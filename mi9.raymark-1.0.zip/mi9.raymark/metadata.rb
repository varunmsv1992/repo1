name             'mi9.raymark'
maintainer       'MI9 Retails'
maintainer_email 'devops@mi9retail.com'
license          'All rights reserved'
description      'Installs/Configures mi9.raymark'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
issues_url       'mailto:devopsservice@mi9retail.com?subject=Raymark Cookbook Issue' if respond_to?(:issues_url)
source_url       'http://mi9retail.com/' if respond_to?(:source_url)
version          '0.3.0'
depends          'mi9.devops.cb.libs'
