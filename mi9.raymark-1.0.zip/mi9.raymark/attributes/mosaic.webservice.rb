default['mosaic']['webservice']['deploy'] =true
default['mosaic']['webservice']['min_kb_available'] =500000
default['mosaic']['webservice']['backup']['ws'] = true
default['mosaic']['webservice']['rollback']['ws'] = false
default['mosaic']['webservice']['backup']['wsdir'] = "#{node['mosaic']['backup']['maindir']}\\ws_#{node['mosaic']['env']}"
default['mosaic']['webservice']['iis_root'] = "C:\\WebSites"
default['mosaic']['webservice']['iis_root_env'] = "#{node['mosaic']['webservice']['iis_root']}\\#{node['mosaic']['env']}"
default['mosaic']['webservice']['backup']['wszip'] = 'WebSites_bkp.zip'
default['mosaic']['webservice']['artifacts'] = ['CRA Web Service ','POS Web Service Public-REST ','POS Web Service-REST ','POSPeripherals Web Service-REST ','LocalFolders ','Mosaic-']
default['mosaic']['webservice']['iis_publication_type'] = 'pubname-env'
default['mosaic']['webservice']['enableHttps'] = false
default['mosaic']['webservice']['deploy_download_folder'] = false

#CRA
default['mosaic']['webservice']['CRA']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\CRAService"
default['mosaic']['webservice']['CRA']['pub_name'] = 'CRAService.mosaic'
default['mosaic']['webservice']['CRA']['app_pool_name'] = 'CRAService'
default['mosaic']['webservice']['CRA']['install'] = true
default['mosaic']['webservice']['CRA']['online_pub_name'] = "CRAService-#{node['mosaic']['env']}"
default['mosaic']['webservice']['CRA']['session_timeout'] = '8:0:0'                      #JSON
default['mosaic']['webservice']['CRA']['caching_enabled'] = 'false'                      #JSON
default['mosaic']['webservice']['CRA']['caching_sliding_expiration'] = '1:0:0'          #JSON
default['mosaic']['webservice']['CRA']['defaultProvider']='LvmhDataProvider'

#POSservice
default['mosaic']['webservice']['POSservice']['install'] = true                          #JSON
default['mosaic']['webservice']['POSservice']['pub_name'] = 'POSservice'                 #JSON
default['mosaic']['webservice']['POSservice']['online_pub_name'] = "POSservice.Rest-#{node['mosaic']['env']}"                 #JSON
default['mosaic']['webservice']['POSservice']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\POSService.REST"
default['mosaic']['webservice']['POSservice']['app_pool_name'] = 'posservice'                 #JSON
default['mosaic']['webservice']['POSservice']['session_timeout'] = '8:0:0'                      #JSON
default['mosaic']['webservice']['POSservice']['caching_enabled'] = 'true'                      #JSON
default['mosaic']['webservice']['POSservice']['caching_sliding_expiration'] = '1:0:0'          #JSON
default['mosaic']['webservice']['POSservice']['xip_database'] = 'XIP'          #JSON

default['mosaic']['webservice']['POSservice']['ePayment']['install'] = false
default['mosaic']['webservice']['POSservice']['ePayment']['type'] = "EpayNet"
default['mosaic']['webservice']['POSservice']['ePayment']['path'] = "C:\\Program Files (x86)\\Raymark\\ePayment"
default['mosaic']['webservice']['POSservice']['ePayment']['dlls'] = ['AuthC3Net.dll','AuthMLNK.dll','AuthSFT4.dll','AuthTriPOS.dll','AuthVRFN.dll','BouncyCastle.Crypto.dll','Encryption.dll','EpaymentTemplates.dll','ePayNet.dll','ePayNet.dll.config','ePayResources.dll','RSAEncryption.dll','Tools.dll','Zip.dll']
#ConnectionStrings

default['mosaic']['ConnectionString']['EFConnectionString'] = "data source=#{node['mosaic']['sql_server_instance']};initial catalog=#{node['mosaic']['sql_db_name']};persist security info=True;user id=#{node['mosaic']['sql_user']};password=#{node['mosaic']['sql_pwd']};MultipleActiveResultSets=True;App=MosaicClientelingWSEF"
default['mosaic']['ConnectionString']['XpertConnection'] = "Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']};App=MosaicClientelingWS"
default['mosaic']['ConnectionString']['XipConnection'] = "Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']};App=MosaicClientelingWS"
default['mosaic']['ConnectionString']['MosaicSchemaEntities'] = "Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']};App=MosaicClientelingWS"
default['mosaic']['ConnectionString']['ConnectionStringWhiteSpace'] = "Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']};App=MosaicClientelingWS"
default['mosaic']['ConnectionString']['ConnectionString'] = "Server=#{node['mosaic']['sql_server_instance']};Database=#{node['mosaic']['sql_db_name']};persist security info=True;user id=#{node['mosaic']['sql_user']};password=#{node['mosaic']['sql_pwd']}"
default['mosaic']['ConnectionString']['SessionConnectionString'] = "data source=#{node['mosaic']['sql_server_instance']};initial catalog=#{node['mosaic']['sql_db_name']};persist security info=True;user id=#{node['mosaic']['sql_user']};password=#{node['mosaic']['sql_pwd']};MultipleActiveResultSets=True"
default['mosaic']['ConnectionString']['XIPReportConnectionString'] = "user id=#{node['mosaic']['sql_user']};password=#{node['mosaic']['sql_pwd']};Persist Security Info=False;Integrated Security=False;Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']}"


#POSServicePublic.REST
default['mosaic']['webservice']['POSWSPublicREST']['install'] = true                     #JSON
default['mosaic']['webservice']['POSWSPublicREST']['pub_name'] = 'posservicepublic.rest' #JSON
default['mosaic']['webservice']['POSWSPublicREST']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\POSServicePublic.REST"
default['mosaic']['webservice']['POSWSPublicREST']['app_pool_name'] = 'posservicepublic'                 #JSON
default['mosaic']['webservice']['POSWSPublicREST']['session_timeout'] = '8:0:0'                      #JSON
default['mosaic']['webservice']['POSWSPublicREST']['caching_enabled'] = 'true'                      #JSON
default['mosaic']['webservice']['POSWSPublicREST']['caching_sliding_expiration'] = '1:0:0'           #JSON
default['mosaic']['webservice']['POSWSPublicREST']['xip_database'] = 'XIP'          #JSON

#POSPeripheral
default['mosaic']['webservice']['POSPeripheral']['install'] = true                       #JSON
default['mosaic']['webservice']['POSPeripheral']['pub_name'] = 'poscontroller'        #JSON
default['mosaic']['webservice']['POSPeripheral']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\POSPeripheralsService.REST"
default['mosaic']['webservice']['POSPeripheral']['app_pool_name'] = 'poscontroller'                 #JSON
default['mosaic']['webservice']['POSPeripheral']['OposPrinterConfigFile'] = "#{node['mosaic']['webservice']['iis_root_env']}\\POSPeripheralsService.REST\\bin\\OPosPrinter.xml"        #JSON

#Mosaic
default['mosaic']['webservice']['MosaicApp']['install'] = true                           #JSON
default['mosaic']['webservice']['MosaicApp']['pub_name'] = 'mosaic'                      #JSON
default['mosaic']['webservice']['MosaicApp']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\Mosaic"
default['mosaic']['webservice']['MosaicApp']['apps'] = ['admin_tool','bulletin_board','GiftRegistry','mpos','oms-dashboard','oms-pps']
default['mosaic']['webservice']['MosaicApp']['app_pool_name'] = 'mosaic'          #JSON

#Image
default['mosaic']['webservice']['Image']['install'] = true                           #JSON
default['mosaic']['webservice']['Image']['pub_name'] = 'Image'                      #JSON
default['mosaic']['webservice']['Image']['physical_path'] = "C:\\Image"
default['mosaic']['webservice']['Image']['app_pool_name'] = 'image'          #JSON

#Backoffice
default['mosaic']['webservice']['Backoffice']['install'] = true                           #JSON
default['mosaic']['webservice']['Backoffice']['pub_name'] = 'backoffice'                      #JSON
default['mosaic']['webservice']['Backoffice']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\Mosaic-Backoffice"
default['mosaic']['webservice']['Backoffice']['app_pool_name'] = 'Backoffice'          #JSON

#CMService
default['mosaic']['webservice']['CMService']['install'] = false                       #JSON
default['mosaic']['webservice']['CMService']['pub_name'] = 'cmservice'        #JSON
default['mosaic']['webservice']['CMService']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\CMService"
default['mosaic']['webservice']['CMService']['app_pool_name'] = 'cmservice'                 #JSON
default['mosaic']['webservice']['CMService']['Auth_ApiUrl'] = 'http://localhost/cmservice-dev'

#CMServiceUI
default['mosaic']['webservice']['CMServiceUI']['install'] = false                       #JSON
default['mosaic']['webservice']['CMServiceUI']['pub_name'] = 'cmservice'        #JSON
default['mosaic']['webservice']['CMServiceUI']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\CMService"
default['mosaic']['webservice']['CMServiceUI']['app_pool_name'] = 'cmservice'                 #JSON
default['mosaic']['webservice']['CMServiceUI']['Auth_ApiUrl'] = 'http://localhost/cmservice-dev'                #JSON

#CStation
default['mosaic']['webservice']['CStation']['install'] = false                       #JSON
default['mosaic']['webservice']['CStation']['pub_name'] = 'controlstation'        #JSON
default['mosaic']['webservice']['CStation']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\Control-Station"
default['mosaic']['webservice']['CStation']['app_pool_name'] = 'control-station'                 #JSON
default['mosaic']['webservice']['CStation']['Auth_ApiUrl'] = 'http://localhost/control-station-dev'                 #JSON

#ClientelingService
default['mosaic']['webservice']['Clienteling']['install'] = false                       #JSON
default['mosaic']['webservice']['Clienteling']['pub_name'] = 'clientelingservice-dev'        #JSON
default['mosaic']['webservice']['Clienteling']['physical_path'] = "#{node['mosaic']['webservice']['iis_root_env']}\\ClientelingService-dev"
default['mosaic']['webservice']['Clienteling']['app_pool_name'] = 'ClientelingService'                 #JSON
default['mosaic']['webservice']['Clienteling']['Auth_ApiUrl'] = 'http://localhost/clientelingservice-dev'
default['mosaic']['webservice']['Clienteling']['ExchangeProxyDomain'] = 'mi9retaildemo.com'
default['mosaic']['webservice']['Clienteling']['ExchangeProxyUri'] = 'https://outlook.office365.com/EWS/Exchange.asmx'
default['mosaic']['webservice']['Clienteling']['ExchangeProxyUserName'] = 'UserName'
default['mosaic']['webservice']['Clienteling']['ExchangeProxyPassword'] = 'Password'
default['mosaic']['webservice']['Clienteling']['eCommerceSite'] = 'https://clienteling.ecom.miix.ca/'
default['mosaic']['webservice']['Clienteling']['ClientelingServiceSecurityToken'] = ''
default['mosaic']['webservice']['Clienteling']['WebServicePublicPassword'] = ''
default['mosaic']['webservice']['Clienteling']['CustomerImagesUploadRootPath'] = 'C:\\Temp\\customer_images'
default['mosaic']['webservice']['Clienteling']['StaffImagesUploadRootPath'] = 'C:\\Temp\\staff_images'
default['mosaic']['webservice']['Clienteling']['ExchangeAuthentication'] = 'false'
default['mosaic']['webservice']['Clienteling']['AssociateEmailAddressDefault'] = 'no-reply@raymark.com'
default['mosaic']['webservice']['Clienteling']['SendMeetingInvitation'] = 'true'


default['mosaic']['webservice']['LocalFolders']['install'] = false
default['mosaic']['webservice']['initial_install'] = false
