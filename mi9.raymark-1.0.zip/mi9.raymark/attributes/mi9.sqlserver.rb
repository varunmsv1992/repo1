#SQL Server properties
default['sql_server']['version']          = '2014'                         #JSON
default['sql_server']['iso_dir']          = "C:\\Temp\\SQLInstall"
default['sql_server']['install_dir']      = 'C:\Program Files\Microsoft SQL Server'
default['sql_server']['port']             = 1433

default['sql_server']['server']           = "#{node['hostname']}"
default['sql_server']['instance_name']    = 'SQLExpress'
default['sql_server']['server_instance']  = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"
#default['sql_server']['instance_dir']     = 'C:\Program Files\Microsoft SQL Server'
#default['sql_server']['data_dir']         = 'C:\MSSQLServer\Data'
default['sql_server']['backup_dir']       = 'E:\Data\_BACKUP'
#default['sql_server']['tempdb_dir']       = 'F:\TempDB'
#default['sql_server']['tempdblog_dir']    = 'F:\TempDB'
#default['sql_server']['userdb_dir']       = 'E:\Data'
#default['sql_server']['userdblog_dir']    = 'E:\Data'

#default['sql_server']['shared_wow_dir']   = 'C:\Program Files (x86)\Microsoft SQL Server'
default['sql_server']['collation']        = 'SQL_Latin1_General_CP1_CI_AS'
default['sql_server']['feature_list']     = 'SQLENGINE,SSMS'
#default['sql_server']['agent_account']    =  'NT AUTHORITY\NETWORK SERVICE'
#default['sql_server']['agent_startup']    =  'enabled'
#default['sql_server']['rs_mode'] = 'FilesOnlyMode'
#default['sql_server']['rs_account'] = 'NT AUTHORITY\NETWORK SERVICE'
#default['sql_server']['rs_startup'] = 'Automatic'
#default['sql_server']['browser_startup']  = 'Disabled'
#default['sql_server']['sysadmins']        = 'Administrator'
default['sql_server']['sql_account']      = 'NT AUTHORITY\NETWORK SERVICE'

#default['sql_server']['file_stream_level']      = 3
#default['sql_server']['file_stream_share_name'] = 'MSSQLSERVERDEVSN'
default['sql_server']['security_mode']          = 'SQL'
default['sql_server']['sapwd']                  = 'R4ym4r7!'

default['sql_server']['version_installed']=''

default['sql_server']['iso_file_name']= 'SQLEXPRWT_x64_ENU.exe'
default['sql_server']['iso_url']= "http://devops2.miix.ca:81/tools/sqlserver_express/"


#./setup.exe /ACTION=Install /IACCEPTSQLSERVERLICENSETERMS
#/UpdateEnabled=0 /features="SQLEngine"
#/instancedir="C:\\Program Files\\Microsoft SQL Server"
#/Instancename=node['sql_server']['instance_name'] /q
#/INSTALLSQLDATADIR=node['sql_server']['data_dir']
#/SQLBACKUPDIR= node['sql_server']['backup_dir']
#/SQLCOLLATION=node['sql_server']['collation']
#/SQLSYSADMINACCOUNTS=node['sql_server']['sysadmins']
#/SQLTEMPDBDIR=node['sql_server']['tempdb_dir']
#/SQLTEMPDBLOGDIR=node['sql_server']['tempdblog_dir']
#/SQLUSERDBDIR="E:\\Data"
#/SQLUSERDBLOGDIR="E:\\Data"
#/INDICATEPROGRESS="True"
#/AGTSVCACCOUNT=node['sql_server']['agent_account']
#/SQLSVCACCOUNT=node['sql_server']['sql_account']
#/FILESTREAMLEVEL=#{node['sql_server']['file_stream_level']}
#/FILESTREAMSHARENAME=node['sql_server']['file_stream_share_name']
#/SECURITYMODE=node['sql_server']['security_mode']
#/SAPWD=node['sql_server']['sapwd']
