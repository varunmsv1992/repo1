default['mcm']['temp_dir'] = 'C:\\temp'
default['mcm']['artifacts_dir'] = 'C:\\Artifacts_depository'            #JSON
default['mcm']['depository_url'] = 'http://10.100.0.153:81/raymark'   #JSON

default['mcm']['version']    = "4.2.12.174"       #JSON

default['mcm']['pos']['deploy'] = true              #JSON
default['mcm']['pos']['min_kb_available'] =500000 #in kb              #JSON

default['mcm']['pos']['deploy'] = true              #JSON

default['mcm']['pos']['path'] = "C:\\merchantconnectmulti"                             #JSON

default['mcm']['pos']['artifacts'] = ['MCM_EMV_Update_Kit-']
default['mcm']['pos']['install'] = true                                 #JSON

#backup
#default['mcm']['env'] = 'LIVE'
default['mcm']['backup']['maindir'] = "C:\\backups"    #common                 #JSON
default['mcm']['pos']['backup']['dir'] = "#{node['mcm']['backup']['maindir']}\\mcm"
default['mcm']['pos']['backup']['zip'] = 'mcm_bkp.zip'
default['mcm']['pos']['backup']['mcm'] = true
default['mcm']['pos']['rollback']['mcm'] = true
