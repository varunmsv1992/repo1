#Windows
default['windows']['temp_dir'] = 'C:\\Temp'

#Mosaic
default['mosaic']['artifacts_dir'] = 'C:\\Artifacts_depository'
default['mosaic']['version']    = "0.0.0.0"
default['mosaic']['depository_url'] = 'http://10.100.0.153:81/raymark'
default['mosaic']['backup']['maindir'] = "C:\\backups"
default['mosaic']['env'] = 'LIVE'
default['mosaic']['restart_iis'] = 'true'
default['mosaic']['profile'] ='standard'
#########################################################################
#Bistro
default['BistroVersion']=1
default['bistro']['url'] = "http://10.100.0.153/bistrojr"
default['waitress']['url'] = node['bistro']['url']
#Windows
default['windows']['drive'] = 'C:\\'
                              #JSON
#default['windows']['drive_C']['min_available'] =500000 #in kb              #JSON
#default['windows']['sqlcmd_path'] = "C:\\Program Files\\Microsoft SQL Server\\120\\Tools\\Binn\\"

#default['windows']['sqlcmd_path_exe'] = node.attribute?('windows') ? node['windows']['sqlcmd_path'] : 'SQLCMD'

require 'mkmf'

sqlcmd = find_executable 'sqlcmd'

if !sqlcmd.empty?
  default['windows']['sqlcmd_path_exe'] = sqlcmd
else
  default['windows']['sqlcmd_path_exe'] = "#{node['windows']['sqlcmd_path']}sqlcmd.exe"
end


#SQL server parameters
default['sql_server']['server']           = '.'                            #JSON
#default['sql_server']['instance_name']   = 'SQLEXPRESS'                   #JSON
default['sql_server']['instance_name']    = ''                             #JSON
default['sql_server']['version']          = '2012'                         #JSON

default['sql_server']['iso_dir']          = "C:\\Temp\\SQLInstall"
default['sql_server']['install_dir']      = 'C:\Program Files\Microsoft SQL Server'
default['sql_server']['port']             = 1433

default['sql_server']['server']           = '.'
default['sql_server']['instance_name']    = 'MSSQLSERVERDEV'
default['sql_server']['instance_dir']     = 'C:\Program Files\Microsoft SQL Server'
default['sql_server']['data_dir']         = 'C:\MSSQLServer\Data'
default['sql_server']['backup_dir']       = 'E:\Data\_BACKUP'
default['sql_server']['iso_file_name']= 'SQLEXPRWT_x64_ENU.exe'
default['sql_server']['iso_url']= "http://devops2.miix.ca:81/tools/sqlserver_express/"
default['sql_server']['server_instance']  = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"

#mosaic: Store configuration
default['mosaic']['customer_name'] = 'Tivol'                               #JSON
default['mosaic']['hostname'] =  "#{node['hostname']}.#{node['domian']}"
                                          #JSON
default['mosaic']['onlineServer'] = node['hostname']
default['mosaic']['offlineServer'] = node['hostname']
default['mosaic']['versionPrefix'] = "#{node['mosaic']['customer_name']} #{node['mosaic']['env']}"
default['mosaic']['offlineVersionPrefix'] = "#{node['mosaic']['customer_name']} #{node['mosaic']['env']}"
default['mosaic']['webprotocol'] = 'http'
default['mosaic']['webprotocol_std'] = node['mosaic']['webprotocol']

default['mosaic']['temp_dir'] = 'C:\\temp'
            #JSON
default['mosaic']['remove_artifacts'] = false
    #JSON
default['xpert']['depository_url'] = node['mosaic']['depository_url']     #JSON
#default['mosaic']['mosaic_root_dir'] = 'E:\Mi9-mosaic-Server'
#default['mosaic']['mosaic_dir']   = "E:\\Mi9-mosaic-Server\\#{node['mosaic']['environment']}"

#database configuration
default['mosaic']['sql_server']           = node['sql_server']['server']
default['mosaic']['sql_instance_name']    = node['sql_server']['instance_name']
default['mosaic']['sql_server_instance']  = node['mosaic']['sql_instance_name'].empty? ? node['mosaic']['sql_server'] : "#{node['mosaic']['sql_server']}\\#{node['mosaic']['sql_instance_name']}"
default['mosaic']['server_instance'] = node['sql_server']['server_instance']
default['mosaic']['sql_db_name'] = "MI9_Retail"                            #JSON
default['mosaic']['sql_user']    = "sa"                                    #JSON
default['mosaic']['sql_pwd']     = "Sa001"                                 #JSON
default['mosaic']['deploy_db']   = true                                 #JSON

#web site configuration
default['mosaic']['programfile_dir'] = 'C:\Program Files (x86)'


#default['mosaic']['iis_root'] = "C:\\WebSites"                             #JSON
#default['mosaic']['iis_root_env'] = "#{node['mosaic']['iis_root']}\\#{node['mosaic']['env']}"   #

#mosaic installation Package
default['mosaic']['build']      = '2020'
      #JSON
default['mosaic']['prev_version'] = "2.7.0.#{node['mosaic']['build']}"     #JSON

#Emails notifications
default['deploy']['sendmailonrunfailed']=true
default['deploy']['sendmailonruncompleted']=true
default['deploy']['email']['from']='MI9 DevOps <devops@mi9retail.com>' #common
default['deploy']['email']['to']=['devops@mi9retail.com'] #common  #JSON
default['deploy']['email']['server']='smtp.gmail.com'     #common
default['deploy']['email']['port']='587'                  #common
default['deploy']['email']['domain']='gmail.com'          #common
default['deploy']['email']['user']='devops@mi9retail.com' #common
default['deploy']['email']['password']='M19D3v0ps'        #common

#Version file
default['mosaic']['version_file'] = "C:\\Temp\\mosaic_version.txt"


#default['mosaic']['backup']['dbdir'] = "#{node['mosaic']['backup']['maindir']}\\db_#{node['mosaic']['env']}"
default['mosaic']['backup']['delete_dbdir'] = true
#default['mosaic']['backup']['db'] = false

default['mosaic']['backup']['delete_wsdir'] = true
