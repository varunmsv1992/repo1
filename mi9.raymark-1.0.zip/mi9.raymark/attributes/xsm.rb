default['xsm']['deploy'] = true
default['xsm']['min_kb_available'] =500000 #in kb
default['xsm']['version'] = "1.9.6.0"
default['xsm']['depository_url']="http://10.100.0.153/depository/Artifacts/XSM"
default['xsm']['artifacts_dir']='C:\\Artifacts_depository'
default['xsm']['backup']['maindir'] = "C:\\backups"

default['xsm']['webservice']['install'] = true
default['xsm']['webservice']['artifact'] = "XSMWebService"
default['xsm']['webservice']['web_path'] = "C:\\inetpub\\wwwroot\\XSM"
default['xsm']['webservice']['database']['server'] = "(local)"
default['xsm']['webservice']['database']['name'] = "DBNAME"
default['xsm']['webservice']['database']['user'] = "sa"
default['xsm']['webservice']['database']['password'] = "XXXX"
default['xsm']['webservice']['backup']['enable'] = true
default['xsm']['webservice']['backup']['dir'] = "XSMWebService"
default['xsm']['webservice']['backup']['zip'] = "XSMWebService.zip"
default['xsm']['webservice']['rollback'] = false

default['xsm']['xsms']['install'] = false
default['xsm']['xsms']['artifact'] = "XSMS"
default['xsm']['xsms']['prev_version'] = "1.9.5.0"
default['xsm']['xsms']['nametouninstall'] = "Xpert-Standalone Manager Server"
default['xsm']['xsms']['folder'] = "C:\\Program Files (x86)\\Raymark\\XSMS\\"

default['xsm']['ftpdg']['install'] = false
default['xsm']['ftpdg']['artifact'] = "FTPDG"
default['xsm']['ftpdg']['prev_version'] = "1.9.5.0"
default['xsm']['ftpdg']['nametouninstall'] = "Xpert-Standalone Manager Data Packer"
default['xsm']['ftpdg']['folder'] = "C:\\Program Files (x86)\\Raymark\\GeneratedFTPdata\\"
