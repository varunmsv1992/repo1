#default_values for POS
default['mosaic']['pos']['deploy'] =true
default['mosaic']['pos']['iis_root'] = "C:\\Program Files (x86)\\Raymark\\Mosaic"
=begin
#CRA
default['mosaic']['pos']['CRA']['install'] = true                                 #JSON
default['mosaic']['pos']['CRA']['pub_name'] = 'CRAService.mosaic'                 #JSON
default['mosaic']['pos']['CRA']['physical_path'] = "#{node['mosaic']['pos']['iis_root']}\\CRAService"
default['mosaic']['pos']['CRA']['app_pool_name'] = 'CRAService.Mosaic'                 #JSON

#POSservice
default['mosaic']['pos']['POSservice']['install'] = true                          #JSON
default['mosaic']['pos']['POSservice']['pub_name'] = 'POSservice'                 #JSON
default['mosaic']['pos']['POSservice']['physical_path'] = "#{node['mosaic']['pos']['iis_root']}\\POSService.REST"
default['mosaic']['pos']['POSservice']['app_pool_name'] = 'posservice'                 #JSON

#POSServicePublic.REST
default['mosaic']['pos']['POSWSPublicREST']['install'] = true                     #JSON
default['mosaic']['pos']['POSWSPublicREST']['pub_name'] = 'posservicepublic.rest' #JSON
default['mosaic']['pos']['POSWSPublicREST']['physical_path'] = "#{node['mosaic']['pos']['iis_root']}\\POSServicePublic.REST"
default['mosaic']['pos']['POSWSPublicREST']['app_pool_name'] = 'DefaultAppPool'                 #JSON

#POSPeripheral
default['mosaic']['pos']['POSPeripheral']['install'] = true                       #JSON
default['mosaic']['pos']['POSPeripheral']['pub_name'] = 'POSController_40'        #JSON
default['mosaic']['pos']['POSPeripheral']['physical_path'] = "#{node['mosaic']['pos']['iis_root']}\\POSPeripheralsService.REST"
default['mosaic']['pos']['POSPeripheral']['app_pool_name'] = 'POSController_40'                 #JSON
=end

#Mosaic
default['mosaic']['pos']['MosaicApp']['install'] = true                           #JSON
default['mosaic']['pos']['MosaicApp']['pub_name'] = 'mosaic'                      #JSON
default['mosaic']['pos']['MosaicApp']['physical_path'] = "#{node['mosaic']['pos']['iis_root']}\\www"
default['mosaic']['pos']['MosaicApp']['apps'] = ['admin_tool','bulletin_board','GiftRegistry','mpos','oms-dashboard','oms-pps']
default['mosaic']['pos']['MosaicApp']['app_pool_name'] = 'mosaicservice'          #JSON

default['mosaic']['pos']['MosaicApp']['config']['setup'] = false
default['mosaic']['pos']['MosaicApp']['config']['PeripheralAllowed'] = 0
default['mosaic']['pos']['MosaicApp']['config']['DefaultCashDrawerId'] = ''
default['mosaic']['pos']['MosaicApp']['config']['DefaultLineDisplayId'] = ''
default['mosaic']['pos']['MosaicApp']['config']['DefaultMICRId'] = ''
default['mosaic']['pos']['MosaicApp']['config']['DefaultMSReaderId'] = ''
default['mosaic']['pos']['MosaicApp']['config']['DefaultPrinterId'] = ''
default['mosaic']['pos']['MosaicApp']['config']['DefaultScannerId'] = ''
default['mosaic']['pos']['MosaicApp']['config']['LocaleName'] = ''
default['mosaic']['pos']['MosaicApp']['config']['apply_patch'] = false

default['mosaic']['pos']['MosaicApp']['config']['MosaicPeripheralsMgr']= 'C:\\Program Files (x86)\\Raymark\\MosaicPeripheralsMgr'
default['mosaic']['pos']['MosaicApp']['config']['logo']= 'D:\\Share\\logo1.bmp'

default['mosaic']['pos']['MosaicApp']['patches']['apply'] = false
#default['mosaic']['pos']['MosaicApp']['patches']['patchfiles'] = {''=>{'',false}}


default['mosaic']['pos']['storemap_defined'] = false
