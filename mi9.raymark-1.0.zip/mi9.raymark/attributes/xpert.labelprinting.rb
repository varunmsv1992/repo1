default['xpert']['temp_dir'] = 'C:\\temp'
default['xpert']['artifacts_dir'] = 'C:\\Artifacts_depository'            #JSON
default['xpert']['depository_url'] = 'http://10.100.0.153:81/raymark'   #JSON

default['xpert']['version']    = "9.0.5R3"       #JSON

default['xpert']['labelprinting']['deploy'] = true              #JSON
default['xpert']['labelprinting']['min_kb_available'] =500000 #in kb              #JSON

#IIS Configuration
default['xpert']['labelprinting']['path'] = "C:\\Program Files (x86)\\Raymark\\Xpert-LabelPrinting"                             #JSON


#backup
#default['xpert']['env'] = 'LIVE'
default['xpert']['backup']['maindir'] = "C:\\backups"    #common                 #JSON
default['xpert']['labelprinting']['backup']['dir'] = "#{node['xpert']['backup']['maindir']}\\xpert-labelprinting"
default['xpert']['labelprinting']['backup']['zip'] = 'xpert_labelprinting_bkp.zip'
default['xpert']['labelprinting']['backup']['xpert'] = true
default['xpert']['labelprinting']['rollback']['xpert'] = true

default['xpert']['labelprinting']['artifacts'] = ['xpert-Label Printing ']

#XPERT FEATURES
default['xpert']['labelprinting']['install'] = true                                 #JSON
