#default_values for standalone
default['mosaic']['standalone']['min_kb_available'] =500000 #in kb              #JSON

default['mosaic']['standalone']['backup']['dbdir'] = "#{node['mosaic']['backup']['maindir']}\\db"
default['mosaic']['standalone']['backup']['db'] = true
default['mosaic']['standalone']['rollback']['db'] = true                            #JSON
default['mosaic']['standalone']['initial_install'] = false

default['mosaic']['standalone']['dbuser'] = "standalone"
default['mosaic']['standalone']['dbpwd'] = "standalone"
default['mosaic']['standalone']['admin_dbuser'] = "sqladmin"
default['mosaic']['standalone']['admin_dbpwd'] = "raymadm"
default['mosaic']['standalone']['cert_path']="C:\\XSM\\"
default['mosaic']['standalone']['centraldbserver']="ITSSQLSERVER"
default['mosaic']['standalone']['centraldbsource']="ItSugar"
default['mosaic']['standalone']['centraldbuser'] = "sa"
default['mosaic']['standalone']['centradbpwd'] = "Raym5460"
default['mosaic']['standalone']['ds_syncline_settings']['http_address'] = ""
default['mosaic']['standalone']['ds_syncline_settings']['http_port'] = "80"
default['mosaic']['standalone']['ds_syncline_settings']['ftp_address'] = ""
default['mosaic']['standalone']['ds_syncline_settings']['ftp_port'] = "21"
default['mosaic']['standalone']['ds_syncline_settings']['ftp_user'] = ""
default['mosaic']['standalone']['ds_syncline_settings']['ftp_password'] = ""
