default['xpert']['temp_dir'] = 'C:\\temp'
default['xpert']['artifacts_dir'] = 'C:\\Artifacts_depository'            #JSON
default['xpert']['depository_url'] = 'http://10.100.0.153:81/raymark'   #JSON

default['xpert']['version']    = "9.0.5R3"       #JSON

default['xpert']['pos']['deploy'] = true              #JSON
default['xpert']['pos']['min_kb_available'] =500000 #in kb              #JSON

#IIS Configuration
default['xpert']['pos']['path'] = "C:\\Program Files (x86)\\Raymark\\Xpert-Central\\Main"                             #JSON


#backup
#default['xpert']['env'] = 'LIVE'
default['xpert']['backup']['maindir'] = "C:\\backups"    #common                 #JSON
default['xpert']['pos']['backup']['dir'] = "#{node['xpert']['backup']['maindir']}\\xpert-central"
default['xpert']['pos']['backup']['zip'] = 'xpert_bkp.zip'
default['xpert']['pos']['backup']['xpert'] = true
default['xpert']['pos']['rollback']['xpert'] = true

default['xpert']['pos']['artifacts'] = ['xpert-central ']

#XPERT FEATURES
default['xpert']['pos']['install'] = true                                 #JSON
