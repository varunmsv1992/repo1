
default['xpert']['XEIS']['version']    = "9.0.5R3"       #JSON

default['xpert']['XEIS']['deploy'] = true              #JSON
default['xpert']['XEIS']['min_kb_available'] =500000 #in kb              #JSON

#IIS Configuration
default['xpert']['XEIS']['path'] = "C:\\Program Files (x86)\\Raymark\\XEIS"                             #JSON



#default['xpert']['Apps']['artifacts'] = {'Xpert-EIS '=>'2.2.0.15','Xpert-EIS Scheduler '=>'2.0.0.1', 'Xpert-Financial Link '=>'3.8.0.11', 'Xpert-Purchaser '=>'3.8.0.6','Xpert-Replenisher '=>'4.6.0.15'}
default['xpert']['Apps']['Installers'] = ["XEIS","XEIS Scheduler","XFL","XGOP","XRS"]


#XEIS
default['xpert']['Apps']['XEIS']['install'] = true                          #JSON
default['xpert']['Apps']['XEIS']['app_name'] = 'Xpert-EIS'                 #JSON
default['xpert']['Apps']['XEIS']['acronym_name'] = 'XEIS'
default['xpert']['Apps']['XEIS']['version'] = "2.2.0.15"                 #JSON
default['xpert']['Apps']['XEIS']['connection_string'] = "Persist Security Info=False;Integrated Security=SSPI;Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']}"                 #JSON
default['xpert']['Apps']['XEIS']['env'] = "-PRO"
#Server=ServerName;Database=DatabaseName;Uid=UserName;Pwd=Password
#XEIS Scheduler
default['xpert']['Apps']['XEIS Scheduler']['install'] = true                          #JSON
default['xpert']['Apps']['XEIS Scheduler']['app_name'] = 'Xpert-EIS Scheduler'                 #JSON
default['xpert']['Apps']['XEIS Scheduler']['acronym_name'] = 'XEIS Scheduler'
default['xpert']['Apps']['XEIS Scheduler']['version'] = "2.0.0.1"                 #JSON
default['xpert']['Apps']['XEIS Scheduler']['connection_string'] = "Persist Security Info=False;Integrated Security=SSPI;Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']}"                 #JSON
default['xpert']['Apps']['XEIS']['env'] = ""

#XEIS
default['xpert']['Apps']['XFL']['install'] = true                          #JSON
default['xpert']['Apps']['XFL']['app_name'] = 'Xpert-Financial Link'                 #JSON
default['xpert']['Apps']['XFL']['acronym_name'] = 'XFL'
default['xpert']['Apps']['XFL']['version'] = "3.8.0.11"                 #JSON
default['xpert']['Apps']['XFL']['connection_string'] = "Persist Security Info=False;Integrated Security=SSPI;Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']}"                 #JSON
default['xpert']['Apps']['XEIS']['env'] = ""

#XEIS
default['xpert']['Apps']['XGOP']['install'] = true                          #JSON
default['xpert']['Apps']['XGOP']['app_name'] = 'Xpert-Purchaser'                 #JSON
default['xpert']['Apps']['XGOP']['acronym_name'] = 'XGOP'
default['xpert']['Apps']['XGOP']['version'] = "3.8.0.6"                 #JSON
default['xpert']['Apps']['XGOP']['connection_string'] = "Persist Security Info=False;Integrated Security=SSPI;Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']}"                 #JSON
default['xpert']['Apps']['XEIS']['env'] = ""

#XEIS
default['xpert']['Apps']['XRS']['install'] = true                          #JSON
default['xpert']['Apps']['XRS']['app_name'] = 'Xpert-Replenisher'                 #JSON
default['xpert']['Apps']['XRS']['acronym_name'] = 'XRS'
default['xpert']['Apps']['XRS']['version'] = "4.6.0.15"                 #JSON
default['xpert']['Apps']['XRS']['connection_string'] = "Persist Security Info=False;Integrated Security=SSPI;Database=#{node['mosaic']['sql_db_name']};Server=#{node['mosaic']['sql_server_instance']};password=#{node['mosaic']['sql_pwd']};user=#{node['mosaic']['sql_user']}"                 #JSON
default['xpert']['Apps']['XEIS']['env'] = ""
