default['mosaic']['masterdb']['SubscriberDB'] = "#{node['mosaic']['sql_db_name']}"    #JSON
default['mosaic']['masterdb']['CertificatePath'] = "C:\\MSSQL\\Certificates"          #JSON
default['mosaic']['masterdb']['dbrole']= "Public"
default['mosaic']['masterdb']['min_kb_available'] =500000 #in kb              #JSON


default['mosaic']['masterdb']['execution_result_filename'] ="C:\\bacups\\execution_result.txt"
default['mosaic']['masterdb']['backup']['dbdir'] = "C:\\backups"
default['mosaic']['masterdb']['backup_master'] = true
default['mosaic']['masterdb']['backup_standalone'] = true
default['mosaic']['masterdb']['datapath'] = 'E:\\Microsoft SQL Server\\MSSQL12.MSSQLSERVER\\MSSQL\\DATA'

default['mosaic']['masterdb']['httpaddress'] = "http:\\localhost"
default['mosaic']['masterdb']['ftpaddress'] = "ftp:\\localhost"
default['mosaic']['masterdb']['ftpuser'] = "ftpuser"
default['mosaic']['masterdb']['ftppassword'] = "ftppwd"
default['mosaic']['masterdb']['sharedfolder'] = "E:\\SharedFolder"
default['mosaic']['masterdb']['emailnotification'] = 'devops@mi9retail.com'
