default['mosaic']['db']['SubscriberDB'] = "#{node['mosaic']['sql_db_name']}"    #JSON
default['mosaic']['db']['CertificatePath'] = "C:\\MSSQL\\Certificates"          #JSON
default['mosaic']['db']['dbrole']= "Public"
default['mosaic']['db']['min_kb_available'] =500000 #in kb              #JSON

default['mosaic']['db']['backup']['dbdir'] = "#{node['mosaic']['backup']['maindir']}\\db"
default['mosaic']['db']['backup']['db'] = false
default['mosaic']['db']['rollback']['db'] = false                            #JSON

default['mosaic']['db']['execution_result_filename'] ="execution_result.txt"
