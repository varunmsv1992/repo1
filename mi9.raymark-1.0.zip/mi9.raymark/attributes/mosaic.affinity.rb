default['mosaic']['affinity']['deploy'] =true                                  #JSON
default['mosaic']['affinity']['min_kb_available'] =500000 #in kb              #JSON
default['mosaic']['affinity']['installation_type'] = "pubname-env"

#IIS Configuration
default['mosaic']['affinity']['iis_root'] = "C:\\Program Files (x86)\\Raymark\\"                             #JSON
default['mosaic']['affinity']['iis_root_env'] = "#{node['mosaic']['affinity']['iis_root']}\\#{node['mosaic']['env']}"   #
default['mosaic']['affinity']['installation_type'] = "pubname-env"
#backup
default['mosaic']['affinity']['backup']['appsdir'] = "#{node['mosaic']['backup']['maindir']}\\apps_#{node['mosaic']['env']}"
default['mosaic']['affinity']['backup']['appszip'] = 'affinity_bkp.zip'
default['mosaic']['affinity']['backup']['apps'] = true
default['mosaic']['affinity']['rollback']['apps'] = true

default['mosaic']['affinity']['artifacts'] = ['Affinity-Customer Relationship Management ','Affinity-Merchandising ','Affinity-Repairs ','Affinity-Enterprise Solution Manager ']

#CRM = Affinity-Customer Relationship Management
default['mosaic']['affinity']['RCRM']['install'] = true                   #JSON
default['mosaic']['affinity']['RCRM']['pub_name'] = 'RCRM'                 #JSON
default['mosaic']['affinity']['RCRM']['physical_path'] = "#{node['mosaic']['affinity']['iis_root_env']}\\RCRM"

#RAMS = Affinity-Merchandising
default['mosaic']['affinity']['RAMS']['install'] = true                   #JSON
default['mosaic']['affinity']['RAMS']['pub_name'] = 'RAMS'                #JSON
default['mosaic']['affinity']['RAMS']['physical_path'] = "#{node['mosaic']['affinity']['iis_root_env']}\\RAMS"

#Repairs = Affinity-Repairs
default['mosaic']['affinity']['Repairs']['install'] = true                #JSON
default['mosaic']['affinity']['Repairs']['pub_name'] = 'REPAIRS'          #JSON
default['mosaic']['affinity']['Repairs']['physical_path'] = "#{node['mosaic']['affinity']['iis_root_env']}\\REPAIRS"

#RESM = Affinity-Repairs
default['mosaic']['affinity']['RESM']['install'] = true                #JSON
default['mosaic']['affinity']['RESM']['pub_name'] = 'RESM'          #JSON
default['mosaic']['affinity']['RESM']['physical_path'] = "#{node['mosaic']['affinity']['iis_root_env']}\\RESM"
