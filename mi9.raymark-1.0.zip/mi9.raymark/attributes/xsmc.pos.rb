default['xsmc']['temp_dir'] = 'C:\\temp'
default['xsmc']['artifacts_dir'] = 'C:\\Artifacts_depository'            #JSON
default['xsmc']['depository_url'] = 'http://10.100.0.153:81/raymark'   #JSON

default['xsmc']['version']    = "2.7.0.0"       #JSON

default['xsmc']['pos']['deploy'] =true              #JSON
default['xsmc']['pos']['min_kb_available'] =500000 #in kb              #JSON

#IIS Configuration
default['xsmc']['pos']['path'] = "C:\\XSMC"                             #JSON

#backup
default['xsmc']['backup']['maindir'] = "C:\\backups"    #common                 #JSON
default['xsmc']['pos']['backup']['dir'] = "#{node['xsmc']['backup']['maindir']}\\XSMC"
default['xsmc']['pos']['backup']['zip'] = 'xsmc_bkp.zip'
default['xsmc']['pos']['backup']['xsmc']  = true

default['xsmc']['pos']['artifacts'] = ['XSMC ']

#xsmc FEATURES
default['xsmc']['pos']['install'] = true                                 #JSON
default['xsmc']['pos']['serverhost'] = "ITSXSMCSYNC1"
default['xsmc']['pos']['maintenanceFolder'] = true

default['xsmc']['pos']['logfiledestination'] = "C:\\Log\\XSM_WG"
default['xsmc']['pos']['typeofuninstall'] = "direct"
default['xsmc']['pos']['nametouninstall'] = "Xpert-Standalone Manager Client"
