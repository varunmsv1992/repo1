default['tpls']['CMServiceUI']=[
                                {"file"=>"App/config.js","source"=>"/store.framework/config.js.erb", "local"=>false}
                              ]

default['tpls']['MosaicApp']=[
                              {"file"=>"App_js/serverSettings.js","source"=>"\\App_js.serverSettings.js.erb", "local"=>true},
                              {"file"=>"admin_tool/App_js/serverSettings.js","source"=>"\\admin_tool.serverSettings.js.erb", "local"=>true},
                              {"file"=>"bulletin_board/App_js/serverSettings.js","source"=>"\\bulletin_board.serverSettings.js.erb", "local"=>true},
                              {"file"=>"GiftRegistry/App_js/serverSettings.js","source"=>"\\GiftRegistry.serverSettings.js.erb", "local"=>true},
                              {"file"=>"mpos/App_js/serverSettings.js","source"=>"\\mpos.serverSettings.js.erb", "local"=>true},
                              {"file"=>"oms-dashboard/App_js/serverSettings.js","source"=>"\\oms-dashboard.serverSettings.js.erb", "local"=>true},
                              {"file"=>"oms-pps/App_js/serverSettings.js","source"=>"\\oms-pps.serverSettings.js.erb", "local"=>true}
                            ]

default['tpls']['Backoffice']=[
                              {"file"=>"App_js/serverSettings.js","source"=>"\\App_js.serverSettings.js.erb", "local"=>true}
                            ]
