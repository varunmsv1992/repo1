#
# Cookbook Name:: mi9.raymark
# Recipe:: Upgrade sqlserver express
#
# Copyright (c) 2016 Mi9 Retail, All Rights Reserved.

# actions

#include_recipe 'chef_handler::inprogressbistrostatus'

#
# Declaring Variables

# --- ISO file <SQL_SERVER_ISO_FILE>
case "#{node['sql_server']['version']}"
when '2008'
	iso_url             = "#{node['sql_server']['iso_url']}//2008R2//#{node['sql_server']['iso_file_name']}"
when '2012'
	iso_url             = "#{node['sql_server']['iso_url']}/2012/#{node['sql_server']['iso_file_name']}"
when '2014'
	iso_url             = "#{node['sql_server']['iso_url']}/2014/#{node['sql_server']['iso_file_name']}"
end

iso_filename 			= "#{node['sql_server']['iso_file_name']}"
iso_dir           = node['sql_server']['iso_dir']
iso_path          = "#{iso_dir}\\#{iso_filename}"

node_user         = "administrator"

# --- Temporary files directory
tempdb_dir 				= node['sql_server']['tempdb_dir']
temp 							= node['windows']['temp_dir']

db_instance 			= ".\\#{node['sql_server']['instance_name']}"
Is2008Installed   = "False"

# Declaring Resources

# Creating a Temporary Directory to work from.
directory "#{iso_dir}" do
	rights :full_control, "#{node_user}"
	inherits true
	action :create
  recursive true
end
=begin
powershell_script 'Check_if_sql_is_installed' do
	code <<-EOH
		#(get-itemproperty 'HKLM:\\SOFTWARE\\Microsoft\\Microsoft SQL Server').InstalledInstances > #{node['windows']['temp_dir']}\\is_sql_installed.txt
		$server = $env:computername
		#Write-Output $server
		$sqlVersions = "11.0.2280.0", "red"
		$result = $false

		$regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $server)
		$SqlKey = $regKey.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL")
		#Write-Verbose "Processing Server $server"
		if ($SqlKey -ne $null)
		{
			Foreach ($instance in $SqlKey.GetValueNames())
			{
				$SQLServerObject = New-Object PSObject
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name ServerName -Value $server
				$InstanceName = $SqlKey.GetValue("$instance")
				Write-Progress -Activity "Parsing SQL-Server Information" -Status "Current Instance $instancename" -ParentID 1
				$InstanceKey = $regKey.OpenSubkey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\$InstanceName\\Setup")
				# $InstanceKey.GetValue("Version")
				$v = $InstanceKey.GetValue("Version").Substring(0,2)
	      switch($v){
	           "10" {"2008" | Out-File "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	           "11" {"2012" | Out-File "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	           "12" {"2014" | Out-File "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	           default {"2012" | Out-File "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	      }
			}
		}else {"NONE" | Out-File "C:\\Temp\\sqlversion.txt"}
		EOH
	guard_interpreter :powershell_script
	not_if { 1!=1}
end


#report back after all is done
ruby_block "is_sql_installed" do
  block do
    encoding_options = {
        :invalid           => :replace,  # Replace invalid byte sequences
        :undef             => :replace,  # Replace anything not defined in ASCII
        :replace           => '',        # Use a blank for those replacements
        :universal_newline => true       # Always break lines with \n
      }
      node.default['sql_server']['version_installed'] = File.read("#{node['windows']['temp_dir']}\\sqlversion.txt").encode(Encoding.find('ASCII'), encoding_options)
  end
end
=end
# Download the SQL Server from a Web Share.
powershell_script 'Download SQL Server Installer' do
	code <<-EOH
		$Client = New-Object System.Net.WebClient
		$Client.DownloadFile("#{iso_url}", "#{iso_path}")
		EOH
	guard_interpreter :powershell_script
	not_if { File.exists?(iso_path)}
end
#$exe = "#{iso_path} /q /X:'#{iso_dir}\\sqlserver_express'"
# Unpack express installer.
powershell_script 'Unpack express installer' do
	code  <<-EOH

		$exe = "#{iso_path} /q /X:'C:\\tmp'"
		Invoke-Expression $exe
		EOH
	guard_interpreter :powershell_script
	not_if '1!=1'
end


# Installing SQL Server  Standard.
reboot 'Restart Computer' do
  action :nothing
end

powershell_script 'Install SQL Server' do
	code <<-EOH
		$SQL_Server_ISO_Drive_Letter = (gwmi -Class Win32_LogicalDisk | Where-Object {$_.VolumeName -eq "SQLServer"}).DeviceID
		#echo $SQL_Server_ISO_Drive_Letter
		$currDir = Get-Location
		cd C:\\tmp\\
		$Install_SQL = ./setup.exe /Q /ACTION=Install /IACCEPTSQLSERVERLICENSETERMS /SkipRules=RebootRequiredCheck /UpdateEnabled=0 /features="#{node['sql_server']['feature_list']}" /Instancename=#{node['sql_server']['instance_name']} /SQLCOLLATION="#{node['sql_server']['collation']}" /INDICATEPROGRESS="True" /SQLSVCACCOUNT="#{node['sql_server']['sql_account']}"  /SECURITYMODE=#{node['sql_server']['security_mode']} /SAPWD="#{node['sql_server']['sapwd']}"
		$Install_SQL > #{iso_dir}\\SQL_Server_Install_Results.txt
		cd $currDir
		EOH
	guard_interpreter :powershell_script
	not_if "((gwmi -class win32_service | Where-Object {$_.Name -eq #{node['sql_server']['instance_name']}}).Name -eq #{node['sql_server']['instance_name']})"
	#notifies :reboot_now, 'reboot[Restart Computer]', :immediately
end

powershell_script 'Enable TCP and PIPES Protocols' do
	code <<-EOH
	  [reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
	  [reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement")
		#Import-Module "sqlps" -DisableNamechecking

		$smo = 'Microsoft.SqlServer.Management.Smo.'
		$wmi = new-object ($smo + 'Wmi.ManagedComputer').

		# List the object properties, including the instance names.
		$Wmi

	  # $cn = [System.Net.Dns]::GetHostName()
	  # $cn = "#{node['hostname']}"
		$cn = $env:COMPUTERNAME
		# Enable the TCP protocol on the default instance.
		$uri = "ManagedComputer[@Name='$cn']/ ServerInstance[@Name='SQLEXPRESS']/ServerProtocol[@Name='Tcp']"
		$Tcp = $wmi.GetSmoObject($uri)
		if (!$Tcp.IsEnabled){
			$Tcp.IsEnabled = $true
			$Tcp.Alter()
			$Tcp
		}

		# Enable the named pipes protocol for the default instance.
		$uri = "ManagedComputer[@Name='$cn']/ ServerInstance[@Name='SQLEXPRESS']/ServerProtocol[@Name='Np']"
		$Np = $wmi.GetSmoObject($uri)
		if (!$Np.IsEnabled){
			$Np.IsEnabled = $true
			$Np.Alter()
			$Np
	  }

		EOH
	guard_interpreter :powershell_script
	not_if { 1!=1}
end

# Removing the SQL Server from the Temp Directory.
=begin
powershell_script 'Delete SQL Server ISO' do
	code <<-EOH
		#[System.IO.File]::Delete("#{iso_path}")
		[System.IO.File]::Delete("#{temp}\\sqlserver_express\\")
		EOH
	guard_interpreter :powershell_script
	only_if { File.exists?(iso_path)}
end
=end

#include_recipe 'chef_handler::completedbistrostatus'
