#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.wf.install
#s
# Copyright (c) 2016 Mi9 Retail, All Rights Reserved.

# actions
# – Installing Windows Features
#

# Declaring Variables
# Declaring Resources

#Install IIS (WebServer)

node['windows']['features']['Windows7'].each do |feature|
  #execute "#{feature}" do
   #command "C:\\Windows\\SysWOW64\\dism.exe /online /enable-feature /all /featurename:#{feature} /norestart"
   #ignore_failure true
  #end

  batch "Installing #{feature}" do
    #architecture :x86_64
    code <<-EOH
    \"dism.exe\" /online /enable-feature /featurename:#{feature} /norestart
    EOH

  end
#  powershell_script "Enabling #{feature}" do
#    code "Add-WindowsFeature #{feature}"
#    guard_interpreter :powershell_script
#    not_if "(Get-WindowsFeature -Name #{feature}).InstallState -eq 'Installed'"
#  end
end

service 'w3svc' do
  action [:enable, :start]
end

execute "register iis" do
 command "C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\aspnet_regiis.exe /i"
 ignore_failure true
end
