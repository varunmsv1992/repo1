version = node['xsm']['version']
art_url = node['xsm']['depository_url']
pkg_dir = "#{node['xsm']['artifacts_dir']}\\#{version}"

directory 'Create_directory'  do
  path "#{pkg_dir}"
  recursive true
  action :create
  not_if { ::File.exists?(pkg_dir)}
end

########################################################
# XSM WebService Deploy
########################################################
if node['xsm']['webservice']['install']

  ruby_block "Check if IIS is installed and running" do
    block do
      script =<<-EOF
          $result = get-wmiobject -query 'select * from Win32_Service where name=''W3svc'''
          return $result.State
      EOF
      iis_running = powershell_out(script).stdout.chop
      if iis_running == ""
          node.default['deploy']['runstatus']="XSM - WebService - Check if IIS is installed and running. IIS isn\'t installed"
          fail 'IIS isn\'t installed'
      end
    end
    only_if {(node['xsm']['webservice']['install'])}
  end

  webServiceArtifact=node['xsm']['webservice']['artifact']

  remote_file "#{pkg_dir}\\#{webServiceArtifact}_#{version}.zip" do
     source "#{art_url}/#{version}/#{webServiceArtifact}_#{version}.zip"
  	 not_if { ::File.exists?("#{pkg_dir}\\#{webServiceArtifact}_#{version}.zip")}
  end

  powershell_script "Unziping artifact #{webServiceArtifact} " do
  	  code <<-EOH
        $Zipfile = "#{pkg_dir}\\#{webServiceArtifact}_#{version}.zip"
  			$Destination = "#{pkg_dir}\\#{webServiceArtifact}_#{version}"
  	    Add-Type -assembly "system.io.compression.filesystem"
  	    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
  	    EOH
  	    guard_interpreter :powershell_script
  	  not_if { ::File.directory?("#{pkg_dir}\\#{webServiceArtifact}_#{version}")}
  end

  #####################################################
  # Deploy WebService
  #####################################################
  batch "Deploy WebService " do
    code <<-EOH
    \"#{pkg_dir}\\#{webServiceArtifact}_#{version}\\XSMWebService.deploy.cmd\" /Y
    EOH
  end

  #####################################################
  # Apply template App
  #####################################################
  template "Apply Template to App.ini" do
    path "#{node['xsm']['webservice']['web_path']}/App.ini"
    source "xsm/webservice/App.ini.erb"
  end

  report_app_installed_v2 'reporting XSM webservice installed' do
      appname 'XSMWebService'
      version version
      path node['xsm']['webservice']['web_path']
      details "WebService"
      action :send
  end

end

#####################################################
# XSMS Installation
#####################################################
if node['xsm']['xsms']['install']

  node.default['deploy']['runstatus']="XSM - XSMS - Start Installation."

  xsms_pkg_dir_prev = "#{node['xsm']['artifacts_dir']}\\#{version}\\xsms_prev"
  xsms_prev_version = node['xsm']['xsms']['prev_version']
  #Creating pkg_dir/xsms previous version folder
  directory xsms_pkg_dir_prev do
    action :create
    not_if { ::File.directory?(xsms_pkg_dir_prev)}
  end

  #download XSMS previous version
  remote_file "#{xsms_pkg_dir_prev}\\XSMS_#{xsms_prev_version}.zip" do
   source "#{art_url}/#{xsms_prev_version}/#{node['xsm']['xsms']['artifact']}_#{xsms_prev_version}.zip"
   not_if { ::File.exists?("#{xsms_pkg_dir_prev}\\XSMS_#{xsms_prev_version}.zip")}
  end

  powershell_script "Unziping XSMS previous version " do
    code <<-EOH
      $Zipfile = "#{xsms_pkg_dir_prev}\\XSMS_#{xsms_prev_version}.zip"
      $Destination = "#{xsms_pkg_dir_prev}\\XSMS_#{xsms_prev_version}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
      guard_interpreter :powershell_script
    not_if { ::File.directory?("#{xsms_pkg_dir_prev}\\XSMS_#{xsms_prev_version}")}
  end

  powershell_script "Uninstall XSMS" do
    code <<-EOH
          $app = Get-WmiObject -Class Win32_Product | Where-Object {
            $_.Name -match "#{node['xsm']['xsms']['nametouninstall']}"
          }

          if($app)
          {
            $app.Uninstall()

            $Registry_Key = "HKLM:\\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\"
            $items = Get-ChildItem $Registry_Key | Where-Object {$_.GetValue("DisplayName") -match "Xpert-Standalone Manager Server"}
            foreach ($item in $items)
            {

                Remove-Item -Path "HKLM:\\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\$($item.PSChildName)"
            }
          }
      EOH
    guard_interpreter :powershell_script
  end

  remote_file "#{pkg_dir}\\XSMS_#{version}.zip" do
     source "#{art_url}/#{version}/#{node['xsm']['xsms']['artifact']}_#{version}.zip"
  	 not_if { ::File.exists?("#{pkg_dir}\\XSMS_#{version}.zip")}
  end

  powershell_script "Unziping XSMS new version " do
    code <<-EOH
      $Zipfile = "#{pkg_dir}\\XSMS_#{version}.zip"
      $Destination = "#{pkg_dir}\\XSMS_#{version}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
      guard_interpreter :powershell_script
    not_if { ::File.directory?("#{pkg_dir}\\XSMS_#{version}")}
  end

  #Apply template: Setup.iss
  template "#{pkg_dir}\\XSMS_#{version}\\install_xsms_#{version}.iss" do
    source "xsm/xsms/install_xsms_#{version}.iss.erb"
  end

  #Installing XSMS for Windows.
  execute "Install XSMS new Version" do
    command "\"#{pkg_dir}\\XSMS_#{version}\\setup.exe\" /s /f1\"#{pkg_dir}\\XSMS_#{version}\\install_xsms_#{version}.iss\""
  end

  report_app_installed_v2 'reporting XSMS installed' do
      appname 'XSMS'
      version version
      path node['xsm']['xsms']['folder']
      details "XSMS"
      action :send
  end

end

#####################################################
# FTP Data Generator Installation
#####################################################
if node['xsm']['ftpdg']['install']

  node.default['deploy']['runstatus']="XSM - FTP Data Generator - Start Installation."

  ftpdg_pkg_dir_prev = "#{node['xsm']['artifacts_dir']}\\#{version}\\ftpdg_prev"
  ftpdg_prev_version = node['xsm']['ftpdg']['prev_version']

  directory ftpdg_pkg_dir_prev do
    action :create
    not_if { ::File.directory?(ftpdg_pkg_dir_prev)}
  end

  #download previous version
  remote_file "#{ftpdg_pkg_dir_prev}\\FTPDG_#{ftpdg_prev_version}.zip" do
   source "#{art_url}/#{ftpdg_prev_version}/#{node['xsm']['ftpdg']['artifact']}_#{ftpdg_prev_version}.zip"
   not_if { ::File.exists?("#{ftpdg_pkg_dir_prev}\\FTPDG_#{ftpdg_prev_version}.zip")}
  end

  powershell_script "Unziping previous version " do
    code <<-EOH
      $Zipfile = "#{ftpdg_pkg_dir_prev}\\FTPDG_#{ftpdg_prev_version}.zip"
      $Destination = "#{ftpdg_pkg_dir_prev}\\FTPDG_#{ftpdg_prev_version}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
      guard_interpreter :powershell_script
    not_if { ::File.directory?("#{ftpdg_pkg_dir_prev}\\FTPDG_#{ftpdg_prev_version}")}
  end

  powershell_script "Uninstall previous version" do
    code <<-EOH
          $app = Get-WmiObject -Class Win32_Product | Where-Object {
            $_.Name -match "#{node['xsm']['ftpdg']['nametouninstall']}"
          }

          if($app)
          {
            $app.Uninstall()

            $Registry_Key = "HKLM:\\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\"
            $items = Get-ChildItem $Registry_Key | Where-Object {$_.GetValue("DisplayName") -match "Xpert-Standalone Manager Server"}
            foreach ($item in $items)
            {

                Remove-Item -Path "HKLM:\\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\$($item.PSChildName)"
            }
          }
      EOH
    guard_interpreter :powershell_script
  end

  remote_file "#{pkg_dir}\\FTPDG_#{version}.zip" do
     source "#{art_url}/#{version}/#{node['xsm']['ftpdg']['artifact']}_#{version}.zip"
  	 not_if { ::File.exists?("#{pkg_dir}\\FTPDG_#{version}.zip")}
  end

  powershell_script "Unziping new version " do
    code <<-EOH
      $Zipfile = "#{pkg_dir}\\FTPDG_#{version}.zip"
      $Destination = "#{pkg_dir}\\FTPDG_#{version}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
      guard_interpreter :powershell_script
    not_if { ::File.directory?("#{pkg_dir}\\FTPDG_#{version}")}
  end

  #Apply template: Setup.iss
  template "#{pkg_dir}\\FTPDG_#{version}\\install_ftpdg_#{version}.iss" do
    source "xsm/ftpdatagenerator/install_ftpdg_#{version}.iss.erb"
  end

  #Installing for Windows.
  execute "Install new Version" do
    command "\"#{pkg_dir}\\FTPDG_#{version}\\setup.exe\" /s /f1\"#{pkg_dir}\\FTPDG_#{version}\\install_ftpdg_#{version}.iss\""
  end

  report_app_installed_v2 'reporting FTPDataGenerator installed' do
      appname 'FTPDataGenerator'
      version version
      path node['xsm']['ftpdg']['folder']
      details "FTPDataGenerator"
      action :send
  end


end
