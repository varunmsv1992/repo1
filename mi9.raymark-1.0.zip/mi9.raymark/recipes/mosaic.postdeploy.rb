# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.postupdate
# Backup current system.
# Copyright (c) 2015 Mi9 Retail, All Rights Reserved.

# actions
# – Delete last backup folders
# - Delete folders in Artifacts_depository

#**********************************************
# – Delete last backup folders
#**********************************************

#delete folders in Artifacts_depository
ruby_block "Delete folders in Artifacts_depository" do
	block do
		FileUtils.rm_rf(Dir.glob("#{node['mosaic']['artifacts_dir']}/*"))
  end
	action :run
  only_if {node['mosaic']['remove_artifacts']}
end

ruby_block 'Get_Normal_Attributes_Before_Remove' do
  block do
     node.default['mosaic']['email']['to']=node['mosaic']['email']['to']
     node.default['deploy']['email']['to']=node['deploy']['email']['to']
  end
end

ruby_block "Delete normal attributes" do
	block do
		node.rm_normal('mosaic')
		node.rm_normal('config')
    node.rm_normal('deploy')
    node.rm_normal('xpert')
    node.rm_normal('xsmc')
    node.rm_normal('sql_server')
    node.rm_normal('xsm')
  end
	action :run
end
