#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.wf.install
#s
# Copyright (c) 2016 Mi9 Retail, All Rights Reserved.

# actions
# – Add Windows Features
# –- IIS and its components
#

# Declaring Variables
# Declaring Resources

#Install IIS (WebServer)
powershell_script 'Install IIS' do
  code 'Add-WindowsFeature Web-Server'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Server).InstallState -eq 'Installed'"
end

service 'w3svc' do
  action [:enable, :start]
end

#powershell_script '' do
#  code 'Add-windowsFeature '
#  guard_interpreter :powershell_script
#  not_if "(Get-WindowsFeature -Name ).InstallState -eq 'Installed'"
#end

#Web-Common-Http
powershell_script 'Web-Common-Http' do
  code 'Add-windowsFeature Web-Common-Http'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Common-Http).InstallState -eq 'Installed'"
end

#Web-Default-Doc
powershell_script 'Web-Default-Doc' do
  code 'Add-windowsFeature Web-Default-Doc'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Default-Doc).InstallState -eq 'Installed'"
end

#Web-Dir-Browsing
powershell_script 'Web-Dir-Browsing' do
  code 'Add-windowsFeature Web-Dir-Browsing'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Dir-Browsing).InstallState -eq 'Installed'"
end

#Web-Http-Errors
powershell_script 'Web-Http-Errors' do
  code 'Add-windowsFeature Web-Http-Errors'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Http-Errors).InstallState -eq 'Installed'"
end

#Web-Static-Content
powershell_script 'Web-Static-Content' do
  code 'Add-windowsFeature Web-Static-Content'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Static-Content).InstallState -eq 'Installed'"
end

#Web-Http-Redirect
powershell_script 'Web-Http-Redirect' do
  code 'Add-windowsFeature Web-Http-Redirect'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Http-Redirect).InstallState -eq 'Installed'"
end

###Web-Health
powershell_script 'Web-Health' do
  code 'Add-windowsFeature Web-Health'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Health).InstallState -eq 'Installed'"
end

#Web-Http-Logging
powershell_script 'Web-Http-Logging' do
  code 'Add-windowsFeature Web-Http-Logging'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Http-Logging).InstallState -eq 'Installed'"
end

#Web-Log-Libraries
powershell_script 'Web-Log-Libraries' do
  code 'Add-windowsFeature Web-Log-Libraries'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Log-Libraries).InstallState -eq 'Installed'"
end

#Web-Request-Monitor
powershell_script 'Web-Request-Monitor' do
  code 'Add-windowsFeature Web-Request-Monitor'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Request-Monitor).InstallState -eq 'Installed'"
end

#Web-Performance
powershell_script 'Web-Performance' do
  code 'Add-windowsFeature Web-Performance'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Performance).InstallState -eq 'Installed'"
end

#Web-Stat-Compression
powershell_script 'Web-Stat-Compression' do
  code 'Add-windowsFeature Web-Stat-Compression'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Stat-Compression).InstallState -eq 'Installed'"
end

#Web-Dyn-Compression
powershell_script 'Web-Dyn-Compression' do
  code 'Add-windowsFeature Web-Dyn-Compression'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Dyn-Compression).InstallState -eq 'Installed'"
end

#Web-Security
powershell_script 'Web-Security' do
  code 'Add-windowsFeature Web-Security'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Security).InstallState -eq 'Installed'"
end

#Web-Filtering
powershell_script 'Web-Filtering' do
  code 'Add-windowsFeature Web-Filtering'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Filtering).InstallState -eq 'Installed'"
end

#Web-Basic-Auth
powershell_script 'Web-Basic-Auth' do
  code 'Add-windowsFeature Web-Basic-Auth'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Basic-Auth).InstallState -eq 'Installed'"
end

#Web-Client-Auth
powershell_script 'Web-Client-Auth' do
  code 'Add-windowsFeature Web-Client-Auth'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Client-Auth).InstallState -eq 'Installed'"
end

#Web-Digest-Auth
powershell_script 'Web-Digest-Auth' do
  code 'Add-windowsFeature Web-Digest-Auth'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Digest-Auth).InstallState -eq 'Installed'"
end
=begin
#Web-Cert-Auth
powershell_script 'Web-Cert-Auth' do
  code 'Add-windowsFeature Web-Cert-Auth'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Cert-Auth).InstallState -eq 'Installed'"
end

#Web-IP-Security
powershell_script 'Web-IP-Security' do
  code 'Add-windowsFeature Web-IP-Security'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-IP-Security).InstallState -eq 'Installed'"
end

#Web-Url-Auth

powershell_script 'Web-Url-Auth' do
  code 'Add-windowsFeature Web-Url-Auth'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Url-Auth).InstallState -eq 'Installed'"
end
=end

#Web-Windows-Auth
powershell_script 'Web-Windows-Auth' do
  code 'Add-windowsFeature Web-Windows-Auth'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Windows-Auth).InstallState -eq 'Installed'"
end

#Web-App-Dev
powershell_script 'Web-App-Dev' do
  code 'Add-windowsFeature Web-App-Dev'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-App-Dev).InstallState -eq 'Installed'"
end

#Web-Net-Ext
powershell_script 'Web-Net-Ext' do
  code 'Add-windowsFeature Web-Net-Ext'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Net-Ext).InstallState -eq 'Installed'"
end

#Web-Net-Ext45
powershell_script 'Web-Net-Ext45' do
  code 'Add-windowsFeature Web-Net-Ext45'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Net-Ext45).InstallState -eq 'Installed'"
end
=begin
#Web-ASP
powershell_script 'Web-ASP' do
  code 'Add-windowsFeature Web-ASP'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-ASP).InstallState -eq 'Installed'"
end

#Web-Asp-Net
powershell_script 'Web-Asp-Net' do
  code 'Add-windowsFeature Web-Asp-Net'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Asp-Net).InstallState -eq 'Installed'"
end
=end

#Web-Asp-Net45
powershell_script 'Web-Asp-Net45' do
  code 'Add-windowsFeature Web-Asp-Net45'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Asp-Net45).InstallState -eq 'Installed'"
end
=begin
#Web-CGI
powershell_script 'Web-CGI' do
  code 'Add-windowsFeature Web-CGI'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-CGI).InstallState -eq 'Installed'"
end
=end

#Web-ISAPI-Ext
powershell_script 'Web-ISAPI-Ext' do
  code 'Add-windowsFeature Web-ISAPI-Ext'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-ISAPI-Ext).InstallState -eq 'Installed'"
end

#Web-ISAPI-Filter
powershell_script 'Web-ISAPI-Filter' do
  code 'Add-windowsFeature Web-ISAPI-Filter'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-ISAPI-Filter).InstallState -eq 'Installed'"
end

#Web-Mgmt-Tools
powershell_script 'Web-Mgmt-Tools' do
  code 'Add-windowsFeature Web-Mgmt-Tools'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Mgmt-Tools).InstallState -eq 'Installed'"
end

#Web-Mgmt-Console
powershell_script 'Web-Mgmt-Console' do
  code 'Add-windowsFeature Web-Mgmt-Console'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Mgmt-Console).InstallState -eq 'Installed'"
end

#Web-Mgmt-Compat
powershell_script 'Web-Mgmt-Compat' do
  code 'Add-windowsFeature Web-Mgmt-Compat'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Mgmt-Compat).InstallState -eq 'Installed'"
end

#Web-Metabase
powershell_script 'Web-Metabase' do
  code 'Add-windowsFeature Web-Metabase'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Metabase).InstallState -eq 'Installed'"
end

#Web-Lgcy-Mgmt-Console
powershell_script 'Web-Lgcy-Mgmt-Console' do
  code 'Add-windowsFeature Web-Lgcy-Mgmt-Console'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Lgcy-Mgmt-Console).InstallState -eq 'Installed'"
end
=begin
#Web-Lgcy-Scripting
powershell_script 'Web-Lgcy-Scripting' do
  code 'Add-windowsFeature Web-Lgcy-Scripting'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Lgcy-Scripting).InstallState -eq 'Installed'"
end

#Web-WMI
powershell_script 'Web-WMI' do
  code 'Add-windowsFeature Web-WMI'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-WMI).InstallState -eq 'Installed'"
end
=end
#Web-Scripting-Tools
powershell_script 'Web-Scripting-Tools' do
  code 'Add-windowsFeature Web-Scripting-Tools'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Scripting-Tools).InstallState -eq 'Installed'"
end

=begin
#Web-Mgmt-Service
powershell_script 'Web-Mgmt-Service' do
  code 'Add-windowsFeature Web-Mgmt-Service'
  guard_interpreter :powershell_script
  not_if "(Get-WindowsFeature -Name Web-Mgmt-Service).InstallState -eq 'Installed'"
end
=end


powershell_script 'Installing AppPools for Mosaic' do
code <<-EOH
  $succeeded = import-module WebAdministration
  if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
    #Could not import, trying to snapin
    add-pssnapin WebAdministration
  }

  $AppPools = "CRAService.Mosaic","mosaicservice","POSController_40","posservice"

  Foreach($AppPool in $AppPools)
  {
    $AppPoolPath = "IIS:\\AppPools\\$AppPool"
    if (!(Test-Path $AppPoolPath -pathType container))
    {
      #create the app pool
      $pool = New-Item $AppPoolPath

      $pool = get-itemproperty $AppPoolPath
      $pool.managedRuntimeVersion= "v4.0"
      $pool.enable32BitAppOnWin64 = 1
      $pool.processModel.Identity
      $pool.processModel.identityType = 4;
      $pool | Set-Item
      $pool.Stop();
      $pool.Start();

    }

  }
EOH
guard_interpreter :powershell_script
not_if { 1!=1}
end
