#
# Cookbook Name:: mi9.raymark
# Recipe:: xpert.labelprinting.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="xpert_labelprinting_start"

ruby_block "verify HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'xpert_labelprinting_verify'
      if node['filesystem']['C:']['kb_available']< node['xpert']['labelprinting']['min_kb_available']
          fail "The HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

if node['xpert']['labelprinting']['rollback']['xpert']
  raymark_rollback 'Rollback_backup_xpert_labelprinting_folder' do
    backup_folder node['xpert']['labelprinting']['backup']['dir']
    action :nothing
  end

  directory 'Delete_folders_in_XPERT_Labelprinting'  do
    path node['xpert']['labelprinting']['path']
    recursive true
  	action :nothing
  end

  powershell_script "Restoring_XPERT_Labelprinting_folders" do
    code <<-EOH
      $Zipfile = "#{node['xpert']['labelprinting']['backup']['dir']}\\#{node['xpert']['labelprinting']['backup']['zip']}"
      $Destination = "#{node['xpert']['labelprinting']['path']}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
    guard_interpreter :powershell_script
    action :nothing
    only_if { node['xpert']['labelprinting']['backup']['dir'] and ::File.directory?(node['xpert']['labelprinting']['path']) }
  end
end

if node['xpert']['labelprinting']['backup']['xpert']

  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="xpert_labelprinting_backup"
    end
  end

  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['xpert']['backup']['maindir']
    backup_folder node['xpert']['labelprinting']['backup']['dir']
    action :backup
  end

  powershell_script "Backup Xpert" do
    code <<-EOH
  					[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
  					$src_folder = "#{node['xpert']['labelprinting']['path']}"
  					$destfile = "#{node['xpert']['labelprinting']['backup']['dir']}\\#{node['xpert']['labelprinting']['backup']['zip']}"
  					$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
  					$includebasedir = $false
  					[System.IO.Compression.ZipFile]::CreateFromDirectory($src_folder,$destfile,$compressionLevel, $includebasedir )
      EOH
    guard_interpreter :powershell_script
    only_if { node['xpert']['labelprinting']['backup']['xpert'] and ::File.directory?(node['xpert']['labelprinting']['path']) }
  end
end

#make update
ruby_block "make xpert labelprinting update" do
  block do
      node.default['deploy']['runstatus']="xpert_labelprinting_update"
      Chef.run_context.include_recipe 'mi9.raymark::xpert.labelprinting.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="Xpert Labelprinting deploy Successfully\n"
  end
end

#delete backup wsdir_last folder
directory 'delete backup Xpert dir_last folder'  do
  puts "Deleting #{node['xpert']['labelprinting']['backup']['dir']}_last"
	path "#{node['xpert']['labelprinting']['backup']['dir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['xpert']['labelprinting']['backup']['dir']}_last")}
end
