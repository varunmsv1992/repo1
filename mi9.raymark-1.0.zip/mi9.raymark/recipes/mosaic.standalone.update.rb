#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.db.update
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#
# actions
# - Download actifacts
# - Update standalone database
# - Run Scripts


#**********************************************
# - Update standalone database
#**********************************************
pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"
version = node['mosaic']['version']
art_url = node['mosaic']['depository_url']

#**********************************************
# – Creating pkg_dir folder if it not exits
#**********************************************
directory 'Create pkg_dir folder' do
	path pkg_dir
  action :create
  not_if { ::File.directory?(pkg_dir) }
end

#download database
remote_file "#{pkg_dir}\\standalone_#{node['mosaic']['customer_name']}_#{node['mosaic']['version']}.zip" do
 atomic_update true
 source "#{art_url}/#{version}/standalone_#{node['mosaic']['customer_name']}_#{node['mosaic']['version']}.zip"
 #not_if { ::File.exists?("#{pkg_dir}\\standalone_#{node['mosaic']['customer_name']}_#{node['mosaic']['version']}.zip") or ::File.exists?("#{pkg_dir}\\standalone.bak") or !(node['mosaic']['standalone']['deploy'])}
 only_if { node['mosaic']['standalone']['deploy']}
end


=begin
#unzip download database
powershell_script "Unzip download database" do
  code <<-EOH
    $Zipfile = "#{pkg_dir}\\standalone_#{node['mosaic']['customer_name']}_#{node['mosaic']['version']}.zip"
    $Destination = "#{pkg_dir}"
    Add-Type -assembly "system.io.compression.filesystem"
    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
    EOH
  guard_interpreter :powershell_script
  not_if { ::File.exists?("#{pkg_dir}\\standalone.bak") or node['mosaic']['standalone']['deploy']=='false'}
end
=end

#unzip download database
powershell_script "Unzip download database" do
  code <<-EOH
    $Zipfile = "#{pkg_dir}\\standalone_#{node['mosaic']['customer_name']}_#{node['mosaic']['version']}.zip"
    $Destination = "#{pkg_dir}"
		$shell = new-object -com shell.application
		$zip = $shell.NameSpace($Zipfile)
		foreach($item in $zip.items())
		{
			$shell.Namespace($destination).copyhere($item,0x14)
		}
    EOH
  guard_interpreter :powershell_script
  #not_if { ::File.exists?("#{pkg_dir}\\standalone.bak") or !(node['mosaic']['standalone']['deploy'])}
	only_if { node['mosaic']['standalone']['deploy']}

end

#restore database
db_instance = node['mosaic']['sql_instance_name'].empty? ? node['mosaic']['sql_server'] : "#{node['mosaic']['sql_server']}\\#{node['mosaic']['sql_instance_name']}"
#db_instance = "#{node['mosaic']['server']}\\#{node['mosaic']['instance_name']}"

db_name = node['mosaic']['sql_db_name']

puts "#{db_instance}"
puts "#{node['mosaic']['sql_user']}"
puts "#{node['mosaic']['sql_pwd']}"
puts "#{pkg_dir}\\#{db_name}.bak"

powershell_script "Restoring database #{node['mosaic']['sql_db_name']}" do
	code <<-EOH
		## - Loads the SQL Server SMO Assembly:
		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
	  [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

		$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
		$sqlConn.ServerInstance="#{db_instance}"
	  $sqlConn.LoginSecure = $false
	  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
	  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

		$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
		$res = new-object Microsoft.SqlServer.Management.Smo.Restore
		## $backup = new-object Microsoft.SqlServer.Management.Smo.Backup
	  $server.KillAllProcesses("#{db_name}")
	  # $error[0]|format-list –force

		$found = $server.Databases.Contains("#{db_name}")

		$res.Devices.AddDevice("#{pkg_dir}\\#{db_name}.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
		$res.Database = "#{db_name}"
		$res.NoRecovery = $false
		$res.FileNumber = 1
		$res.ReplaceDatabase = $true;
		$smoRestoreDetails = $res.ReadFileList($server)

		foreach($r in $smoRestoreDetails.Rows)
		{
				$smoRestoreFile = New-Object("Microsoft.SqlServer.Management.Smo.RelocateFile")

				$smoRestoreFile.LogicalFileName = $r["LogicalName"]
			#	$smoRestoreFile.PhysicalFileName = $server.Information.MasterDBPath.ToString() +"\\"+ $r["PhysicalName"].Substring($r["PhysicalName"].LastIndexOf('\\')+1)
			  if ($r["Type"] -eq "D"){
					$smoRestoreFile.PhysicalFileName = $server.Information.MasterDBPath.ToString() +"\\standalone.mdf"
				}else{
					$smoRestoreFile.PhysicalFileName = $server.Information.MasterDBPath.ToString() +"\\standalone_log.ldf"
				}
				$res.RelocateFiles.Add($smoRestoreFile)
		}

		$res.SqlRestore($server)

	#  Write-Output $error[0]|format-list

	EOH
	guard_interpreter :powershell_script
	only_if { node['mosaic']['standalone']['deploy']}
end


powershell_script "Creating Standalone user" do
	code <<-EOH
	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

	$instanceName = "#{db_instance}"
	$loginName  = "#{node['mosaic']['standalone']['dbuser']}"
  $dbUserName = "#{node['mosaic']['standalone']['dbuser']}"
	$password   = "#{node['mosaic']['standalone']['dbpwd']}"

	$databasenames = "standalone"
	$roleNames =  @("db_owner","ADMIN")

  $sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
  $sqlConn.ServerInstance="#{db_instance}"
  $sqlConn.LoginSecure = $false
  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

  $server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)

	if (!$server.Logins.Contains($loginName))
	{
		$login = New-Object `
		-TypeName Microsoft.SqlServer.Management.Smo.Login `
		-ArgumentList $server, $loginName
		$login.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::SqlLogin
		$login.PasswordExpirationEnabled = $false
	  $login.PasswordPolicyEnforced = $false
		$login.Create($password)
		Write-Host("Login $loginName created successfully.")
  }

	foreach($databaseToMap in $databasenames)
	{
	    $database = $server.Databases[$databaseToMap]
    	if ($database.Users[$dbUserName])
	    {
	        Write-Host("Dropping user $dbUserName on $database.")
	        $database.Users[$dbUserName].Drop()
	    }
	    $dbUser = New-Object `
	    -TypeName Microsoft.SqlServer.Management.Smo.User `
	    -ArgumentList $database, $dbUserName
	    $dbUser.Login = $loginName
	    $dbUser.Create()
	    Write-Host("User $dbUser created successfully.")

	    #assign database role for a new user
			foreach ($roleName in $roleNames){
	        #assign database role for a new user
	        $dbrole = $database.Roles[$roleName]
	        $dbrole.AddMember($dbUserName)
	        $dbrole.Alter()
					Write-Host("User $dbUserName successfully added to $roleName role.")
      }

	}

EOH
guard_interpreter :powershell_script
only_if { node['mosaic']['standalone']['deploy']}
end

powershell_script "Creating sqladmin user" do
	code <<-EOH
	#import SQL Server module
	#Import-Module SQLPS -DisableNameChecking
	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

	$instanceName = "#{db_instance}"
	$loginName = "#{node['mosaic']['standalone']['admin_dbuser']}"
	$password = "#{node['mosaic']['standalone']['admin_dbpwd']}"

  $sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
  $sqlConn.ServerInstance="#{db_instance}"
  $sqlConn.LoginSecure = $false
  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

  $server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)

	if (!$server.Logins.Contains($loginName))
	{
		$login = New-Object `
		-TypeName Microsoft.SqlServer.Management.Smo.Login `
		-ArgumentList $server, $loginName
		$login.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::SqlLogin
		$login.PasswordExpirationEnabled = $false
	  $login.PasswordPolicyEnforced = $false
		$login.Create($password)
		$login.AddToRole("sysadmin")
		Write-Host("Login $loginName created successfully.")
  }

EOH
guard_interpreter :powershell_script
only_if { node['mosaic']['standalone']['deploy']}
end


###############################################################
#
#Running SQL Server scripts
###############################################################


#Download db files templates
remote_file 'download_standalone-scripts' do
  path "#{pkg_dir}\\standalone_db-scripts #{version}.zip"
	atomic_update true
  source "#{art_url}/#{version}/standalone_db-scripts #{version}.zip"
	#only_if { node['mosaic']['standalone']['initial_install']}
	only_if { node['mosaic']['standalone']['deploy']}
end

directory "#{pkg_dir}\\standalone_db-scripts #{version}" do
  recursive true
  action :delete
	only_if {::File.directory?("#{pkg_dir}\\standalone_db-scripts #{version}")}
end

powershell_script "Unziping standalone_db-scripts" do
  code <<-EOH
    $Zipfile = "#{pkg_dir}\\standalone_db-scripts #{version}.zip"
    $Destination = "#{pkg_dir}\\standalone_db-scripts #{version}"
    Add-Type -assembly "system.io.compression.filesystem"
    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
    EOH
    guard_interpreter :powershell_script
  #not_if { !(node['mosaic']['standalone']['initial_install']) ||(::File.directory?("#{pkg_dir}\\standalone_db-scripts #{version}") )}
	#not_if { (::File.directory?("#{pkg_dir}\\standalone_db-scripts #{version}") )}
	only_if { node['mosaic']['standalone']['deploy']}

end

ruby_block "Replacing & execute value in CERTIFICATE.sql" do
  block do
    text = File.read("#{pkg_dir}\\standalone_db-scripts #{version}\\CERTIFICATE.sql")
    new_contents = text.gsub("<Subscriber Database, sysname, SubscriberDB>", "Standalone")
    new_contents = new_contents.gsub("<Certificate Path, sysname, C:\\MSSQL\\Certificates>", "#{node['mosaic']['standalone']['cert_path']}")
    new_contents = new_contents.gsub("<DB Role, RoleName, public>", "public")
    # To merely print the contents of the file, use:
    #puts new_contents

    # To write changes to the file, use:
    File.open("#{pkg_dir}\\standalone_db-scripts #{version}\\CERTIFICATE.sql", "w") {|file| file.puts new_contents }

    puts "Running by first time"
    #Running by first time
		object = Chef::Resource::Execute.new("Script Certificate", run_context)
		object.returns [0,-1073741819]
		 object.command "\"#{node['windows']['sqlcmd_path_exe']}\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{pkg_dir}\\standalone_db-scripts #{version}\\CERTIFICATE.sql\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_certificate.txt\""
		#object.command "\"Sqlcmd\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{pkg_dir}\\standalone_db-scripts #{version}\\CERTIFICATE.sql\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_certificate.txt\""
		object.run_action :run

    puts "Running by second time"
    #Running by second time
		object = Chef::Resource::Execute.new("Script Certificate", run_context)
		object.returns [0,-1073741819]
		object.command "\"#{node['windows']['sqlcmd_path_exe']}\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{pkg_dir}\\standalone_db-scripts #{version}\\CERTIFICATE.sql\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_certificate.txt\""
    #object.command "\"Sqlcmd\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{pkg_dir}\\standalone_db-scripts #{version}\\CERTIFICATE.sql\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_certificate.txt\""
		object.run_action :run

  end
	#only_if { node['mosaic']['standalone']['initial_install']}
	only_if { node['mosaic']['standalone']['deploy']}
end

ruby_block "Replacing & execute value in DS_SyncLine_Settings.sql" do
  block do
    text = File.read("#{pkg_dir}\\standalone_db-scripts #{version}\\DS_SyncLine_Settings.sql")
    new_contents = text.gsub("<Http Address, sysname, http://>", "#{node['mosaic']['standalone']['ds_syncline_settings']['http_address']}")
		new_contents = new_contents.gsub("80", "#{node['mosaic']['standalone']['ds_syncline_settings']['http_port']}")
    new_contents = new_contents.gsub("<Ftp Address, sysname, ftp://>", "#{node['mosaic']['standalone']['ds_syncline_settings']['ftp_address']}")
		new_contents = new_contents.gsub("21", "#{node['mosaic']['standalone']['ds_syncline_settings']['ftp_port']}")
		new_contents = new_contents.gsub("<ftp user, sysname, username>", "#{node['mosaic']['standalone']['ds_syncline_settings']['ftp_user']}")
		new_contents = new_contents.gsub("<ftp password, sysname, password>", "#{node['mosaic']['standalone']['ds_syncline_settings']['ftp_password']}")


    # To merely print the contents of the file, use:
    #puts new_contents

    # To write changes to the file, use:
    File.open("#{pkg_dir}\\standalone_db-scripts #{version}\\DS_SyncLine_Settings.sql", "w") {|file| file.puts new_contents }

		object = Chef::Resource::Execute.new("Script Certificate", run_context)
		object.command "\"#{node['windows']['sqlcmd_path_exe']}\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{pkg_dir}\\standalone_db-scripts #{version}\\DS_SyncLine_Settings.sql\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_DS_SyncLine_Settings.txt\""
		#object.command "\"Sqlcmd\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{pkg_dir}\\standalone_db-scripts #{version}\\DS_SyncLine_Settings.sql\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_DS_SyncLine_Settings.txt\""
		object.run_action :run

  end
	#only_if { node['mosaic']['standalone']['initial_install']}
	only_if { node['mosaic']['standalone']['deploy']}
end

=begin
ruby_block "Replacing & execute value in XSM_Load_Newer_Session_Transactions.sql" do
  block do
    text = File.read("#{pkg_dir}\\standalone_db-scripts #{version}\\XSM_Load_Newer_Session_Transactions.sql")
		new_contents = text.gsub("<centraldbserver, sysname,ITSXSMCSYNC1>", "#{node['mosaic']['standalone']['centraldbserver']}")
    new_contents = new_contents.gsub("<centraldbuser, sysname,sa>", "#{node['mosaic']['standalone']['centraldbuser']}")
    new_contents = new_contents.gsub("<centraldbpwd, sysname,Raym5460>", "#{node['mosaic']['standalone']['centraldbpwd']}")
    new_contents = new_contents.gsub("<centraldbsource, sysname,ItSugar>", "#{node['mosaic']['standalone']['centraldbsource']}")

    # To merely print the contents of the file, use:
    #puts new_contents

    # To write changes to the file, use:
    File.open("#{pkg_dir}\\standalone_db-scripts #{version}\\XSM_Load_Newer_Session_Transactions.sql", "w") {|file| file.puts new_contents }

		object = Chef::Resource::Execute.new("Script Certificate", run_context)
		object.command "\"#{node['windows']['sqlcmd_path']}\\Sqlcmd.exe\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{pkg_dir}\\standalone_db-scripts #{version}\\XSM_Load_Newer_Session_Transactions.sql\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_XSM_Load_Newer_Session_Transactions.txt\""
		object.run_action :run

  end
	#only_if { node['mosaic']['standalone']['initial_install']}
	only_if { node['mosaic']['standalone']['deploy']}
end
=end

ruby_block "Executing scripts" do
  block do
    #Running store procedure scripts located in db-scripts
    if ( ::File.directory?("#{pkg_dir}\\standalone_db-scripts #{version}"))
      path = "#{pkg_dir}\\standalone_db-scripts #{version}"
      path = path.gsub /\\+/, '/'
      scripts = Dir.glob("#{path}/*.sql").sort
      i= 0
      scripts.each do |script|
      #Dir.glob("#{pkg_dir}/db-scripts #{version}/*.sql").sort do |script|
        puts "#{script}"
        next if script == '.' or script == '..' or script == 'Certificate.sql' or script == 'DS_SyncLine_Settings.sql' or script =='XSM_Load_Newer_Session_Transactions.sql'
          object = Chef::Resource::Execute.new("Script #{script}", run_context)
          object.command "\"#{node['windows']['sqlcmd_path_exe']}\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{script}\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_#{i}.txt\""
				#	object.command "\"Sqlcmd\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{script}\" -o \"#{pkg_dir}\\standalone_db-scripts #{version}\\out_#{i}.txt\""
          object.run_action :run

        #execute "Script #{script}" do
        #  command "\"#{node['windows']['sqlcmd_path']}\\Sqlcmd.exe\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{script}\" -o \"#{pkg_dir}\\db-scripts #{version}\\out_#{i}.txt\""
        #end
        i = i + 1
      end
    end
  end
	only_if { node['mosaic']['standalone']['deploy']}
end

ruby_block "Concatening output files" do
  block do
    if ( ::File.directory?("#{pkg_dir}\\standalone_db-scripts #{version}"))
      path = "#{pkg_dir}\\standalone_db-scripts #{version}"
      path = path.gsub /\\+/, '/'
      outputs = Dir.glob("#{path}/out_*.txt").sort
      hole_content = ""
      outputs.each do |output|
        next if output == '.' or output == '..'
        file = File.open("#{output}", "rb")
        nextContents = file.read
        hole_content = hole_content + nextContents
      end
      File.open("#{pkg_dir}\\standalone_db-scripts #{version}\\#{node['mosaic']['db']['execution_result_filename'] }", "w") {|file| file.puts hole_content }
    end

  end
	only_if {node['mosaic']['standalone']['deploy']}
end
