#Common actions for all recipies
node.default['windows']['temp_dir']=MI9Utils::Utils.get_windows_temp_folder()

pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"
version = node['mosaic']['version']
profile = node['mosaic']['profile']

configzip = "configs #{version} #{profile}.zip"

art_url = node['mosaic']['depository_url']
#Creating windows temp dir
directory node['windows']['temp_dir'] do
  action :create
  not_if { ::File.directory?(node['windows']['temp_dir'])}
end

#Creating artifacts_dir folder
directory node['mosaic']['artifacts_dir'] do
  action :create
  not_if { ::File.directory?(node['mosaic']['artifacts_dir'])}
end

#Creating pkg_dir folder
directory pkg_dir do
  action :create
  not_if { ::File.directory?(pkg_dir)}
end

#Download Configs files templates
if (node['roles'].include?('rm_webservice') or node['roles'].include?('rm_affinity') or node['roles'].include?('rm_pos'))

  remote_file 'download_configs' do
    path "#{pkg_dir}\\#{configzip}"
    atomic_update true
    source "#{art_url}/#{version}/#{configzip}"
  end

  directory "#{pkg_dir}\\configs #{version}" do
    action :create
    not_if { ::File.directory?("#{pkg_dir}\\configs #{version}")}
  end

  powershell_script "Unziping #{configzip}" do
    code <<-EOH
      # $Zipfile = "#{pkg_dir}\\#{configzip}"
      # $Destination = "#{pkg_dir}\\configs #{version}"
      #Add-Type -assembly "system.io.compression.filesystem"
      #[io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)

      $Zipfile = "#{pkg_dir}\\#{configzip}"
      $Destination = "#{pkg_dir}\\configs #{version}"
      $shell = new-object -com shell.application
      $zip = $shell.NameSpace($Zipfile)
      foreach($item in $zip.items())
      {
        $shell.Namespace($Destination).copyhere($item,0x14)
      }
      EOH
      guard_interpreter :powershell_script
    only_if { ::File.directory?("#{pkg_dir}\\configs #{version}")}
  end
end
