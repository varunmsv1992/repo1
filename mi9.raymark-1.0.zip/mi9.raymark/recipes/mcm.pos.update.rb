#
# Cookbook Name:: mi9.raymark
# Recipe:: mcm.pos.update
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute

# actions
# - Download actifacts
# - Preparing update
# - stop serice
# – Update mcm
# - start service


#**********************************************
# - Download actifacts
#**********************************************
#mcm .zip

pkg_dir = "#{node['mcm']['artifacts_dir']}\\#{node['mcm']['version']}"
version = node['mcm']['version']
art_url = node['mcm']['depository_url']

#Creating pkg_dir
directory pkg_dir do
  action :create
  not_if { ::File.directory?(pkg_dir)}
end

node['mcm']['pos']['artifacts'].each do |art|
  puts "Downloading #{art}#{version}.zip"
  artEncoded = art.dup
  if art_url.include? "http"
    artEncoded = artEncoded.gsub! ' ', '%20'
    artEncoded = artEncoded.nil? ? art : artEncoded
  end
  remote_file "#{pkg_dir}\\#{art}#{version}.zip" do
   source "#{art_url}/#{version}/#{artEncoded}#{version}.zip"
	#not_if { ::File.exists?("#{pkg_dir}\\#{art}#{version}.zip")}
  end
end

#**********************************************
# - Preparing update
#**********************************************

node['mcm']['pos']['artifacts'].each do |art|
  puts "Unzipping #{art}"
  directory "#{pkg_dir}\\#{art}#{version}" do
    recursive true
    action :delete
  	only_if {::File.directory?("#{pkg_dir}\\#{art}#{version}")}
  end
	powershell_script "Unziping artifact #{art}#{version}.zip" do
	  code <<-EOH
      $Zipfile = "#{pkg_dir}\\#{art}#{version}.zip"
			$Destination = "#{pkg_dir}\\#{art}#{version}"
	    Add-Type -assembly "system.io.compression.filesystem"
	    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
	    EOH
	    guard_interpreter :powershell_script
	  #not_if { ::File.directory?("#{pkg_dir}\\#{art}#{version}")}
	end

end

=begin
ruby_block 'Backup License.dat' do
  block do
    FileUtils.cp "#{node['mcm']['pos']['path']}\\License.dat","#{pkg_dir}/License.dat"
  end
  only_if { ::File.file?("#{node['mcm']['pos']['path']}\\License.dat")}
end
=end

#Creating phisical folders to store the websites
directory node['mcm']['pos']['path'] do
  recursive true
  action :create
	not_if {::File.directory?(node['mcm']['pos']['path'])}
end


#**********************************************
# – Update mcm
#**********************************************


windows_service 'CDCA Multi Client' do #CDCA Multi Client
  action :stop
end

powershell_script "Close MCM app" do
  code <<-EOH
    try{
					$process = Get-Process "Multi" -ErrorAction Stop
					if ($process -ne $Null -and $process -ne ''){
								 Get-Process "Multi" | stop-process
					}
    }catch [System.Exception] {
        Write-Output $_.Exception.Message
    }
    EOH
  guard_interpreter :powershell_script
end

#Update files
ruby_block 'Copy mcm files' do
  block do
    FileUtils.cp_r "#{pkg_dir}/MCM_EMV_Update_Kit-#{version}/.",node['mcm']['pos']['path']
  end
#  only_if { ::Dir.entries(node['mcm']['pos']['path']) == ['.', '..']} #if the folder is empty
only_if {::File.directory?(node['mcm']['pos']['path'])}
end

windows_service 'CDCA Multi Client' do
  action :start
end
