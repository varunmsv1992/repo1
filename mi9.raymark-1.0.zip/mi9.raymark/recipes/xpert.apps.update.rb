#
# Cookbook Name:: mi9.raymark
# Recipe:: xsmc.pos.update
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute

# actions
# - Download actifacts
# - Preparing update
# – Update xsmc


#**********************************************
# - Download actifacts
#**********************************************
#xsmc .zip

pkg_dir = "#{node['xpert']['artifacts_dir']}"

#version = node['xsmc']['version']
art_url = node['xpert']['depository_url']

#Creating pkg_dir/xsmc folder
directory pkg_dir do
  action :create
  not_if { ::File.directory?(pkg_dir)}
end


node['xpert']['Apps']['Installers'].each do |app|
  puts "Downloading #{app}"
  puts node[:xpert][:Apps][:"#{app}"][:app_name]

  art =node[:xpert][:Apps][:"#{app}"][:app_name]
  art ="#{art} "
  artEncoded = art.dup
  if art_url.include? "http"
    artEncoded = artEncoded.gsub! ' ', '%20'
    artEncoded = artEncoded.nil? ? art : artEncoded
  end
  version = node[:xpert][:Apps][:"#{app}"][:version]
	remote_file "#{pkg_dir}\\#{art}#{version}.zip" do
   source "#{art_url}/#{artEncoded}#{version}.zip"
	 not_if { ::File.exists?("#{pkg_dir}\\#{art}#{version}.zip")}
  end

end

node['xpert']['Apps']['Installers'].each do |app|
  puts "Downloading #{app}"
  puts node[:xpert][:Apps][:"#{app}"][:app_name]

  art =node[:xpert][:Apps][:"#{app}"][:app_name]
  art ="#{art} "
  artEncoded = art.dup
  version = node[:xpert][:Apps][:"#{app}"][:version]
  powershell_script "Unzipping artifact #{art} " do
    code <<-EOH
      $Zipfile = "#{pkg_dir}\\#{art}#{version}.zip"
      $Destination = "#{pkg_dir}\\#{art}#{version}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
      guard_interpreter :powershell_script
    not_if { ::File.directory?("#{pkg_dir}\\#{art}#{version}")}
  end
end


#**********************************************
# – Update xpert apps
#**********************************************
node['xpert']['Apps']['Installers'].each do |app|
  app_name = node[:xpert][:Apps][:"#{app}"][:app_name]
  acronym = node[:xpert][:Apps][:"#{app}"][:acronym_name]
  art = "#{app_name} "
  version = node[:xpert][:Apps][:"#{app}"][:version]

  deploy_xpertapplication "#{app_name}" do
    acronym_name "#{acronym}"
    version "#{version}"
    installer_dir "#{pkg_dir}/#{art}#{version}"
    action :deployapp
    only_if { node[:xpert][:Apps][:"#{app}"][:install]}
  end

end
