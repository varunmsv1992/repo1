#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.webservice.update
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute

# actions
# - Download actifacts
# - Preparing update
# – Update CRA
# - Update POS Web service Public-REST
# - Update POS Web Service-REST
# - Update POSPeripherals Web Service-REST
# – Update Mosaic
# - Update Backoffice

#**********************************************
# - Download actifacts
#**********************************************
#CRA Web Service .zip
#POS Web Service Public-REST .zip
#POS Web Service-REST .zip
#POSPeripherals Web Service-REST .zip

pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"
version = node['mosaic']['version']
art_url = node['mosaic']['depository_url']

download_installers 'artifacts' do
    dest_dir pkg_dir
    artifacts node['mosaic']['webservice']['artifacts']
    version node['mosaic']['version']
    art_url node['mosaic']['depository_url']
    action [:download,:unzip]
end

#Creating phisical folders to store the websites
directory node['mosaic']['webservice']['iis_root_env'] do
  recursive true
  action :create
	not_if {::File.directory?(node['mosaic']['webservice']['iis_root_env']) or node['mosaic']['webservice']['iis_publication_type']=='simple'}
end


#Restarting IIS
powershell_script 'Restart IIS' do
	code <<-EOH
    invoke-command -scriptblock {iisreset}
		EOH
	guard_interpreter :powershell_script
	only_if { node['mosaic']['restart_iis']== 'true'}
end

#**********************************************
# – Update CRA
#**********************************************
puts node['mosaic']['version']
deploy_webservice 'CRA' do
  physical_path node['mosaic']['webservice']['CRA']['physical_path']
  pub_name node['mosaic']['webservice']['CRA']['pub_name']
  app_pool_name node['mosaic']['webservice']['CRA']['app_pool_name']
  appversion node['mosaic']['version']
  installer_dir "#{pkg_dir}/CRA Web Service #{version}/craservice.mosaic"
  config_template_file "#{pkg_dir}\\configs #{version}\\webservices\\CRA_Web_Service_Web.config.erb"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deployws
  only_if { node['mosaic']['webservice']['CRA']['install']}
end

#**********************************************
# - Update POS Web service Public-REST
#**********************************************
deploy_webservice 'POSServicePublicREST' do
  physical_path node['mosaic']['webservice']['POSWSPublicREST']['physical_path']
  pub_name node['mosaic']['webservice']['POSWSPublicREST']['pub_name']
  app_pool_name node['mosaic']['webservice']['POSWSPublicREST']['app_pool_name']
  appversion node['mosaic']['version']
  installer_dir "#{pkg_dir}/POS Web service Public-REST #{version}/posservicepublic.rest"
  config_template_file "#{pkg_dir}\\configs #{version}\\webservices\\POS_Web_Service_Public-REST_Web.config.erb"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deployws
  only_if { node['mosaic']['webservice']['POSWSPublicREST']['install']}
end


#**********************************************
# - Update POS Web Service-REST
#**********************************************
deploy_webservice 'POSservice' do
  physical_path node['mosaic']['webservice']['POSservice']['physical_path']
  pub_name node['mosaic']['webservice']['POSservice']['pub_name']
  app_pool_name node['mosaic']['webservice']['POSservice']['app_pool_name']
  appversion node['mosaic']['version']
  installer_dir "#{pkg_dir}/POS Web Service-REST #{version}/posservice.rest"
  config_template_file "#{pkg_dir}\\configs #{version}\\webservices\\POS_Web_Service-REST_Web.config.erb"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deployws
  only_if { node['mosaic']['webservice']['POSservice']['install']}
end

ruby_block 'move Epayment dlls' do
  block do
    temp_pss_physical_path = node['mosaic']['webservice']['POSservice']['physical_path']
    iis_publication_type = node['mosaic']['webservice']['iis_publication_type']
    iis_root = node['mosaic']['webservice']['iis_root']
    env = node['mosaic']['env']
    pss_physical_path = ""
    if !temp_pss_physical_path.include? iis_root
      if iis_publication_type.to_s =='simple'
        pss_physical_path= "#{iis_root}\\#{temp_pss_physical_path}"
      else
        pss_physical_path= "#{iis_root}\\#{env}\\#{temp_pss_physical_path}"
      end
    else
      pss_physical_path = temp_pss_physical_path #I don't know why is we don't do this, phisical_path lose it current value
    end

    if node['mosaic']['webservice']['POSservice']['ePayment']['type'] == "EpayNet"
      dlls = node['mosaic']['webservice']['POSservice']['ePayment']['dlls']
      dlls.each{|dll|
        puts "copying dll=#{dll}"
        FileUtils.cp "#{node['mosaic']['webservice']['POSservice']['ePayment']['path']}\\#{dll}","#{pss_physical_path}/BIN/#{dll}"
      }
    end
  end
  only_if { node['mosaic']['webservice']['POSservice']['ePayment']['install']}
end

#**********************************************
# - Update POSPeripherals Web Service-REST
#**********************************************
deploy_webservice 'POSPeripheral' do
  physical_path node['mosaic']['webservice']['POSPeripheral']['physical_path']
  pub_name node['mosaic']['webservice']['POSPeripheral']['pub_name']
  app_pool_name node['mosaic']['webservice']['POSPeripheral']['app_pool_name']
  appversion node['mosaic']['version']
  installer_dir "#{pkg_dir}/POSPeripherals Web Service-REST #{version}/PosPeripheralsService.rest"
  config_template_file "#{pkg_dir}\\configs #{version}\\webservices\\POSPeripherals_Web_Service-REST_Web.config.erb"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deployws
  only_if { node['mosaic']['webservice']['POSPeripheral']['install']}
end


#**********************************************
# – Update LocalFolders
#**********************************************
=begin
  #Update files
  ruby_block 'Copy Local folders to C drive' do
    block do
      FileUtils.cp_r "#{pkg_dir}/LocalFolders #{version}/.","C:\\"
    end

    not_if { !(node['mosaic']['webservice']['LocalFolders']['install']) || !(node['mosaic']['webservice']['initial_install']) ||(::File.directory?("C:\\XSM")) || (::File.directory?("C:\\Image"))} #if the folder is empty
  end

  directory 'C:\XSM' do
    rights :full_control, 'Everyone'
    only_if{(node['mosaic']['webservice']['LocalFolders']['install']) || (node['mosaic']['webservice']['initial_install'])}
  end

  directory 'C:\XMLTemplates' do
    rights :full_control, 'Everyone'
    only_if{(node['mosaic']['webservice']['LocalFolders']['install']) || (node['mosaic']['webservice']['initial_install'])}
  end

  directory 'C:\ReceiptTemplates' do
    rights :full_control, 'Everyone'
    only_if{(node['mosaic']['webservice']['LocalFolders']['install']) || (node['mosaic']['webservice']['initial_install'])}
  end

  directory 'C:\Invoices' do
    rights :full_control, 'Everyone'
    only_if{(node['mosaic']['webservice']['LocalFolders']['install']) || (node['mosaic']['webservice']['initial_install'])}
  end
=end
  #Creating POSservice Web Application if not exists
  powershell_script 'Installing Image for Mosaic' do
  code <<-EOH
    $succeeded = import-module WebAdministration
    if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
      #Could not import, trying to snapin
      add-pssnapin WebAdministration
    }

    $appName = "#{node['mosaic']['webservice']['Image']['pub_name']}"
    $IISPath = "IIS:\\Sites\\Default Web Site\\$appName"
    $appPoolName = "#{node['mosaic']['webservice']['Image']['app_pool_name']}"
    $AppPoolPath = "IIS:\\AppPools\\$appPoolName"
    if (!(Test-Path $AppPoolPath -pathType container))
    {
      #create the app pool
      $pool = New-Item $AppPoolPath
      $pool = get-itemproperty $AppPoolPath
      $pool.managedRuntimeVersion= "v4.0"
      $pool.enable32BitAppOnWin64 = 1
      $pool.processModel.Identity
      $pool.processModel.identityType = 4;
      $pool | Set-Item
      $pool.Stop();
      $pool.Start();
    }
    $phisicalPath = "#{node['mosaic']['webservice']['Image']['physical_path']}"
    $IISPath = "IIS:\\Sites\\Default Web Site\\$appName"
    $exits = Test-Path $IISPath
    if (-Not ($exists)) {
        New-Item "$IISPath" -physicalPath $phisicalPath -type Application
        Set-ItemProperty  "$IISPath" -name applicationPool -value $appPoolName
    }
  EOH
  guard_interpreter :powershell_script
  only_if{(node['mosaic']['webservice']['LocalFolders']['install']) || (node['mosaic']['webservice']['initial_install'])}
  end


#**********************************************
# – Update Mosaic
#**********************************************
  deploy_webservice 'Mosaic' do
    physical_path node['mosaic']['webservice']['MosaicApp']['physical_path']
    pub_name node['mosaic']['webservice']['MosaicApp']['pub_name']
    app_pool_name node['mosaic']['webservice']['MosaicApp']['app_pool_name']
    appversion node['mosaic']['version']
    installer_dir "#{pkg_dir}/Mosaic-#{version}/www"
    config_template_file "#{pkg_dir}\\configs #{version}\\webservices\\mosaic"
    subapps node['mosaic']['webservice']['MosaicApp']['apps']
    iis_publication_type node['mosaic']['webservice']['iis_publication_type']
    env node['mosaic']['env']
    iis_root node['mosaic']['webservice']['iis_root']
    templates node['tpls']['MosaicApp']
    action :deploywebapp
    only_if { node['mosaic']['webservice']['MosaicApp']['install']}
  end

  iis_publication_type = node['mosaic']['webservice']['iis_publication_type']
  tphysical_path = node['mosaic']['webservice']['MosaicApp']['physical_path']
  iis_root = node['mosaic']['webservice']['iis_root']
  physical_path = ""
  env = node['mosaic']['env']
  if !tphysical_path.include? iis_root
    if iis_publication_type.to_s =='simple'
      physical_path= "#{iis_root}\\#{tphysical_path}"
    else
      physical_path= "#{iis_root}\\#{env}\\#{tphysical_path}"
    end
  else
    physical_path = tphysical_path #I don't know why is we don't do this, phisical_path lose it current value
  end

  #restore web.config file for mpos
  ruby_block 'Copy mpos web.config' do
    block do
      FileUtils.cp "#{physical_path}/mpos/web.configHG","#{physical_path}/mpos/Web.config"
    end
    only_if { ::File.file?("#{physical_path}/mpos/Web.configHG")} #if the folder is empty
  end
=begin
  powershell_script "Override_Mpos_SysSetting " do
    code <<-EOH
     $mposSysSettingSource = "#{physical_path}\\mpos\\App_js\\sysSettings.js"
     $mposSysSettingDestination = $mposSysSettingSource
     $newline = "mClientelingIntegrated: true,"

     (Get-Content $mposSysSettingSource) -replace "mClientelingIntegrated\\s*:\\s*false\\s*,", "$newline" | Set-Content $mposSysSettingDestination

      EOH
      guard_interpreter :powershell_script
  only_if {::File.file?("#{physical_path}\\mpos\\App_js\\sysSettings.js")}
  end
=end
  #**********************************************
  # – Update Backoffice
  #**********************************************

  temp_bo_physical_path = node['mosaic']['webservice']['Backoffice']['physical_path']
  bo_physical_path = ""
  iis_root = node['mosaic']['webservice']['iis_root']
  if !temp_bo_physical_path.include? iis_root
    if iis_publication_type.to_s =='simple'
      bo_physical_path= "#{iis_root}\\#{temp_bo_physical_path}"
    else
      bo_physical_path= "#{iis_root}\\#{env}\\#{temp_bo_physical_path}"
    end
  else
    bo_physical_path = temp_bo_physical_path #I don't know why is we don't do this, phisical_path lose it current value
  end

  template 'BackOffice_Create_WebConfig' do
    source "webserver/login_web.config.erb"
    path "#{bo_physical_path}/Web.config"
    action :nothing
  end

  deploy_webservice 'Backoffice' do
    physical_path node['mosaic']['webservice']['Backoffice']['physical_path']
    pub_name node['mosaic']['webservice']['Backoffice']['pub_name']
    app_pool_name node['mosaic']['webservice']['Backoffice']['app_pool_name']
    appversion node['mosaic']['version']
    installer_dir "#{pkg_dir}/Mosaic-Backstore-#{version}/www"
    config_template_file "#{pkg_dir}\\configs #{version}\\backoffice"
    iis_publication_type node['mosaic']['webservice']['iis_publication_type']
    env node['mosaic']['env']
    iis_root node['mosaic']['webservice']['iis_root']
    templates node['tpls']['Backoffice']
    action :deploywebapp
    only_if { node['mosaic']['webservice']['Backoffice']['install']}
    notifies :create, 'template[BackOffice_Create_WebConfig]', :immediately
  end



  #**********************************************
  # – Update CMService
  #**********************************************
  deploy_webservice 'CMService' do
    physical_path node['mosaic']['webservice']['CMService']['physical_path']
    pub_name node['mosaic']['webservice']['CMService']['pub_name']
    app_pool_name node['mosaic']['webservice']['CMService']['app_pool_name']
    appversion node['mosaic']['version']
    installer_dir "#{pkg_dir}/CM Web Service #{version}/cmservice"
    config_template_file "#{pkg_dir}\\configs #{version}\\webservices\\CM_Web_Service_Web.config.erb"
    iis_publication_type node['mosaic']['webservice']['iis_publication_type']
    env node['mosaic']['env']
    iis_root node['mosaic']['webservice']['iis_root']
    action :deployws
    only_if { node['mosaic']['webservice']['CMService']['install']}
  end

  #**********************************************
  # – Update CMServiceUI
  #**********************************************
  deploy_webservice 'CMServiceUI' do
    physical_path node['mosaic']['webservice']['CMServiceUI']['physical_path']
    pub_name node['mosaic']['webservice']['CMServiceUI']['pub_name']
    app_pool_name node['mosaic']['webservice']['CMServiceUI']['app_pool_name']
    appversion node['mosaic']['version']
    installer_dir "#{pkg_dir}/Mi9.Store.Standard-#{version}"
    iis_publication_type node['mosaic']['webservice']['iis_publication_type']
    env node['mosaic']['env']
    iis_root node['mosaic']['webservice']['iis_root']
    templates node['tpls']['CMServiceUI']
    action :deploywebapp
    only_if { node['mosaic']['webservice']['CMServiceUI']['install']}
  end

  #**********************************************
  # – Update ClientelingService
  #**********************************************

  deploy_webservice 'ClientelingService' do
    physical_path node['mosaic']['webservice']['Clienteling']['physical_path']
    pub_name node['mosaic']['webservice']['Clienteling']['pub_name']
    app_pool_name node['mosaic']['webservice']['Clienteling']['app_pool_name']
    appversion node['mosaic']['version']
    installer_dir "#{pkg_dir}/ClientelingService #{version}/clientelingservice"
    config_template_file "C:\\chef\\cookbooks\\mi9.raymark\\templates\\webserver\\Clienteling_Web_Service_Web.config.erb"
    iis_publication_type node['mosaic']['webservice']['iis_publication_type']
    env node['mosaic']['env']
    iis_root node['mosaic']['webservice']['iis_root']
    action :deployws
    only_if { node['mosaic']['webservice']['Clienteling']['install']}
  end

  temp_cm_physical_path = node['mosaic']['webservice']['CMServiceUI']['physical_path']
  cm_physical_path = ""
  if !temp_cm_physical_path.include? iis_root
    if iis_publication_type.to_s =='simple'
      cm_physical_path= "#{iis_root}\\#{temp_cm_physical_path}"
    else
      cm_physical_path= "#{iis_root}\\#{env}\\#{temp_cm_physical_path}"
    end
  else
    cm_physical_path = temp_cm_physical_path #I don't know why is we don't do this, phisical_path lose it current value
  end

  powershell_script "Override_Config.js " do
    code <<-EOH
     $mposSysSettingSource = "#{cm_physical_path}\\App\\config.js"
     $mposSysSettingDestination = $mposSysSettingSource
     $baseApiUrlLine1 = "'baseApiUrl': '#{node['mosaic']['webservice']['CMServiceUI']['Auth_ApiUrl']}/v1/auth/',"
     $baseApiUrlLine2 = "'baseApiUrl': '#{node['mosaic']['webservice']['CMServiceUI']['Auth_ApiUrl']}/v1/cash-management/',"

     (Get-Content $mposSysSettingSource) -replace "'baseApiUrl': 'http://localhost:8847/api/v1/auth/',", "$baseApiUrlLine1" | Set-Content $mposSysSettingDestination
     (Get-Content $mposSysSettingSource) -replace "'baseApiUrl': 'http://localhost:8847/api/v1/cash-management/',", "$baseApiUrlLine2" | Set-Content $mposSysSettingDestination
    EOH
    guard_interpreter :powershell_script
  only_if {node['mosaic']['webservice']['CMServiceUI']['install']}
  end

  #**********************************************
  # – Update Control-Station
  #**********************************************
  temp_cs_physical_path = node['mosaic']['webservice']['CStation']['physical_path']
  cs_physical_path = ""
  if !temp_cs_physical_path.include? iis_root
    if iis_publication_type.to_s =='simple'
      cs_physical_path= "#{iis_root}\\#{temp_cs_physical_path}"
    else
      cs_physical_path= "#{iis_root}\\#{env}\\#{temp_cs_physical_path}"
    end
  else
    cs_physical_path = temp_cs_physical_path #I don't know why is we don't do this, phisical_path lose it current value
  end

  template 'ControlStation_Create_WebConfig' do
    source "webserver/login_web.config.erb"
    path "#{cs_physical_path}/Web.config"
    action :nothing
  end

  deploy_webservice 'Control-Station' do
    physical_path node['mosaic']['webservice']['CStation']['physical_path']
    pub_name node['mosaic']['webservice']['CStation']['pub_name']
    app_pool_name node['mosaic']['webservice']['CStation']['app_pool_name']
    appversion node['mosaic']['version']
    installer_dir "#{pkg_dir}/Mosaic-ControlStation-#{version}/www"
    config_template_file "#{pkg_dir}\\configs #{version}\\backoffice"
    iis_publication_type node['mosaic']['webservice']['iis_publication_type']
    env node['mosaic']['env']
    iis_root node['mosaic']['webservice']['iis_root']
    templates node['tpls']['Backoffice']
    action :deploywebapp
    only_if { node['mosaic']['webservice']['CStation']['install']}
    notifies :create, 'template[ControlStation_Create_WebConfig]', :immediately
  end

  #**********************************************
  # POS Deploy.
  #**********************************************
  # create application just in case iis_publication_type is env-pubname
  powershell_script 'Creating Web app for the environment' do
  code <<-EOH
    $succeeded = import-module WebAdministration
    if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
      #Could not import, trying to snapin
      add-pssnapin WebAdministration
    }
    $appName = "#{node['mosaic']['env']}"
    $appPoolName = "DefaultAppPool"
    $physicalPath = "C:\\WebSites\\$appName"
    $IISPath = "IIS:\\Sites\\Default Web Site\\$appName"
    $exists = Test-Path $IISPath
    if ($exists){
      Remove-WebApplication -Name "$appName" -Site "Default Web Site"
    }
      New-Item "$IISPath" -physicalPath $physicalPath -type Application -Force
      Set-ItemProperty  "$IISPath" -name applicationPool -value $appPoolName -Force

  EOH
  guard_interpreter :powershell_script
  only_if { node['mosaic']['webservice']['iis_publication_type']=='env-pubname'}
  end


  #Creation application Download
 if node['mosaic']['webservice']['deploy_download_folder']
    #Creating phisical folders to store the websites
    directory "#{iis_root}/download" do
      recursive true
      action :create
    	not_if {::File.directory?("#{iis_root}/download")} # or node['mosaic']['webservice']['iis_publication_type']=='simple'}
    end

    #download MosaicSetupFull previous version
    remote_file "#{iis_root}\\Downloads\\MosaicSetupFull-#{version}.exe" do
     source "#{art_url}/#{version}/MosaicSetupFull-#{version}.exe"
     not_if { ::File.exists?("#{iis_root}\\Downloads\\MosaicSetupFull-#{version}.exe")}
    end

    powershell_script 'Creating Web app for the environment' do
    code <<-EOH
      $succeeded = import-module WebAdministration
      if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
        #Could not import, trying to snapin
        add-pssnapin WebAdministration
      }
      $appName = "Downloads"
      $appPoolName = "DefaultAppPool"
      $physicalPath = "C:\\WebSites\\$appName"
      $IISPath = "IIS:\\Sites\\Default Web Site\\$appName"
      $exists = Test-Path $IISPath
      if (!$exists){
        New-Item "$IISPath" -physicalPath $physicalPath -type Application -Force
        Set-ItemProperty  "$IISPath" -name applicationPool -value $appPoolName -Force
        Set-WebConfigurationProperty -filter /system.webServer/directoryBrowse -name enabled -value true -PSPath 'IIS:\\Sites\\Default Web Site\\Downloads'
      }

    EOH
    guard_interpreter :powershell_script
    only_if { 1==1}
    end

end
