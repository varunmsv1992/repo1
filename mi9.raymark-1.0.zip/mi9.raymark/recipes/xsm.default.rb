#
# Cookbook Name:: mi9.raymark
# Recipe:: xsm.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="xsm_start"

ruby_block "verify webservice HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'xsm_verify'
      if node['filesystem']['C:']['kb_available']< node['xsm']['min_kb_available']
          fail "The webservice HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

if node['xsm']['webservice']['rollback']
  backupFolder="#{node['xsm']['backup']['maindir']}\\#{node['xsm']['webservice']['backup']['dir']}"

  raymark_rollback 'Rollback_backup_ws_folder' do
    backup_folder backupFolder
    action :nothing
  end

  directory 'Delete_folders_in_WebSites'  do
    path node['xsm']['webservice']['web_path']
    recursive true
  	action :nothing
  end

  powershell_script "Restoring_WebSites_folders" do
    code <<-EOH
      $Zipfile = "#{backupFolder}\\#{node['xsm']['webservice']['backup']['zip']}"
      $Destination = "#{node['xsm']['webservice']['web_path']}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
    guard_interpreter :powershell_script
    action :nothing
    only_if { ::File.directory?(backupFolder) and ::File.directory?(node['xsm']['webservice']['web_path']) }
  end
end

if node['xsm']['webservice']['backup']['enable']
  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="xsm_backup"
    end
  end

  backupFolder="#{node['xsm']['backup']['maindir']}\\#{node['xsm']['webservice']['backup']['dir']}"

  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['xsm']['backup']['maindir']
    backup_folder backupFolder
    action :backup
  end

  powershell_script "Backup WebSites" do
    code <<-EOH
  					[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
  					$src_folder = "#{node['xsm']['webservice']['web_path']}"
  					$destfile = "#{backupFolder}\\#{node['xsm']['webservice']['backup']['zip']}"
  					$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
  					$includebasedir = $false
  					[System.IO.Compression.ZipFile]::CreateFromDirectory($src_folder,$destfile,$compressionLevel, $includebasedir )
      EOH
    guard_interpreter :powershell_script
    only_if {::File.directory?(node['xsm']['webservice']['web_path'])}
  end
end

ruby_block "make xsm update" do
  block do
      node.default['deploy']['runstatus']="xsm_update"
      Chef.run_context.include_recipe 'mi9.raymark::xsm.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="XSM deploy Successfully\n"
  end
end

#post update
directory 'delete backup last folder'  do
  path "#{node['xsm']['backup']['maindir']}\\#{node['xsm']['webservice']['backup']['dir']}_last"
  recursive true
	action :delete
  only_if { node['xsm']['webservice']['backup']['enable'] }
end
