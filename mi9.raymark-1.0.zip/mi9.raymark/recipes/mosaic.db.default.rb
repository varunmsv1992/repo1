#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.db.default
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['mosaic']['runstatus']="db_start"

ruby_block "verify DB HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'db_verify'
      if node['filesystem']['C:']['kb_available'] < node['mosaic']['db']['min_kb_available']
          fail "The DB HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

if node['mosaic']['db']['rollback']['db']
  raymark_rollback 'Rollback_backup_db_folder' do
    backup_folder node['mosaic']['standalone']['backup']['dbdir']
    action :nothing
  end

  powershell_script "Restoring_db_database" do
    db_instance = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"
  	db_name = node['mosaic']['sql_db_name']
  	code <<-EOH
  		## - Loads the SQL Server SMO Assembly:
  		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
  		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
  	  [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

  		$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
  		$sqlConn.ServerInstance="#{db_instance}"
  	  $sqlConn.LoginSecure = $false
  	  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
  	  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

  		$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
  		$res = new-object Microsoft.SqlServer.Management.Smo.Restore
  		## $backup = new-object Microsoft.SqlServer.Management.Smo.Backup
  		$server.KillAllProcesses('#{db_name}')
  	  # $error[0]|format-list –force

  		$found = $server.Databases.Contains("#{db_name}")

  		$res.Devices.AddDevice("#{node['mosaic']['db']['backup']['dbdir']}\\#{db_name}_db_bkp.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
  		$res.Database = "#{db_name}"
  		$res.NoRecovery = $false
  		$res.FileNumber = 1
  		$res.ReplaceDatabase = $true;

  		$res.SqlRestore($server)

  	  # $error[0]|format-list –force

  	EOH
  	guard_interpreter :powershell_script
    only_if {node['mosaic']['deploy_db']}
  	action :nothing
  end
end

#make a backup
if nodedefault['mosaic']['db']['backup']['db']

  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="db_backup"
    end
  end

  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['mosaic']['backup']['maindir']
    backup_folder node['mosaic']['db']['backup']['dbdir']
    action :backup
  end

  powershell_script "Backup Database Standalone" do
    db_instance = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"
  	db_name = node['mosaic']['sql_db_name']
    code <<-EOH
  	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
  	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
  	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

  					$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
  					$sqlConn.ServerInstance="#{db_instance}"
  				  $sqlConn.LoginSecure = $false
  				  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
  				  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

  					$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
  					$backup = new-object Microsoft.SqlServer.Management.Smo.Backup
  					$found = $server.Databases.Contains("#{node['mosaic']['sql_db_name']}")
  					if ($found)
  					{
  							$backup.Devices.AddDevice("#{node['mosaic']['db']['backup']['dbdir']}\\#{db_name}_db_bkp.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
  							$backup.Database = "#{node['mosaic']['sql_db_name']}"
  							$backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
  							$backup.Initialize = $TRUE
  							$backup.SqlBackup($server)

  					}

      EOH
    guard_interpreter :powershell_script
    only_if { node['mosaic']['standalone']['backup']['db']}
  end
end

ruby_block "run db " do
  block do
      node.default['deploy']['runstatus'] = 'db_update'
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.db.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="DB deploy Successfully\n"
  end
end

#post update
directory 'delete backup dbdir_last folder'  do
  puts "Deleting #{node['mosaic']['db']['backup']['dbdir']}_last"
	path "#{node['mosaic']['db']['backup']['dbdir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['mosaic']['db']['backup']['dbdir']}_last")}
end
