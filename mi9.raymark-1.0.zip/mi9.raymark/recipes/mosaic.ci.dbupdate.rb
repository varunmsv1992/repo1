
#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.ci.dbupdate
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#
# actions
# - Download db scripts
# - Run scripts over Big database database

node.default['deploy']['runstatus']="CI dbupdate start"

#**********************************************
# - Update Big database
#**********************************************
pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"
version = node['mosaic']['version']
art_url = node['mosaic']['depository_url']
env = node['mosaic']['env']
#restore database
db_instance = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"
db_name = node['mosaic']['sql_db_name']

#Download db files templates
remote_file 'download_dbupdate' do
  path "#{pkg_dir}\\dbupdate-#{env}-#{version}.zip"
  source "#{art_url}/#{version}/dbupdate-#{env}-#{version}.zip"
end

powershell_script "Unziping dbupdate" do
  code <<-EOH
    $Zipfile = "#{pkg_dir}\\dbupdate-#{env}-#{version}.zip"
    $Destination = "#{pkg_dir}\\dbupdate-#{env}-#{version}"
    Add-Type -assembly "system.io.compression.filesystem"
    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
    EOH
    guard_interpreter :powershell_script
  not_if { ::File.directory?("#{pkg_dir}\\dbupdate-#{env}-#{version}")}
end

batch "run dbupdate .bat" do
  cwd "#{pkg_dir}\\dbupdate-#{env}-#{version}"
  code "dbupdate.bat"
  action :run
  timeout 18000
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="CI dbupdate deploy Successfully\n"
  end
end
