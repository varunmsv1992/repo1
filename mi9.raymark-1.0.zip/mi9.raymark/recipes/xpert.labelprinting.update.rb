#
# Cookbook Name:: mi9.raymark
# Recipe:: xpert.labelprinting.update
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute

# actions
# - Download actifacts
# - Preparing update
# – Update xpert label printing


#**********************************************
# - Download actifacts
#**********************************************

pkg_dir = "#{node['xpert']['artifacts_dir']}\\#{node['xpert']['version']}"
version = node['xpert']['version']
art_url = node['xpert']['depository_url']

download_installers 'artifacts' do
    dest_dir pkg_dir
    artifacts node['xpert']['labelprinting']['artifacts']
    version node['xpert']['version']
    art_url node['xpert']['depository_url']
    action [:download,:unzip]
end


=begin
#Creating phisical folders to store the websites
directory node['xpert']['labelprinting']['path'] do
  recursive true
  action :create
	not_if {::File.directory?(node['xpert']['labelprinting']['path'])}
end
=end

#**********************************************
# – Update Xpert
#**********************************************

#delete previous version
directory node['xpert']['labelprinting']['path'] do
  recursive true
  action :delete
	only_if {node['xpert']['labelprinting']['path']}
end

#Creating folder
directory node['xpert']['labelprinting']['path'] do
  action :create
  not_if { ::File.directory?(node['xpert']['labelprinting']['path'])}
end

#Update files
ruby_block 'Copy Xpert files' do
  block do
    FileUtils.cp_r "#{pkg_dir}/Xpert-Label Printing #{version}/.",node['xpert']['labelprinting']['path']
  end
  only_if { ::Dir.entries(node['xpert']['labelprinting']['path']) == ['.', '..']} #if the folder is empty
end
