#
# Cookbook Name:: mi9.raymark
# Recipe:: xpert.Apps.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="xpert_start"

ruby_block "verify HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'xpert_verify'
      if node['filesystem']['C:']['kb_available']< node['xpert']['Apps']['min_kb_available']
          fail "The HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end


#make update
ruby_block "make xpert update" do
  block do
      node.default['deploy']['runstatus']="xpert_update"
      Chef.run_context.include_recipe 'mi9.raymark::xpert.apps.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="xpert deploy Successfully\n"
  end
end
