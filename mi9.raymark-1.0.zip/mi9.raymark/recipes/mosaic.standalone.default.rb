#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.standalone.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="standalone_start"

ruby_block "verify Standalone HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'standalone_verify'
      if node['filesystem']['C:']['kb_available'] < node['mosaic']['standalone']['min_kb_available']
          fail "The Standalone HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

powershell_script 'Check_if_sql_is_installed' do
	code <<-EOH
		#(get-itemproperty 'HKLM:\\SOFTWARE\\Microsoft\\Microsoft SQL Server').InstalledInstances > #{node['windows']['temp_dir']}\\is_sql_installed.txt
		$server = $env:computername
		#Write-Output $server
		$sqlVersions = "11.0.2280.0", "red"
		$result = $false

		$regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $server)
		$SqlKey = $regKey.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL")
		#Write-Verbose "Processing Server $server"
		if ($SqlKey -ne $null)
		{
			Foreach ($instance in $SqlKey.GetValueNames())
			{
				$SQLServerObject = New-Object PSObject
				$SQLServerObject | Add-Member -MemberType NoteProperty -Name ServerName -Value $server
				$InstanceName = $SqlKey.GetValue("$instance")
				Write-Progress -Activity "Parsing SQL-Server Information" -Status "Current Instance $instancename" -ParentID 1
				$InstanceKey = $regKey.OpenSubkey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\$InstanceName\\Setup")
				# $InstanceKey.GetValue("Version")
				$v = $InstanceKey.GetValue("Version").Substring(0,2)
	      switch($v){
	           "10" {"2008" | Out-File -Encoding "UTF8" "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	           "11" {"2012" | Out-File -Encoding "UTF8" "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	           "12" {"2014" | Out-File -Encoding "UTF8" "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	           default {"2012" | Out-File -Encoding "UTF8" "#{node['windows']['temp_dir']}\\sqlversion.txt"}
	      }
			}
		}else {"NONE" | Out-File "#{node['windows']['temp_dir']}\\sqlversion.txt"}
		EOH
	guard_interpreter :powershell_script
	not_if { 1!=1}
end


#report back after all is done
ruby_block "is_sql_installed" do
  block do
    encoding_options = {
        :invalid           => :replace,  # Replace invalid byte sequences
        :undef             => :replace,  # Replace anything not defined in ASCII
        :replace           => '',        # Use a blank for those replacements
        :universal_newline => true       # Always break lines with \n
      }
      node.default['mosaic']['version_installed'] = File.read("#{node['windows']['temp_dir']}\\sqlversion.txt").encode(Encoding.find('ASCII'), encoding_options).strip
  end
end

if node['mosaic']['standalone']['rollback']['db']
  raymark_rollback 'Rollback_backup_standalone_folder' do
    backup_folder node['mosaic']['standalone']['backup']['dbdir']
    action :nothing
  end

  powershell_script "Restoring_standalone_database" do
    db_instance = node['mosaic']['sql_instance_name'].empty? ? node['mosaic']['sql_server'] : "#{node['mosaic']['sql_server']}\\#{node['mosaic']['sql_instance_name']}"
  	db_name = node['mosaic']['sql_db_name']
  	code <<-EOH
  		## - Loads the SQL Server SMO Assembly:
  		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
  		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
  	  [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

  		$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
  		$sqlConn.ServerInstance="#{db_instance}"
  	  $sqlConn.LoginSecure = $false
  	  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
  	  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

  		$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
  		$res = new-object Microsoft.SqlServer.Management.Smo.Restore
  		## $backup = new-object Microsoft.SqlServer.Management.Smo.Backup
  		$server.KillAllProcesses('#{db_name}')
  	  # $error[0]|format-list –force

  		$found = $server.Databases.Contains("#{db_name}")

  		$res.Devices.AddDevice("#{node['mosaic']['standalone']['backup']['dbdir']}\\#{db_name}_db_bkp.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
  		$res.Database = "#{db_name}"
  		$res.NoRecovery = $false
  		$res.FileNumber = 1
  		$res.ReplaceDatabase = $true;

  		$res.SqlRestore($server)

  	  # $error[0]|format-list –force

  	EOH
  	guard_interpreter :powershell_script
    only_if {node['mosaic']['deploy_db']=='true'}
  	action :nothing
  end
end

if node['mosaic']['standalone']['backup']['db']

  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="standalone_backup"
    end
  end

  db_instance = node['mosaic']['sql_instance_name'].empty? ? node['mosaic']['sql_server'] : "#{node['mosaic']['sql_server']}\\#{node['mosaic']['sql_instance_name']}"
  db_name = node['mosaic']['sql_db_name']

    #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['mosaic']['backup']['maindir']
    backup_folder node['mosaic']['standalone']['backup']['dbdir']
    action :backup
  end

  powershell_script "Backup Database Standalone" do
    code <<-EOH
  <#
  	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
  	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
  	[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

  					$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
  					$sqlConn.ServerInstance="#{db_instance}"
  				  $sqlConn.LoginSecure = $false
  				  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
  				  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

  					$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
  					$backup = new-object Microsoft.SqlServer.Management.Smo.Backup
  					$found = $server.Databases.Contains("#{node['mosaic']['sql_db_name']}")
  					if ($found)
  					{
  							$backup.Devices.AddDevice("#{node['mosaic']['standalone']['backup']['dbdir']}\\#{db_name}_db_bkp.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
  							$backup.Database = "#{node['mosaic']['sql_db_name']}"
  							$backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
  							$backup.Initialize = $TRUE
  							$backup.SqlBackup($server)

  					}
  					#>
      EOH
    guard_interpreter :powershell_script
  end
end

#make update
ruby_block "make Standalone update" do
  block do
      node.default['deploy']['runstatus']="standalone_update"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.standalone.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="Standalone deploy Successfully\n"
  end
end

#post update
directory 'delete backup dbdir_last folder'  do
  puts "Deleting #{node['mosaic']['standalone']['backup']['dbdir']}_last"
	path "#{node['mosaic']['standalone']['backup']['dbdir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['mosaic']['standalone']['backup']['dbdir']}_last")}
end
