#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.affinity.update
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

# actions
# - Download actifacts
# - Preparing update
# – Update RCRM
# - Update RAMS
# - Update Repairs

#**********************************************
# - Download actifacts
#**********************************************
#Affinity-Customer Relationship Management .zip
#Affinity-Merchandising .zip
#Affinity-Repairs .zip

pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"
version = node['mosaic']['version']
art_url = node['mosaic']['depository_url']

download_installers 'artifacts' do
    dest_dir pkg_dir
    artifacts node['mosaic']['affinity']['artifacts']
    version node['mosaic']['version']
    art_url node['mosaic']['depository_url']
    action [:download,:unzip]
end


#Creating folder
directory node['mosaic']['affinity']['iis_root_env'] do
  action :create
  recursive true
  not_if { ::File.directory?(node['mosaic']['affinity']['iis_root_env'])}
end

puts "iis_root =====>#{node['mosaic']['affinity']['iis_root']}"
#**********************************************
# – Update CRM
#**********************************************

deploy_application 'RCRM' do
  physical_path node['mosaic']['affinity']['RCRM']['physical_path']
  exe_file_name "Raymark.RCRM.exe"
  appversion version
  installer_dir "#{pkg_dir}/Affinity-Customer Relationship Management #{version}"
  config_template_file "#{pkg_dir}\\configs #{version}\\affinity\\Raymark.RCRM.exe.config.erb"
  installation_type node['mosaic']['affinity']['installation_type']
  program_file_root node['mosaic']['affinity']['iis_root']
  action :deployapp
  only_if { node['mosaic']['affinity']['RCRM']['install']}
end


#**********************************************
# - Update RAMS
#**********************************************
deploy_application 'RAMS' do
  physical_path node['mosaic']['affinity']['RAMS']['physical_path']
  exe_file_name "Raymark.RAMS.Win.exe"
  appversion version
  installer_dir "#{pkg_dir}/Affinity-Merchandising #{version}"
  config_template_file "#{pkg_dir}\\configs #{version}\\affinity\\Raymark.RAMS.Win.exe.config.erb"
  installation_type node['mosaic']['affinity']['installation_type']
  program_file_root node['mosaic']['affinity']['iis_root']
  action :deployapp
  only_if { node['mosaic']['affinity']['RAMS']['install']}
end


#**********************************************
# - Update Repairs
#**********************************************
deploy_application 'Repairs' do
  physical_path node['mosaic']['affinity']['Repairs']['physical_path']
  exe_file_name "Raymark.Repair.exe"
  appversion version
  installer_dir "#{pkg_dir}/Affinity-Repairs #{version}"
  config_template_file "#{pkg_dir}\\configs #{version}\\affinity\\Raymark.Repair.exe.config.erb"
  installation_type node['mosaic']['affinity']['installation_type']
  program_file_root node['mosaic']['affinity']['iis_root']
  action :deployapp
  only_if { node['mosaic']['affinity']['Repairs']['install']}
end


#**********************************************
# - Update RESM
#**********************************************
deploy_application 'RESM' do
  physical_path node['mosaic']['affinity']['RESM']['physical_path']
  exe_file_name "Raymark.RESM.exe"
  appversion version
  installer_dir "#{pkg_dir}/Affinity-Enterprise Solution Manager #{version}"
  config_template_file "#{pkg_dir}\\configs #{version}\\affinity\\Raymark.RESM.exe.config.erb"
  installation_type node['mosaic']['affinity']['installation_type']
  program_file_root node['mosaic']['affinity']['iis_root']
  action :deployapp
  only_if { node['mosaic']['affinity']['RESM']['install']}
end
