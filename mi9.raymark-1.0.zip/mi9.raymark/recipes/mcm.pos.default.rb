#
# Cookbook Name:: mi9.raymark
# Recipe:: mcm.pos.default
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="mcm_start"

ruby_block "verify HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'mcm_verify'
      if node['filesystem']['C:']['kb_available']< node['mcm']['pos']['min_kb_available']
          fail "The HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

if node['mcm']['pos']['rollback']['mcm']
  raymark_rollback 'Rollback_backup_mcm_pos_folder' do
    backup_folder node['mcm']['pos']['backup']['dir']
    action :nothing
  end

  directory 'Delete_folders_in_MCM'  do
    path node['mcm']['pos']['path']
    recursive true
  	action :nothing
  end

  powershell_script "Restoring_MCM_folders" do
    code <<-EOH
      $Zipfile = "#{node['mcm']['pos']['backup']['dir']}\\#{node['mcm']['pos']['backup']['zip']}"
      $Destination = "#{node['mcm']['pos']['path']}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
    guard_interpreter :powershell_script
    action :nothing
    only_if { node['mcm']['pos']['backup']['dir'] and ::File.directory?(node['mcm']['pos']['path']) }
  end
end

if node['mcm']['pos']['backup']['mcm']
  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="webservice_backup"
    end
  end

  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['mcm']['backup']['maindir']
    backup_folder node['mcm']['pos']['backup']['dir']
    action :backup
  end

  windows_service 'CDCA Multi Client' do #CDCA Multi Client
    action :stop
  end

  powershell_script "Close MCM app" do
    code <<-EOH
      try{
  					$process = Get-Process "Multi" -ErrorAction Stop
  					if ($process -ne $Null -and $process -ne ''){
  								 Get-Process "Multi" | stop-process
  					}
      }catch [System.Exception] {
          Write-Output $_.Exception.Message
      }
      EOH
    guard_interpreter :powershell_script
  end

  #Backup mcm folder
  powershell_script "Backup mcm" do
    code <<-EOH
  					[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
  					$src_folder = "#{node['mcm']['pos']['path']}"
  					$destfile = "#{node['mcm']['pos']['backup']['dir']}\\#{node['mcm']['pos']['backup']['zip']}"
  					$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
  					$includebasedir = $false
  					[System.IO.Compression.ZipFile]::CreateFromDirectory($src_folder,$destfile,$compressionLevel, $includebasedir )
      EOH
    guard_interpreter :powershell_script
    only_if {::File.directory?(node['mcm']['pos']['path']) }
  end

  windows_service 'CDCA Multi Client' do #CDCA Multi Client
    action :start
  end
end

#make update
ruby_block "make mcm update" do
  block do
      node.default['deploy']['runstatus']="mcm_update"
      Chef.run_context.include_recipe 'mi9.raymark::mcm.pos.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="MCM Pos deploy Successfully\n"
  end
end

#post update
directory 'delete backup mcm dir_last folder'  do
  puts "Deleting #{node['mcm']['pos']['backup']['dir']}_last"
	path "#{node['mcm']['pos']['backup']['dir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['mcm']['pos']['backup']['dir']}_last")}
end
