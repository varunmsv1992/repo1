#
# Cookbook Name:: mi9.raymark
# Recipe:: handler
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

#**********************************************
# - Listen chef-client run
#**********************************************
Chef.event_handler do
  on :run_failed do
    if Chef.run_context.node['deploy']['sendmailonrunfailed']
        MI9HandlerChefRun::HandlerChefRun.new.send_email_on_run_failed(
            Chef.run_context.node.name, Chef.run_context.node['deploy']
        )
    end

    case Chef.run_context.node['deploy']['runstatus']
          when "webservice_backup"
            if Chef.run_context.node['mosaic']['webservice']['rollback']['ws']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_ws_folder", "raymark_rollback",:rollback_default)
            end
          when "webservice_update"
            if Chef.run_context.node['mosaic']['webservice']['rollback']['ws']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Delete_folders_in_WebSites", "directory",:delete)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Restoring_WebSites_folders", "powershell_script",:run)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_ws_folder", "raymark_rollback",:rollback_default)
            end
          when "appserver_backup"
            if Chef.run_context.node['mosaic']['appserver']['rollback']['apps']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_apps_folder", "raymark_rollback",:rollback_default)
            end
          when "appserver_update"
            if Chef.run_context.node['mosaic']['appserver']['rollback']['apps']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Delete_folders_in_AppServer", "directory",:delete)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Restoring_AppServer_folders", "powershell_script",:run)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_apps_folder", "raymark_rollback",:rollback_default)
            end
          when "xsmc_backup"
            if Chef.run_context.node['xsmc']['pos']['rollback']['xsmc']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_xpert_folder", "raymark_rollback",:rollback_default)
            end
          when "xsmc_update"
            if Chef.run_context.node['xsmc']['pos']['rollback']['xsmc']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Delete_folders_in_XSMC", "directory",:delete)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Restoring_XSMC_folders", "powershell_script",:run)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_xpert_folder", "raymark_rollback",:rollback_default)
            end
          when "xpert_backup"
            if Chef.run_context.node['xpert']['pos']['rollback']['xpert']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_xpert_pos_folder", "raymark_rollback",:rollback_default)
            end
          when "xpert_update"
            if Chef.run_context.node['xpert']['pos']['rollback']['xpert']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Delete_folders_in_XPERT_Pos", "directory",:delete)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Restoring_XPERT_Pos_folders", "powershell_script",:run)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_xpert_pos_folder", "raymark_rollback",:rollback_default)
            end
          when "standalone_backup"
            if Chef.run_context.node['mosaic']['standalone']['rollback']['db']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_standalone_folder", "raymark_rollback",:rollback_default)
            end
          when "standalone_update"
            if Chef.run_context.node['mosaic']['standalone']['rollback']['db']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Restoring_standalone_database", "powershell_script",:run)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_standalone_folder", "raymark_rollback",:rollback_default)
            end
          when "db_backup"
            if Chef.run_context.node['mosaic']['db']['rollback']['db']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_db_folder", "raymark_rollback",:rollback_default)
            end
          when "db_update"
            if Chef.run_context.node['mosaic']['db']['rollback']['db']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Restoring_db_database", "powershell_script",:run)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_db_folder", "raymark_rollback",:rollback_default)
            end
          when "mcm_backup"
            if Chef.run_context.node['mcm']['pos']['rollback']['mcm']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_mcm_pos_folder", "raymark_rollback",:rollback_default)
            end
          when "mcm_update"
            if Chef.run_context.node['mcm']['pos']['rollback']['mcm']
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Delete_folders_in_MCM", "directory",:delete)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Restoring_MCM_folders", "powershell_script",:run)
              MI9HandlerChefRun::HandlerChefRun.new.run_resource("Rollback_backup_mcm_pos_folder", "raymark_rollback",:rollback_default)
            end
    end

  end
  on :run_completed do
    if Chef.run_context.node['deploy']['sendmailonruncompleted']
        MI9HandlerChefRun::HandlerChefRun.new.send_email_on_run_completed(
            Chef.run_context.node.name, Chef.run_context.node['deploy']
        )
    end
  end
end
