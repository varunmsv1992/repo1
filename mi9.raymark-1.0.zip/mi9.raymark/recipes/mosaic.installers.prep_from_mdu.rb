
#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.ci.dbupdate
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#
# actions
# - Prepare the installation package from mdu server
# -

#**********************************************
# - Update Preparing installers
#**********************************************
pkg_dir = "#{node['mosaic']['artifacts_dir']}"
version = "#{node['mosaic']['version']}"
=begin
pkg_dir = "C:\\Artifact_depository"

#pkg_dir = "\\\\10.100.0.153\\c$\\depository\\Mosaic-Affinity\\Release"
version = "3.1.1.14"
node.default['devops']['WorkingDirPath'] = "C:\\DevOps\\QA"
node.default['devops']['Waitress'] = "JVR|Local"
node.default['devops']['bistro_ArtRelativeDirPath'] = "Mosaic-Affinity\\Release\\#{version}"
node.default['devops']['bistro_dbserver'] = '10.120.0.22'
node.default['devops']['bistro_dbname'] = 'mi9_bistro_stg'
node.default['devops']['bistro_dbuser'] = 'sa'
node.default['devops']['bistro_dbpwd']  = 'Sa001'
node.default['devops']['bistro_copyToServer']  = false
node.default['devops']['bistro_ArtifactRootPath']  = "C:\\artifact_depository\\"
#node.default['devops']['bistro_ArtifactRootPath']  = "\\\\10.100.0.153\\c$\\depository"
=end

node.default['deploy']['runstatus']="Start Upgrade PS"

notifications_file="#{node['windows']['temp_dir']}\\notifications_file_prepinstall.txt"
node.default['action_todo']=""

directory 'Create Temp folder if it not exits' do
	path node['windows']['temp_dir']
  action :create
  not_if { ::File.directory?(node['windows']['temp_dir']) }
end

ruby_block "is_notification_file_exits" do
  block do
    if !(File.file?(notifications_file))
       puts "File doesn't exits"
       puts "Creating notifications_file_prepinstall.txt"
       node.default['action_todo']="Start_Prepare_Installers"
       File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }
    else
       puts "File exits"
       node.default['action_todo'] = File.read(notifications_file)
       if node['action_todo']=="Restart"
          node.default['action_todo'] = "Preparing_Installers"
          File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }
       end
    end
  end
end

execute "Create_Chef_Task" do
	date= Time.new.strftime("%m/%d/%Y")
  time= (Time.new + 60).strftime("%H:%M")
  command "SCHTASKS /create /tn \"BistroDeployPrepInstallers\" /tr \"\\\"cmd\\\" /c c:\\Bistro\\BistroDeploy.exe /LR\" /sc once /sd #{date} /st #{time} /RU #{node['deploy']['taskuser']} /RP #{node['deploy']['taskpass']} /RL HIGHEST /F"
	action :run
  only_if { node['action_todo']=='Start_Prepare_Installers'}
end

ruby_block "prepare_to_start" do
  block do

       node.default['action_todo']="Restart"
			 node.default['deploy']['runstatus']="Preparing Installers: Starting"
       File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }

  end
  only_if { node['action_todo']=='Start_Prepare_Installers'}
end


powershell_script 'execute Prepare-RaymarkChefInstallPackages' do
 code <<-EOH
   $existPath = Test-Path "#{node['devops']['WorkingDirPath']}\\Prepare-RaymarkChefInstallPackages"
   if (-Not $existPath)
   {
     Throw "#{node['devops']['WorkingDirPath']}\\Prepare-RaymarkChefInstallPackages path does not exists"
   }

   $existsPkgDir = Test-Path "#{pkg_dir}"
   if (-Not $existsPkgDir)
   {
     Throw "#{pkg_dir} path does not exists"
   }

   #{node['devops']['WorkingDirPath']}\\Prepare-RaymarkChefInstallPackages\\Prepare-RaymarkChefInstallPackages.ps1 -DestDirRootPath "#{pkg_dir}" -Release "#{version}"

 EOH
 timeout 18000
 action :run
 only_if { node['action_todo']=='Preparing_Installers'}
end



ruby_block "Ending_Process" do
  block do

       node.default['action_todo']="End"
			 node.default['deploy']['runstatus']="Preparing Installers: Ending"
       File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }

  end
  only_if { node['action_todo']=='Preparing_Installers'}
end

=begin
powershell_script 'Prepare installers' do
 code <<-EOH
     #params
     $Path = "#{pkg_dir}"

     $existPath = Test-Path $Path
     if (-Not $existPath)
     {
       Throw "$Path path does not exists"
     }

     $Version = "#{version}"
     $ArtRelativeDirPath = "#{node['devops']['bistro_ArtRelativeDirPath']}"
     # $Waitresses = "AMAZON_S3|Waitress03,JVR|Local"
     $Waitresses = "#{node['devops']['Waitress']}"
     # $Waitresses = ''
     $CopyToServer = #{node['devops']['bistro_copyToServer']}

     $dbServer = "#{node['devops']['bistro_dbserver']}"
     $dbName = "#{node['devops']['bistro_dbname']}"
     $dbUser = "#{node['devops']['bistro_dbuser']}"
     $dbPwd  = "#{node['devops']['bistro_dbpwd']}"

     $bistroArtifactRootPath = "#{node['devops']['bistro_ArtifactRootPath']}"
     $OrgWaitressKeys = @()

     function Get-FileInfo($Path){

         $result = @()
         $md5 = New-Object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider
         $files = Get-ChildItem "$Path\\*" -Include *.zip, *.exe, *.msu, *.msi

         foreach($file in $files)
         {
             $md5hash = [System.BitConverter]::ToString($md5.ComputeHash([System.IO.File]::ReadAllBytes($File.FullName))).Replace('-','')
             $fileinfo = @{
                 Name=$file.Name
                 Path=$file.FullName
                 MD5=$md5hash
                 RelativePath=$(Join-Path $ArtRelativeDirPath $file.Name)
                 Id=''
             }

             $result += $fileinfo

         }

         return $result
     }
     function Copy-Artifacts($FileInfo,$DestDirPath){

         if(!(Test-Path $DestDirPath)){New-Item $DestDirPath -ItemType Directory -Force}
         $FileInfo | %{Copy-Item $_.Path $DestDirPath -Force | Out-Null}
     }
     function Get-SQLQuery ($Server, $Database, $User, $Pass, $SQLQuery) {
         $connection = New-Object System.Data.SQLClient.SQLConnection
         $connection.ConnectionString = "server='$Server';database='$Database';User Id='$User';Password='$Pass';"
         $adapter = new-object system.data.sqlclient.sqldataadapter ($SQLQuery, $connection)
         $table = new-object system.data.datatable
         $adapter.Fill($table) | out-null
         return $table
     }
     function Update-ArtifactTable($FileInfo){

         foreach($artifact in $FileInfo)
         {

             $Query =   "merge BrArtifacts AS T
                         using (values ('$($artifact.RelativePath)', '$Version','$($artifact.MD5)',0)) AS U ([PathName], [Version],[Checksum],[Sync])
     	                    on U.[PathName] = T.[PathName]
                         when matched then
     	                    update set
     		                    T.[Version] = U.[Version],
     		                    T.[Checksum] = U.[Checksum],
     		                    T.[Sync] = U.[Sync]
                         when not matched then
     	                    insert ([PathName], [Version],[Checksum],[Sync])
     	                    values (U.[PathName], U.[Version],U.[Checksum],U.[Sync]);"

             $result = Get-SQLQuery $dbServer $dbName $dbUser $dbPwd $Query
         }
     }
     function Get-ArtifactIDs($FileInfo){

         foreach($artifact in $FileInfo)
         {

             $Query =   "select Id
                         from BrArtifacts
                         where [PathName] = '$($artifact.RelativePath)'
     	                    and [Version] = '$Version'
     	                    and [Checksum] = '$($artifact.MD5)'"

             $result = Get-SQLQuery $dbServer $dbName $dbUser $dbPwd $Query
             $artifact.Id = $result[0]
         }
     }
     function Get-RelatedArtifactIDs($Waitresses){

         $RelatedIDs = @()
         $OrgWaitressKPVList = $Waitresses.Split(',')

         foreach($kpv in $OrgWaitressKPVList)
         {
             $split = $kpv.Split('|')
             $OrgName = $split[0]
             $WaitressName = $split[1]

             $Query =   "SELECT
     	                    O.Id AS 'OrgID'
     	                    ,W.Id AS 'WaitressID'
                         FROM BrOrganizations O
                         JOIN BrWaitress W
     	                    ON (O.Id = W.OrganizationId)
                         WHERE O.Name = '$OrgName'
     	                    AND W.Name  = '$WaitressName'"

             $tbl = Get-SQLQuery $dbServer $dbName $dbUser $dbPwd $Query

             $tbl | %{
                 $entry = @{
                     OrgID=$_.OrgID
                     WaitressID=$_.WaitressID
                 }

                 $RelatedIDs += $entry
             }

         }

         return $RelatedIDs

     }
     function Update-RelatedArtifactTables($Keys,$FileInfo){

         foreach($entry in $Keys)
         {

             foreach($artifact in $FileInfo)
             {
                 $Query =   "merge BrOrganizationsArtifacts AS T
                             using (values ('$($entry.OrgID)', '$($artifact.Id)')) AS U ([OrganizationId], [ArtifactId])
     	                        on U.[OrganizationId] = T.[OrganizationId]
     		                        and U.[ArtifactId] = T.[ArtifactId]
                             when not matched then
     	                        insert ([OrganizationId], [ArtifactId])
     	                        values (U.[OrganizationId], U.[ArtifactId]);

                             merge BrWaitressArtifacts AS T
                             using (values ('$($entry.WaitressID)', '$($artifact.Id)',0)) AS U ([WaitressId], [ArtifactId],[Sync])
     	                        on U.[WaitressId] = T.[WaitressId]
     		                        and U.[ArtifactId] = T.[ArtifactId]
                             when matched then
     	                        update set
     		                        T.[Sync] = U.[Sync]
                             when not matched then
     	                        insert ([WaitressId], [ArtifactId],[Sync])
     	                        values (U.[WaitressId], U.[ArtifactId],U.[Sync]);"

                 $result = Get-SQLQuery $dbServer $dbName $dbUser $dbPwd $Query
             }
         }
     }

     #get artifact file info
     $artFileInfo = Get-FileInfo $Path

     #copy files to server
     if($CopyToServer){Copy-Artifacts $artFileInfo (Join-Path $bistroArtifactRootPath $ArtRelativeDirPath)}

     #update artifact table
     Update-ArtifactTable $artFileInfo

     #update related tables
     if($Waitresses){

         #get new artifact ids
         Get-ArtifactIDs $artFileInfo

         #get related org-waitress keys
         $OrgWaitressKeys = Get-RelatedArtifactIDs $Waitresses

         #update related tables
         Update-RelatedArtifactTables $OrgWaitressKeys $artFileInfo

     }
 EOH
 timeout 18000
 action :run
end
=end


execute "Delete_Chef_Task" do
 command "SCHTASKS /Delete /TN \"BistroDeployPrepInstallers\" /F"
 action :run
 ignore_failure true
 only_if { node['action_todo']=='End'}
end

file 'Delete powershellversion file' do
	path "#{node['windows']['temp_dir']}\\notifications_file_prepinstall.txt"
  action :delete
	only_if {node['action_todo']=='End'}
end
