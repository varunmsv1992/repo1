#
# Cookbook Name:: mi9.raymark
# Recipe:: xsmc.pos.update
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute

# actions
# - Download actifacts
# - Preparing update
# – Update xsmc


#**********************************************
# - Download actifacts
#**********************************************
#xsmc .zip

pkg_dir = "#{node['xsmc']['artifacts_dir']}\\#{node['xsmc']['version']}"
pkg_dir_prev = "#{node['mosaic']['artifacts_dir']}\\#{node['xsmc']['prev_version']}"

version = node['xsmc']['version']
prev_version = node['xsmc']['prev_version']
art_url = node['xsmc']['depository_url']
art_dir="XSMC "

#Creating pkg_dir/xsmc folder
directory pkg_dir do
  action :create
  not_if { ::File.directory?(pkg_dir)}
end

directory pkg_dir_prev do
  action :create
  not_if { ::File.directory?(pkg_dir_prev)}
end

node['xsmc']['pos']['artifacts'].each do |art|
  puts "Downloading #{art}"
  artEncoded = art.dup
  if art_url.include? "http"
    artEncoded = artEncoded.gsub! ' ', '%20'
    artEncoded = artEncoded.nil? ? art : artEncoded
  end
	remote_file "#{pkg_dir}\\#{art}#{version}.zip" do
   source "#{art_url}/#{version}/#{artEncoded}#{version}.zip"
	 not_if { ::File.exists?("#{pkg_dir}\\#{art}#{version}.zip")}
  end
end

#**********************************************
# - Preparing update
#**********************************************

node['xsmc']['pos']['artifacts'].each do |art|
  puts "Unzipping #{art}"
	powershell_script "Unzipping artifact #{art} " do
	  code <<-EOH
      $Zipfile = "#{pkg_dir}\\#{art}#{version}.zip"
			$Destination = "#{pkg_dir}\\#{art}#{version}"
	    Add-Type -assembly "system.io.compression.filesystem"
	    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
	    EOH
	    guard_interpreter :powershell_script
	  not_if { ::File.directory?("#{pkg_dir}\\#{art}#{version}")}
	end

end

#download XSMC previous version
remote_file "#{pkg_dir_prev}\\XSMC #{prev_version}.zip" do
 source "#{art_url}/#{prev_version}/XSMC #{prev_version}.zip"
 not_if { ::File.exists?("#{pkg_dir_prev}\\XSMC #{prev_version}.zip")}
end

powershell_script "Unziping artifact XSMC prev version " do
  code <<-EOH
    $Zipfile = "#{pkg_dir_prev}\\XSMC #{prev_version}.zip"
    $Destination = "#{pkg_dir_prev}\\XSMC #{prev_version}"
    Add-Type -assembly "system.io.compression.filesystem"
    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
    EOH
    guard_interpreter :powershell_script
  not_if { ::File.directory?("#{pkg_dir_prev}\\XSMC #{prev_version}")}
end

#**********************************************
# – Update xsmc
#**********************************************

powershell_script "Close XSMC app" do
  code <<-EOH
    try{
					$process = Get-Process "XSMC" -ErrorAction Stop
					if ($process -ne $Null -and $process -ne ''){
								 Get-Process "XSMC" | stop-process
					}
    }catch [System.Exception] {
        Write-Output $_.Exception.Message
    }
    EOH
  guard_interpreter :powershell_script
end

powershell_script "Uninstall XSMC" do
  code <<-EOH
        $app = Get-WmiObject -Class Win32_Product | Where-Object {
          $_.Name -match "#{node['xsmc']['pos']['nametouninstall']}"
        }
        if($app -ne $null)
          {
            $app.Uninstall()
          }

    EOH
  guard_interpreter :powershell_script
  only_if { node['xsmc']['pos']['typeofuninstall']=='direct'}
end

#Apply template: unistall.iss.erb
template "#{pkg_dir_prev}\\#{art_dir}#{prev_version}\\uninstall.iss" do
  source "/XSMC/uninstall.iss.erb"
  only_if { node['xsmc']['pos']['typeofuninstall']=='indirect'}
end

#Uninstalling Raymark Mosaic for Windows.
execute "Uninstall Raymark Mosaic for Windows" do
  command "\"#{pkg_dir_prev}\\#{art_dir}#{prev_version}\\XSMC(V1.0.1.8)_20120731.msi\" /s /f1\"#{pkg_dir}\\#{art_dir}#{prev_version}\\uninstall.iss\""
  #action :nothing
  only_if { ::File.directory?("#{pkg_dir_prev}") and node['xsmc']['pos']['typeofuninstall']=='indirect'}
end

#delete XSCM folder if it exists
directory 'delete backup XSMC folder'  do
  path "#{node['xsmc']['pos']['path']}"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['xsmc']['pos']['path']}")}
end

#Creating phisical folders to store the websites
directory node['xsmc']['pos']['newpath'] do
  recursive true
  action :create
	not_if {::File.directory?(node['xsmc']['pos']['newpath'])}
end


#Apply template: Setup.ini
template "#{pkg_dir}\\#{art_dir}#{version}\\setup.iss" do
  source "/XSMC/setup.iss_#{node['xsmc']['version']}.erb"
end

#Installing XSMC for Windows.
execute "Install XSMC for Windows" do
  command "\"#{pkg_dir}\\#{art_dir}#{version}\\setup.exe\" /s /f1\"#{pkg_dir}\\#{art_dir}#{version}\\setup.iss\""
  #action :nothing
  only_if { ::File.directory?("#{pkg_dir}")}
end

#Create phisical folder to store Log Files
directory node['xsmc']['pos']['logfiledestination'] do
  action :create
	not_if {::File.directory?(node['xsmc']['pos']['logfiledestination'])}
end

#Apply template: App.ini
template "#{node['xsmc']['pos']['newpath']}/App.ini" do
  source "XSMC/App.ini.erb"
end

#Apply template: App.ini
template "#{node['xsmc']['pos']['newpath']}/XSMC.exe.config" do
  source "XSMC/XSMC.exe.config.erb"
end
