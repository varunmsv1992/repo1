=begin
  text = File.read('C:\Temp\06- CERTIFICATE SCRIPT.sql')
  new_contents = text.gsub("<Subscriber Database, sysname, SubscriberDB>", "SubscriberDB")
  new_contents = new_contents.gsub("<Certificate Path, sysname, C:\\MSSQL\\Certificates>", "C:\\MSSQL\\Certificates")
  new_contents = new_contents.gsub("<DB Role, RoleName, public>", "Public")
  # To merely print the contents of the file, use:
  puts new_contents

  # To write changes to the file, use:
  File.open('C:\Temp\07- CERTIFICATE SCRIPT.sql', "w")
  File.open('C:\Temp\07- CERTIFICATE SCRIPT.sql', "w") {|file| file.puts new_contents }

=end
#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.db.update
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#
# actions
# - Download db scripts
# - Run scripts over Big database database

#**********************************************
# - Update Big database
#**********************************************
pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"
version = node['mosaic']['version']
art_url = node['mosaic']['depository_url']

#restore database
db_instance = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"
db_name = node['mosaic']['sql_db_name']

#Download db files templates
remote_file 'download_db-scripts' do
  path "#{pkg_dir}\\db-scripts #{version}.zip"
  source "#{art_url}/#{version}/db-scripts #{version}.zip"
end

powershell_script "Unziping db-scripts" do
  code <<-EOH
    $Zipfile = "#{pkg_dir}\\db-scripts #{version}.zip"
    $Destination = "#{pkg_dir}\\db-scripts #{version}"
    Add-Type -assembly "system.io.compression.filesystem"
    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
    EOH
    guard_interpreter :powershell_script
  not_if { ::File.directory?("#{pkg_dir}\\db-scripts #{version}")}
end

ruby_block "Replacing value in 06- CERTIFICATE SCRIPT.sql" do
  block do
    text = File.read("#{pkg_dir}\\db-scripts #{version}\\06- CERTIFICATE SCRIPT.sql")
    new_contents = text.gsub("<Subscriber Database, sysname, SubscriberDB>", "#{node['mosaic']['db']['SubscriberDB']}")
    new_contents = new_contents.gsub("<Certificate Path, sysname, C:\\MSSQL\\Certificates>", "#{node['mosaic']['db']['CertificatePath']}")
    new_contents = new_contents.gsub("<DB Role, RoleName, public>", "#{node['mosaic']['db']['dbrole']}")
    # To merely print the contents of the file, use:
    #puts new_contents

    # To write changes to the file, use:
    #File.open("#{pkg_dir}\\db-scripts #{version}\\06- CERTIFICATE SCRIPT.sql", "w")
    File.open("#{pkg_dir}\\db-scripts #{version}\\06- CERTIFICATE SCRIPT.sql", "w") {|file| file.puts new_contents }
  end
end

db_instance = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"

ruby_block "Executing scripts" do
  block do
    #Running store procedure scripts located in db-scripts
    if ( ::File.directory?("#{pkg_dir}\\db-scripts #{version}"))
      path = "#{pkg_dir}\\db-scripts #{version}"
      path = path.gsub /\\+/, '/'
      scripts = Dir.glob("#{path}/*.sql").sort
      i= 0
      scripts.each do |script|
      #Dir.glob("#{pkg_dir}/db-scripts #{version}/*.sql").sort do |script|
        puts "#{script}"
        next if script == '.' or script == '..'
          object = Chef::Resource::Execute.new("Script #{script}", run_context)
          object.command "\"#{node['windows']['sqlcmd_path_exe']}\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{script}\" -o \"#{pkg_dir}\\db-scripts #{version}\\out_#{i}.txt\""
          object.run_action :run

        #execute "Script #{script}" do
        #  command "\"#{node['windows']['sqlcmd_path']}\\Sqlcmd.exe\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{script}\" -o \"#{pkg_dir}\\db-scripts #{version}\\out_#{i}.txt\""
        #end
        i = i + 1
      end
    end
  end
end

ruby_block "Concatening output files" do
  block do
    if ( ::File.directory?("#{pkg_dir}\\db-scripts #{version}"))
      path = "#{pkg_dir}\\db-scripts #{version}"
      path = path.gsub /\\+/, '/'
      outputs = Dir.glob("#{path}/out_*.txt").sort
      hole_content = ""
      outputs.each do |output|
        next if output == '.' or output == '..'
        file = File.open("#{output}", "rb")
        nextContents = file.read
        hole_content = hole_content + nextContents

      end

      File.open("#{node['mosaic']['backup']['maindir']}\\#{node['mosaic']['db']['execution_result_filename'] }", "w") {|file| file.puts hole_content }
    end

  end

end
=begin
ruby_block "Creating wrapper.sql" do
  block do
    if ( ::File.directory?("#{pkg_dir}\\db-scripts #{version}"))
      path = "#{pkg_dir}\\db-scripts #{version}"
      path = path.gsub /\\+/, '/'
      outputs = Dir.glob("#{path}/*.sql").sort
      hole_content = "BEGIN TRY
      BEGIN TRAN
      SET XACT_ABORT ON; -- Roll back everything if error occurs in script

-- do stuff

COMMIT TRANSACTION TransactionWithGos;
END TRAN
BEGIN CATCH
  ROALLBACK
END CATCH
GO"
      outputs.each do |output|
        next if output == '.' or output == '..'
        file = File.open("#{output}", "rb")
        nextContents = file.read
        hole_content = hole_content + nextContents

      end

      File.open("#{path}\\wrapper.sql", "w") {|file| file.puts hole_content }
    end

  end

end
=end
