#
# Cookbook Name:: mi9.raymark
# Recipe:: default
#
# Copyright 2017, Mi9 Retails
#
# All rights reserved - Do Not Redistribute
#

ruby_block "include Initial Recipes" do
  block do
      #Chef.run_context.include_recipe 'mi9.raymark::handler'
      Chef.run_context.include_recipe 'mi9.devops.cb.libs::handler'
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.commons'
  end
end

if node['mosaic']['version'] == "0.0.0.0"
  fail "Check the deployment config file. Seems it is not compatible with Mosaic-Affinity"
end

ruby_block "include Role WebService" do
  block do
      node.default['deploy']['runlog']="- WebService\n"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.webservice.default'
  end
  only_if {(node['roles'].include?('rm_webservice') and node['mosaic']['webservice']['deploy'])}
end
puts node['roles']
puts node['mosaic']['affinity']['deploy']
ruby_block "include Role affinity" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- affinity\n"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.affinity.default'
  end
  only_if {(node['roles'].include?('rm_affinity') and node['mosaic']['affinity']['deploy'])}
end

ruby_block "include Role pos" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- POS\n"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.mpos.default'
  end
  only_if {(node['roles'].include?('rm_pos') and node['mosaic']['pos']['deploy'])}
end

ruby_block "include Role pos Xsmc" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- Xscm\n"
      Chef.run_context.include_recipe 'mi9.raymark::xsmc.pos.default'
  end
  only_if {(node['roles'].include?('rm_xsmc_pos') and node['xsmc']['pos']['deploy'])}
end

ruby_block "include Role Xpert label printing" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- Xpert-LabelPrinting\n"
      Chef.run_context.include_recipe 'mi9.raymark::xpert.labelprinting.default'
  end
  only_if {(node['roles'].include?('rm_xpert_labelprinting') and node['xpert']['labelprinting']['deploy'])}
end

ruby_block "include Role Xpert Apps" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- Xpert-Apps\n"
      Chef.run_context.include_recipe 'mi9.raymark::xpert.apps.default'
  end
  only_if {(node['roles'].include?('rm_xpert_apps') and node['xpert']['apps']['deploy'])}
end

ruby_block "include Role pos Xpert" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- Xpert\n"
      Chef.run_context.include_recipe 'mi9.raymark::xpert.central.default'
  end
  only_if {(node['roles'].include?('rm_xpert_pos') and node['xpert']['pos']['deploy'])}
end

ruby_block "include Role standalone" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- Standalone\n"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.standalone.default'
  end
  only_if {(node['roles'].include?('rm_standalone') and node['mosaic']['deploy_db'])}
end

ruby_block "include Role Generate standalone" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- GenStandalone\n"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.genstandalone.default'
  end
  only_if {(node['roles'].include?('rm_genstandalone') )}
end

ruby_block "include Role db" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- DataBase\n"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.db.default'
  end
  only_if {(node['roles'].include?('rm_db') and node['mosaic']['deploy_db'])}
end

ruby_block "include Role XSM" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- XSM\n"
      Chef.run_context.include_recipe 'mi9.raymark::xsm.default'
  end
  only_if {(node['roles'].include?('rm_xsm') and node['xsm']['deploy'])}
end

ruby_block "include Role CI" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- CI-DB\n"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.ci.dbupdate'
  end
  only_if {(node['roles'].include?('CI') and node['xsm']['deploy'])}
end

ruby_block "include Role MCM" do
  block do
      node.default['deploy']['runlog']="#{node['deploy']['runlog']}- MCM\n"
      Chef.run_context.include_recipe 'mi9.raymark::mcm.pos.default'
  end
  only_if {(node['roles'].include?('rm_mcm_pos') and node['mcm']['deploy'])}
end

ruby_block "include Post Deploy Recipe" do
  block do
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.postdeploy'
  end
end
