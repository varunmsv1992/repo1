=begin
node.default['mosaic']['webservice']['POSservice']['physical_path'] = "POSService"
node.default['mosaic']['webservice']['POSservice']['ePayment']['install'] = true
node.default['mosaic']['webservice']['POSservice']['ePayment']['type'] = "EpayNet"
node.default['mosaic']['webservice']['POSservice']['ePayment']['path'] = "C:\\Program Files (x86)\\Raymark\\Replenishment\\"
#default['mosaic']['webservice']['POSservice']['ePayment']['dlls'] = ['AuthC3Net.dll','AuthMLNK.dll','AuthSFT4.dll','AuthTriPOS.dll','AuthVRFN.dll','BouncyCastle.Crypto.dll','Encryption.dll','EpaymentTemplates.dll','ePayNet.dll','ePayNet.dll.config','ePayResources.dll','RSAEncryption.dll','Tools.dll','Zip.dll']
node.default['mosaic']['webservice']['POSservice']['ePayment']['dlls'] = ['AxInterop.RaymImage.dll','AxSHDocVw.dll','Advr_login.htm']
env = "training"
iis_root = "C:\\test"
iis_publication_type = "pubname-env"
node.default['mosaic']['artifacts_dir'] = "C:\\Artifact_depository"
node.default['mosaic']['version']= "3.1.1.14"
node.default['mosaic']['webservice']['enableHttps'] = true
node.default['mosaic']['pos']['storemap_defined'] = true
pkg_dir = "C:\\Temp\\XSMC"
node.default['xsmc']['pos']['artifact'] ="RDSS_Client_Installer.msi"
node.default['xsmc']['pos']['newpath'] = "C:\\XSMC"

node.default['windows']['sqlcmd_path'] = "C:\\program file ...\\sqlcmd"
sqlcmd_path = node.attribute?('windows') ? node['windows']['sqlcmd_path'] : 'SQLCMD'

puts sqlcmd_path
=end

node.default['windows']['temp_dir']= "C:\\Temp"
=begin
batch 'ExportMosaicRegistry' do
  code <<-EOH
  REG EXPORT HKEY_LOCAL_MACHINE\\SOFTWARE\\WOW6432Node\\Raymark\\Mosaic #{node['windows']['temp_dir']}\\mosaic.reg
  EOH
  timeout 18000
end
=end

batch 'ImportMosaicRegistry' do
  code <<-EOH
  REG Import #{node['windows']['temp_dir']}\\mosaic.reg
  EOH
  timeout 18000
end

=begin
report_app_installed_v2 'reporting Test-App installed' do
		appname 'TEST-APP'
		version '3.2.1.0'
		path 'C:\Temp'
		details "Testing report_app_installed_v2"
		action :send
end

ruby_block "Test Compare versions" do
  block do

      if (Gem::Version.new(node.default['mosaic']['version']) >= Gem::Version.new('2.0.0'))
        puts 'good'
      else
        puts 'fails'
      end
  end
end
=end
=begin
execute "msiexec /i #{pkg_dir}\\#{node['xsmc']['pos']['artifact']} /qn INSTALLDIR=\"#{node['xsmc']['pos']['newpath']}\"" do
  action :run
  only_if { ::File.file?("#{pkg_dir}\\#{node['xsmc']['pos']['artifact']}")}
end


if (node['mosaic']['pos']['storemap_defined'])
	ruby_block 'Loading StoreMap' do
		block do

			def downcase_hash_keys(h)
			  if h.is_a?(Hash)
			    h.keys.each do |key|
			      new_key = key.to_s.downcase
			      h[new_key] = h.delete(key)
			      downcase_hash_keys(h[new_key])
			    end
			  elsif h.respond_to?(:each)
			    h.each { |e| downcase_hash_keys(e) }
			  end
			  h
			end

			if File.file?("C:\\test\\test.json")
				require 'json'
				file = File.read("C:\\test\\test.json")
				data_hash = JSON.parse(file)
				downcase_hash_keys(data_hash)
				puts data_hash
				puts "#{node['hostname']}"

				#puts data_hash["#{node['hostname']}"]
				node.default['mosaic']['offlineServer'] = data_hash["#{node['hostname']}".to_s.downcase]['masterpos']

				puts node['mosaic']['offlineServer']

			else
				puts "the system can't find the storemap file. Current node #{node['hostname']}"
			end
		end
		only_if { ::File.file?("C:\\test\\test.json")} #if the folder is empty
	end
end
=end

=begin
ruby_block 'move Epayment dlls' do
  block do
    temp_pss_physical_path = node['mosaic']['webservice']['POSservice']['physical_path']
    pss_physical_path = ""
    if !temp_pss_physical_path.include? iis_root
      if iis_publication_type.to_s =='simple'
        pss_physical_path= "#{iis_root}\\#{temp_pss_physical_path}"
      else
        pss_physical_path= "#{iis_root}\\#{env}\\#{temp_pss_physical_path}"
      end
    else
      pss_physical_path = temp_pss_physical_path #I don't know why is we don't do this, phisical_path lose it current value
    end

    if node['mosaic']['webservice']['POSservice']['ePayment']['type'] == "EpayNet"
      dlls = node['mosaic']['webservice']['POSservice']['ePayment']['dlls']
      dlls.each{|dll|
        puts "dllxx=#{dll}"
        FileUtils.cp "#{node['mosaic']['webservice']['POSservice']['ePayment']['path']}\\#{dll}","#{pss_physical_path}/BIN/#{dll}"
      }
#puts "entro"
    end
  end
  only_if { node['mosaic']['webservice']['POSservice']['ePayment']['install']}
end
=end

=begin
registry_key 'HKEY_LOCAL_MACHINE\SOFTWARE\Raymark\Mosaic' do
  architecture :i386
#  recursive true
  values [{:name => 'PeripheralAllowed', :type => :dword, :data => 1},
          {:name => 'DefaultCashDrawerId', :type => :string, :data => ''},
          {:name => 'DefaultLineDisplayId', :type => :string, :data => ''},
          {:name => 'DefaultMICRId', :type => :string, :data => ''},
          {:name => 'DefaultMSReaderId', :type => :string, :data => ''},
          {:name => 'DefaultPrinterId', :type => :string, :data => ''},
          {:name => 'DefaultScannerId', :type => :string, :data => ''},
          {:name => 'LocaleName', :type => :string, :data => ''},

         ]
  action :create
end

ruby_block 'read mac_address from register' do
  block do

    #subkey_array = registry_get_values('HKEY_LOCAL_MACHINE\SOFTWARE\Raymark\Mosaic', :machine).select { |v| v[:name] == "PeripheralAllowed" }[0]

    macAddress = registry_get_values('HKEY_LOCAL_MACHINE\SOFTWARE\Raymark\Mosaic', :i386).select { |v| v[:name] == "PeripheralAllowed" }[0]
    #reg_key_hash = subkey_array.at(18)
    #macAddress = reg_key_hash.values_at(:data)
    puts "#{macAddress}"

    node.run_state['mac'] = "#{macAddress}"
  end
  only_if {1 == 1}
end

ruby_block 'put mac address' do
  block do

    puts "the mac address is: #{node.run_state['mac']}"
  end
  only_if {1 == 1}
end

=end

=begin
powershell_script 'EnableHttps with self_signed_certificate' do
	code <<-EOH
	    Import-Module WebAdministration
      $SiteName = "Default Web Site"
      $HostName = "localhost"
      $CertificatePassword = '1234'
      $UAPWebBrowserUrl ='https://localhost'
      $SiteFolder = Join-Path -Path 'C:\\inetpub\\wwwroot' -ChildPath $SiteName
      $certPath = '#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}\\ssc.pfx'
      Write-Host 'Import pfx certificate' $certPath
      $certRootStore = "LocalMachine"
      $certStore = "My"
      $pfx = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
      $pfx.Import($certPath,$CertificatePassword,"Exportable,MachineKeySet,PersistKeySet")
      $store = New-Object System.Security.Cryptography.X509Certificates.X509Store($certStore,$certRootStore)
      $store.Open('ReadWrite')
      $store.Add($pfx)
      $store.Close()
      $certThumbprint = $pfx.Thumbprint

      Write-Host 'Add website' $SiteName
      # New-WebSite -Name $SiteName -PhysicalPath $SiteFolder -Force
      $IISSite = "IIS:\\Sites\\$SiteName"
      Set-ItemProperty "$IISSite" -name  Bindings -value @(@{protocol='https';bindingInformation='*:443:$HostName'},@{protocol='http';bindingInformation='*:80:$HostName'})

      if($applicationPool) { Set-ItemProperty $IISSite -name  ApplicationPool -value $IISApplicationPool }


      Write-Host 'Bind certificate with Thumbprint' $certThumbprint
      $obj = get-webconfiguration "//sites/site[@name='$SiteName']"
      $binding = $obj.bindings.Collection[0]
      $method = $binding.Methods["AddSslCertificate"]
      $methodInstance = $method.CreateInstance()
      $methodInstance.Input.SetAttributeValue("certificateHash", $certThumbprint)
      $methodInstance.Input.SetAttributeValue("certificateStoreName", $certStore)
      $methodInstance.Execute()

    EOH
	guard_interpreter :powershell_script
	# only_if { node['mosaic']['webservice']['enableHttps'] && ::File.file?("#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}\\ssc.pfx")}
end
=end
=begin
powershell_script 'EnableHttps with self_signed_certificate' do
	code <<-EOH
	    Import-Module WebAdministration
      $SiteName = "Default Web Site"
      $HostName = "#{node['hostname']}"

      $certStore = "My"

			$certThumbprint = (Get-ChildItem cert:\\LocalMachine\\My | where-object { $_.Subject -like "*$HostName*" } | Select-Object -First 1).Thumbprint

      Write-Host 'Add website' $SiteName
      # New-WebSite -Name $SiteName -PhysicalPath $SiteFolder -Force
      $IISSite = "IIS:\\Sites\\$SiteName"
      Set-ItemProperty "$IISSite" -name  Bindings -value @(@{protocol='https';bindingInformation="*:443:$HostName"},@{protocol='http';bindingInformation="*:80:$HostName"})

      if($applicationPool) { Set-ItemProperty $IISSite -name  ApplicationPool -value $IISApplicationPool }


      Write-Host 'Bind certificate with Thumbprint' $certThumbprint
      $obj = get-webconfiguration "//sites/site[@name='$SiteName']"
      $binding = $obj.bindings.Collection[0]
      $method = $binding.Methods["AddSslCertificate"]
      $methodInstance = $method.CreateInstance()
      $methodInstance.Input.SetAttributeValue("certificateHash", $certThumbprint)
      $methodInstance.Input.SetAttributeValue("certificateStoreName", $certStore)
      $methodInstance.Execute()

    EOH
	guard_interpreter :powershell_script
	# only_if { node['mosaic']['webservice']['enableHttps'] && ::File.file?("#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}\\ssc.pfx")}
end
=end
=begin
powershell_script 'self_signed_certificate' do
    code <<-EOH
        # Variables for user to set
        $PortNumber = "443"
        $URL = "localhost"
        # Variables determined by the script
        $PowershellVersion = $host.version.Major
        $OS = Get-WMIObject Win32_OperatingSystem | select-object Caption
        $OkToProceed = $true
        $WebsiteName = "Default Web Site"
        # Check for correct powershell ver.
        if ($PowershellVersion -lt 4)
        {
            $OKToProceed = $false
            Write-Host "Error: Please update Powershell and try again."
        }
        # check if website exists in IIS
        $WebsiteExists = Get-Website -Name $WebsiteName
        if ($WebsiteExists -eq $null)
        {
            $OKToProceed = $false
            Write-Host "Error: check in IIS for the correct website name"
        }
        if ($OkToProceed -eq $true)
        {
        Import-Module WebAdministration
        Stop-Website -Name $WebsiteName
        Sleep -s 3
        # remove cert. with the same name if it exists.
        Get-ChildItem Cert:\\LocalMachine\\My -DnsName $URL | remove-item -force -erroraction silentlycontinue
        netsh http delete sslcert ipport=0.0.0.0:$PortNumber
        # remove https binding if it existsts.
        Remove-WebBinding -Name $WebsiteName -Protocol https -IPAddress "*" -Port $PortNumber -HostHeader $URL -ErrorAction SilentlyContinue
        # create HTTPS binding
        New-WebBinding -Name $WebsiteName -Protocol https -IPAddress "*" -Port $PortNumber -HostHeader $URL

        # create ssl cert,powershell 5 allows to set longer expiry date.
        if ($OS -like '*8*' -or $OS -like '*2012*')
        {
            $cert = New-SelfSignedCertificate -DnsName $URL -CertStoreLocation Cert:\\LocalMachine\\My
        }
        else
        {
            $StartDate = '01/01/' + (Get-Date).Year
            $EndDate = '01/01/' + (Get-Date).AddYears(5).Year
            $cert = New-SelfSignedCertificate -DnsName $URL -CertStoreLocation Cert:\\LocalMachine\\My -FriendlyName $URL -NotBefore $StartDate -NotAfter $EndDate
        }
        $rootStore = New-Object System.Security.Cryptography.X509Certificates.X509Store -ArgumentList Root, LocalMachine
        $rootStore.Open("MaxAllowed")
        $rootStore.Add($cert)
        $rootStore.Close()
        Start-Sleep -s 3
        Push-Location IIS:\SslBindings
        # bind certificate to webbindings
        $SelfSignedCert = Get-ChildItem Cert:\\LocalMachine\\My -DnsName $URL
        $strThumb = $SelfSignedCert.Thumbprint  #get the hash if the cert.
        $guid = [guid]::NewGuid().ToString("B")
        netsh http add sslcert ipport=0.0.0.0:$PortNumber certhash=$strThumb certstorename=MY appid="$guid"
        #exit powerShell
        Pop-Location
        # start websitewebsite
        Start-Website -Name $WebsiteName
        Sleep -s 3

        Write-Host "check https://$URL is functional and you are not getting any seucirty warnings"
        }
    EOH
guard_interpreter :powershell_script
end
=end
