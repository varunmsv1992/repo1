#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.webservice.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="webservice_start"

ruby_block "verify webservice HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'webservice_verify'
      if node['filesystem']['C:']['kb_available']< node['mosaic']['webservice']['min_kb_available']
          fail "The webservice HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

ruby_block "is_ps_installed" do
    block do
      script =<<-EOF
        return (get-wmiobject -query "select * from Win32_Service where name='W3svc'").State
      EOF
      isRunning = powershell_out(script).stdout.chop
      if (isRunning.nil? || isRunning.empty?)
        Chef.run_context.include_recipe 'mi9.raymark::mosaic.wf.install'
      end
    end
end

if node['mosaic']['webservice']['rollback']['ws']
  raymark_rollback 'Rollback_backup_ws_folder' do
    puts node['mosaic']['webservice']['backup']['wsdir']
    backup_folder node['mosaic']['webservice']['backup']['wsdir']
    action :nothing
  end

  directory 'Delete_folders_in_WebSites'  do
    path node['mosaic']['webservice']['iis_root_env']
    recursive true
  	action :nothing
  end

  powershell_script "Restoring_WebSites_folders" do
    code <<-EOH
      $Zipfile = "#{node['mosaic']['webservice']['backup']['wsdir']}\\#{node['mosaic']['webservice']['backup']['wszip']}"
      $Destination = "#{node['mosaic']['webservice']['iis_root']}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
    guard_interpreter :powershell_script
    action :nothing
    only_if { ::File.directory?(node['mosaic']['webservice']['backup']['wsdir']) and ::File.directory?(node['mosaic']['webservice']['iis_root_env']) }
  end
end

if node['mosaic']['webservice']['backup']['ws']
  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="webservice_backup"
    end
  end

  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['mosaic']['backup']['maindir']
    backup_folder node['mosaic']['webservice']['backup']['wsdir']
    action :backup
  end

  powershell_script "Backup WebSites" do
    code <<-EOH
  					[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
  					$src_folder = "#{node['mosaic']['webservice']['iis_root']}"
  					$destfile = "#{node['mosaic']['webservice']['backup']['wsdir']}\\#{node['mosaic']['webservice']['backup']['wszip']}"
  					$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
  					$includebasedir = $false
  					[System.IO.Compression.ZipFile]::CreateFromDirectory($src_folder,$destfile,$compressionLevel, $includebasedir )
      EOH
    guard_interpreter :powershell_script
    only_if {::File.directory?(node['mosaic']['webservice']['iis_root_env'])}
  end
end

#make update
ruby_block "make webservice update" do
  block do
      node.default['deploy']['runstatus']="webservice_update"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.webservice.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="WebService deploy Successfully\n"
  end
end

#post update
directory 'delete backup wsdir_last folder'  do
  path "#{node['mosaic']['webservice']['backup']['wsdir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['mosaic']['webservice']['backup']['wsdir']}_last")}
end
