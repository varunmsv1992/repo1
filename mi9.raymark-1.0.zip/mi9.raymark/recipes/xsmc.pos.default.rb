#
# Cookbook Name:: mi9.raymark
# Recipe:: xsmc.pos.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#


node.default['deploy']['runstatus']="xsmc_start"

ruby_block "verify HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'xsmc_verify'
      if node['filesystem']['C:']['kb_available']< node['xsmc']['pos']['min_kb_available']
          fail "The HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

if node['xsmc']['pos']['rollback']['xsmc']
  raymark_rollback 'Rollback_backup_xpert_folder' do
    backup_folder node['xsmc']['pos']['backup']['dir']
    action :nothing
  end

  directory 'Delete_folders_in_XSMC'  do
    path node['xsmc']['pos']['path']
    recursive true
  	action :nothing
  end

  powershell_script "Restoring_XSMC_folders" do
    code <<-EOH
      $Zipfile = "#{node['xsmc']['pos']['backup']['dir']}\\#{node['xsmc']['pos']['backup']['zip']}"
      $Destination = "#{node['xsmc']['pos']['path']}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
    guard_interpreter :powershell_script
    action :nothing
    only_if { node['xsmc']['pos']['backup']['dir'] and ::File.directory?(node['xsmc']['pos']['path']) }
  end
end

if node['xsmc']['pos']['backup']['xsmc']
  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="xsmc_backup"
    end
  end
  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['xsmc']['backup']['maindir']
    backup_folder node['xsmc']['pos']['backup']['dir']
    action :backup
  end

  #Backup Xsmc folder
  powershell_script "Backup Xsmc" do
    code <<-EOH
  					$process = Get-Process "XSMC"
  					if ($process -ne $Null -and $process -ne ''){
  								 Get-Process "XSMC" | stop-process -Confirm:$false -Force
  					}
  					[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
  					$src_folder = "#{node['xsmc']['pos']['path']}"
  					$destfile = "#{node['xsmc']['pos']['backup']['dir']}\\#{node['xsmc']['pos']['backup']['zip']}"
  					$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
  					$includebasedir = $false
  					if (Test-Path $destfile)
  					{
  							Remove-Item $destfile
  					}
  					[System.IO.Compression.ZipFile]::CreateFromDirectory($src_folder,$destfile,$compressionLevel, $includebasedir )
      EOH
    guard_interpreter :powershell_script
    only_if { node['xsmc']['pos']['backup']['xsmc'] and ::File.directory?(node['xsmc']['pos']['path']) }
  end

end

#make update
ruby_block "make xsmc update" do
  block do
      node.default['deploy']['runstatus']="xsmc_update"

      if (Gem::Version.new(node['xsmc']['version']) < Gem::Version.new('2.0.0.0'))
        Chef.run_context.include_recipe 'mi9.raymark::xsmc.pos.update'
      else
        Chef.run_context.include_recipe 'mi9.raymark::xsmc.pos.update_v2.0'
      end
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="XSMC deploy Successfully\n"
  end
end

#post update
#**********************************************
# – Deploying Maintenance folder
#**********************************************
if node['xsmc']['pos']['maintenanceFolder']

    pkg_dir = "#{node['xsmc']['artifacts_dir']}\\#{node['xsmc']['version']}"
    version = node['xsmc']['version']
    art_url = node['xsmc']['depository_url']

    #download database
    remote_file "#{pkg_dir}\\Maintenance.zip" do
     atomic_update true
     source "#{art_url}/#{version}/Maintenance.zip"
     #not_if { ::File.exists?("#{pkg_dir}\\standalone_#{node['mosaic']['customer_name']}_#{node['mosaic']['version']}.zip") or ::File.exists?("#{pkg_dir}\\standalone.bak") or !(node['mosaic']['standalone']['deploy'])}
     not_if {::File.file?("#{pkg_dir}\\Maintenance.zip")}
    end


    powershell_script "Unziping Maintenance folder" do
      code <<-EOH
        $Zipfile = "#{pkg_dir}\\Maintenance.zip"
        $Destination = "#{node['xsmc']['pos']['newpath']}\\Maintenance"
        If (Test-Path $Destination){
        	Remove-Item $strFolderName -Force
        }

        Add-Type -assembly "system.io.compression.filesystem"
        [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
        EOH
        guard_interpreter :powershell_script
      only_if { ::File.file?("#{pkg_dir}\\Maintenance.zip")}
    end
end
#**********************************************
# – Delete last backup folders
#**********************************************

#delete backup dir_last folder
directory 'delete backup dir_last folder'  do
  puts "Deleting #{node['xsmc']['pos']['backup']['dir']}_last"
	path "#{node['xsmc']['pos']['backup']['dir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['xsmc']['pos']['backup']['dir']}_last")}
end
