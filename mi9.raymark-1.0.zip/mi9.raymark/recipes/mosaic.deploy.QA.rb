
#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.ci.dbupdate
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#
# actions
# - Prepare the installation package from mdu server
# -

#**********************************************
# - Update Preparing installers
#**********************************************
pkg_dir = "#{node['mosaic']['artifacts_dir']}"
version = "#{node['mosaic']['version']}"
=begin
pkg_dir = "C:\\Artifact_depository"

#pkg_dir = "\\\\10.100.0.153\\c$\\depository\\Mosaic-Affinity\\Release"
version = "3.1.1.14"
node.default['devops']['WorkingDirPath'] = "C:\\DevOps\\QA"
node.default['devops']['Waitress'] = "JVR|Local"
node.default['devops']['bistro_ArtRelativeDirPath'] = "Mosaic-Affinity\\Release\\#{version}"
node.default['devops']['bistro_dbserver'] = '10.120.0.22'
node.default['devops']['bistro_dbname'] = 'mi9_bistro_stg'
node.default['devops']['bistro_dbuser'] = 'sa'
node.default['devops']['bistro_dbpwd']  = 'Sa001'
node.default['devops']['bistro_copyToServer']  = false
node.default['devops']['bistro_ArtifactRootPath']  = "C:\\artifact_depository\\"
#node.default['devops']['bistro_ArtifactRootPath']  = "\\\\10.100.0.153\\c$\\depository"
=end

node.default['deploy']['runstatus']="Start Upgrade QA env"

notifications_file="#{node['windows']['temp_dir']}\\notifications_file_prepinstall.txt"
node.default['action_todo']=""

directory 'Create Temp folder if it not exits' do
	path node['windows']['temp_dir']
  action :create
  not_if { ::File.directory?(node['windows']['temp_dir']) }
end

ruby_block "is_notification_file_exits" do
  block do
    if !(File.file?(notifications_file))
       puts "File doesn't exits"
       puts "Creating notifications_file_prepinstall.txt"
       node.default['action_todo']="Start_Prepare_Installers"
       File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }
    else
       puts "File exits"
       node.default['action_todo'] = File.read(notifications_file)
       if node['action_todo']=="Restart"
          node.default['action_todo'] = "Preparing_Installers"
          File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }
       end
    end
  end
end

execute "Create_Chef_Task_v2" do
	date= Time.new.strftime("%m/%d/%Y")
  time= (Time.new + 60).strftime("%H:%M")
  command "SCHTASKS /create /tn \"BistroDeployPrepInstallers\" /tr \"\\\"cmd\\\" /c c:\\Bistro\\BistroDeploy.exe /LR\" /sc once /sd #{date} /st #{time} /RU #{node['deploy']['taskuser']} /RP #{node['deploy']['taskpass']} /RL HIGHEST /F"
	action :run
  only_if { node['action_todo']=='Start_Prepare_Installers'  && node['BistroVersion']=="2"}
end

execute "Create_Chef_Task_v3" do
	date= Time.new.strftime("%m/%d/%Y")
  time= (Time.new + 60).strftime("%H:%M")
  command "SCHTASKS /create /tn \"BistroDeployPrepInstallers\" /tr \"\\\"cmd\\\" /c c:\\Bistro\\BistroClient.exe --deploy /LR\" /sc once /sd #{date} /st #{time} /RU #{node['deploy']['taskuser']} /RP #{node['deploy']['taskpass']} /RL HIGHEST /F"
	action :run
  only_if { node['action_todo']=='Start_Prepare_Installers'  && node['BistroVersion']=="3"}
end

ruby_block "prepare_to_start" do
  block do

       node.default['action_todo']="Restart"
			 node.default['deploy']['runstatus']="Preparing Installers: Starting"
       File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }

  end
  only_if { node['action_todo']=='Start_Prepare_Installers'}
end


powershell_script 'execute Prepare-RaymarkChefInstallPackages' do
 code <<-EOH
   $existPath = Test-Path "#{node['devops']['WorkingDirPath']}\\Prepare-RaymarkChefInstallPackages"
   if (-Not $existPath)
   {
     Throw "#{node['devops']['WorkingDirPath']}\\Prepare-RaymarkChefInstallPackages path does not exists"
   }

   $existsPkgDir = Test-Path "#{pkg_dir}"
   if (-Not $existsPkgDir)
   {
     Throw "#{pkg_dir} path does not exists"
   }

   $existVersion = Test-Path "#{pkg_dir}\\#{version}"
   if (-Not $existVersion)
	 {
   		#{node['devops']['WorkingDirPath']}\\Prepare-RaymarkChefInstallPackages\\Prepare-RaymarkChefInstallPackages.ps1 -DestDirRootPath "#{pkg_dir}" -Release "#{version}"
   }
   # else
	 # {
	 # #{node['devops']['WorkingDirPath']}\\Prepare-RaymarkChefInstallPackages\\Prepare-RaymarkChefInstallPackages.ps1 -DestDirRootPath "#{pkg_dir}" -TempDirRootPath "#{pkg_dir}" -Release "#{version}" -SkipArtifactDownload -SkipArtifactMove -KeepTempFiles
	 # }

 EOH
 timeout 18000
 action :run
 only_if { node['action_todo']=='Preparing_Installers'}
end



ruby_block "Ending_Process" do
  block do

       node.default['action_todo']="End"
			 node.default['deploy']['runstatus']="Preparing Installers: Ending"
       File.open(notifications_file, 'w') {|f| f.write(node['action_todo']) }

  end
  only_if { node['action_todo']=='Preparing_Installers'}
end


execute "Delete_Chef_Task" do
 command "SCHTASKS /Delete /TN \"BistroDeployPrepInstallers\" /F"
 action :run
 ignore_failure true
 only_if { node['action_todo']=='End'}
end

file 'Delete powershellversion file' do
	path "#{node['windows']['temp_dir']}\\notifications_file_prepinstall.txt"
  action :delete
	only_if {node['action_todo']=='End'}
end

ruby_block "Installing packages" do
  block do
      Chef.run_context.include_recipe 'mi9.raymark::default'
  end
  only_if {node['action_todo']=='End'}
end
