#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.standalone.default
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#
#include_recipe "mi9.raymark::mosaic.standalone.rollback"

node.default['deploy']['runstatus']="Genstandalone start"

#**********************************************
# - Update Big database
#**********************************************

pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"
version = node['mosaic']['version']
art_url = node['mosaic']['depository_url']
node.default['action_todo']=""

#restore database
db_instance = node['sql_server']['instance_name'].empty? ? node['sql_server']['server'] : "#{node['sql_server']['server']}\\#{node['sql_server']['instance_name']}"
db_name = node['mosaic']['sql_db_name']

#Download db files templates
remote_file 'download_db-scripts' do
  path "#{pkg_dir}\\db-scripts #{version}.zip"
  source "#{art_url}/#{version}/db-scripts #{version}.zip"
end

powershell_script "Unziping db-scripts" do
  code <<-EOH

    $Zipfile = "#{pkg_dir}\\db-scripts #{version}.zip"
    $Destination = "#{pkg_dir}\\db-scripts #{version}"
    Add-Type -assembly "system.io.compression.filesystem"
    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
    EOH
    guard_interpreter :powershell_script
  not_if { ::File.directory?("#{pkg_dir}\\db-scripts #{version}")}
end

ruby_block "Replacing value in DS_Syncline_Setting.sql" do
  block do
    text = File.read("#{pkg_dir}\\db-scripts #{version}\\11- DS_Syncline_Setting.sql")
    new_contents = text.gsub("<Http Address, sysname, http://>", "#{node['mosaic']['masterdb']['httpaddress']}")
    new_contents = new_contents.gsub("<Ftp Address, sysname, ftp://>", "#{node['mosaic']['masterdb']['ftpaddress']}")
    new_contents = new_contents.gsub("<ftp user, sysname, username>", "#{node['mosaic']['masterdb']['ftpuser']}")
    new_contents = new_contents.gsub("<ftp password, sysname, password>", "#{node['mosaic']['masterdb']['ftppassword']}")

    File.open("#{pkg_dir}\\db-scripts #{version}\\11- DS_Syncline_Setting.sql", "w") {|file| file.puts new_contents }
  end
end

#Create New DB Backup folder
directory 'Create Backup dbdir folder'  do
	path node['mosaic']['masterdb']['backup']['dbdir']
	action :create
	not_if { ::File.directory?(node['mosaic']['masterdb']['backup']['dbdir'])}
end

directory 'Create Backup standalone folder'  do
	path "#{node['mosaic']['masterdb']['backup']['dbdir']}\\standalone"

	action :create
	not_if { ::File.directory?("#{node['mosaic']['masterdb']['backup']['dbdir']}\\standalone")}
end

puts "#{node['mosaic']['sql_user']}"
puts "#{node['mosaic']['sql_pwd']}"
puts "#{node['mosaic']['sql_db_name']}"
puts "#{node['mosaic']['masterdb']['backup']['dbdir']}\\#{db_name}_db_bkp.bak"
puts "#{node['mosaic']['masterdb']['backup_master']}"
puts "#{db_instance}"
#Backup MasterDB database
powershell_script "Backup MasterDatabase" do
  code <<-EOH

	       [system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
	       [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
	       [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

					$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
					$sqlConn.ServerInstance="#{db_instance}"
				  $sqlConn.LoginSecure = $false
				  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
				  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

					$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
          $server.ConnectionContext.StatementTimeout=0
					$backup = new-object Microsoft.SqlServer.Management.Smo.Backup
					$found = $server.Databases.Contains("#{node['mosaic']['sql_db_name']}")
					if ($found)
					{
							$backup.Devices.AddDevice("#{node['mosaic']['masterdb']['backup']['dbdir']}\\#{db_name}_db_bkp.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
							$backup.Database = "#{node['mosaic']['sql_db_name']}"
              $backup.CompressionOption = 1
							$backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
							$backup.Initialize = $TRUE
							$backup.SqlBackup($server)

					}

    EOH
  timeout 18000
  guard_interpreter :powershell_script
  only_if { node['mosaic']['masterdb']['backup_master']}

end

powershell_script "Restoring database as standalone" do
	code <<-EOH
		## - Loads the SQL Server SMO Assembly:
		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
		[system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
	  [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

		$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
		$sqlConn.ServerInstance="#{db_instance}"
	  $sqlConn.LoginSecure = $false
	  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
	  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

		$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
    $server.ConnectionContext.StatementTimeout=0
		$res = new-object Microsoft.SqlServer.Management.Smo.Restore
		## $backup = new-object Microsoft.SqlServer.Management.Smo.Backup
	  $server.KillAllProcesses('standalone')
	  # $error[0]|format-list –force

		$found = $server.Databases.Contains("standalone")

		$res.Devices.AddDevice("#{node['mosaic']['masterdb']['backup']['dbdir']}\\#{db_name}_db_bkp.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
		$res.Database = "standalone"
		$res.NoRecovery = $false
		$res.FileNumber = 1
		$res.ReplaceDatabase = $true;
		$smoRestoreDetails = $res.ReadFileList($server)

		foreach($r in $smoRestoreDetails.Rows)
		{
				$smoRestoreFile = New-Object("Microsoft.SqlServer.Management.Smo.RelocateFile")

				$smoRestoreFile.LogicalFileName = $r["LogicalName"]
			#	$smoRestoreFile.PhysicalFileName = $server.Information.MasterDBPath.ToString() +"\\"+ $r["PhysicalName"].Substring($r["PhysicalName"].LastIndexOf('\\')+1)
			  if ($r["Type"] -eq "D"){
					$smoRestoreFile.PhysicalFileName = "#{node['mosaic']['masterdb']['datapath']}\\standalone.mdf"
				}else{
					$smoRestoreFile.PhysicalFileName = "#{node['mosaic']['masterdb']['datapath']}\\standalone_log.ldf"
				}
				$res.RelocateFiles.Add($smoRestoreFile)
		}

		$res.SqlRestore($server)

	#  Write-Output $error[0]|format-list

	EOH
  timeout 18000
	guard_interpreter :powershell_script
	only_if { node['mosaic']['masterdb']['backup_master'] and ::File.file?("#{node['mosaic']['masterdb']['backup']['dbdir']}\\#{db_name}_db_bkp.bak")}
end

ruby_block "Executing scripts" do
  block do
    #Running store procedure scripts located in db-scripts
    if ( ::File.directory?("#{pkg_dir}\\db-scripts #{version}"))
      path = "#{pkg_dir}\\db-scripts #{version}"
      path = path.gsub /\\+/, '/'
      scripts = Dir.glob("#{path}/*.sql").sort
      i= 0
      scripts.each do |script|
      #Dir.glob("#{pkg_dir}/db-scripts #{version}/*.sql").sort do |script|
        puts "#{script}"
        next if script == '.' or script == '..'
          object = Chef::Resource::Execute.new("Script #{script}", run_context)
          object.timeout 18000
          object.command "\"#{node['windows']['sqlcmd_path_exe']}\"  /S \"#{db_instance}\" /d standalone -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{script}\" -o \"#{pkg_dir}\\db-scripts #{version}\\out_#{i}.txt\""
          object.run_action :run

        #execute "Script #{script}" do
        #  command "\"#{node['windows']['sqlcmd_path']}\\Sqlcmd.exe\"  /S \"#{db_instance}\" /d #{node['mosaic']['sql_db_name']} -U #{node['mosaic']['sql_user']}  -P #{node['mosaic']['sql_pwd']}  -C -i \"#{script}\" -o \"#{pkg_dir}\\db-scripts #{version}\\out_#{i}.txt\""
        #end
        i = i + 1
      end
    end
  end
end


ruby_block "Concatening output files" do
  block do
    if ( ::File.directory?("#{pkg_dir}\\db-scripts #{version}"))
      path = "#{pkg_dir}\\db-scripts #{version}"
      path = path.gsub /\\+/, '/'
      outputs = Dir.glob("#{path}/out_*.txt").sort
      hole_content = ""
      outputs.each do |output|
        next if output == '.' or output == '..'
        file = File.open("#{output}", "rb")
        nextContents = file.read
        hole_content = hole_content + nextContents

      end

      File.open("#{node['mosaic']['masterdb']['execution_result_filename']}", "w") {|file| file.puts hole_content }
    end

  end

end

powershell_script "Backup Standalone" do
  code <<-EOH

	       [system.reflection.assembly]::LoadWithPartialName("Microsoft.SQLServer.Smo") | Out-Null;
	       [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null;
	       [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null;

					$sqlConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
					$sqlConn.ServerInstance="#{db_instance}"
				  $sqlConn.LoginSecure = $false
				  $sqlConn.Login = "#{node['mosaic']['sql_user']}"
				  $sqlConn.Password = "#{node['mosaic']['sql_pwd']}"

					$server = new-object Microsoft.SqlServer.Management.Smo.Server($sqlConn)
					$backup = new-object Microsoft.SqlServer.Management.Smo.Backup
					$found = $server.Databases.Contains("#{node['mosaic']['sql_db_name']}")
					if ($found)
					{
							$backup.Devices.AddDevice("#{node['mosaic']['masterdb']['backup']['dbdir']}\\standalone\\standalone.bak", [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
							$backup.Database = "standalone"
							$backup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
              $backup.CompressionOption = 1
							$backup.Initialize = $TRUE
							$backup.SqlBackup($server)

					}

    EOH
  guard_interpreter :powershell_script
  only_if { node['mosaic']['masterdb']['backup_standalone']}
end

powershell_script "Compress Standalone backup" do
  code <<-EOH

    $source = "#{node['mosaic']['masterdb']['backup']['dbdir']}\\standalone"

    $destination = "#{node['mosaic']['masterdb']['sharedfolder']}\\standalone.zip"
    If(Test-path $destination) {Remove-item $destination}
    Add-Type -assembly "system.io.compression.filesystem"

    $compressionLevel= [System.IO.Compression.CompressionLevel]::Optimal
    [io.compression.zipfile]::CreateFromDirectory($Source, $destination,$compressionLevel, $false)


   #  Compress-Archive -LiteralPath "#{node['mosaic']['masterdb']['backup']['dbdir']}\\standalone\\standalone.bak" -CompressionLevel Optimal -DestinationPath

  EOH
guard_interpreter :powershell_script
only_if { node['mosaic']['masterdb']['backup_standalone']}
end

powershell_script 'Send Email with Gmail' do
		code <<-EOH
            $smtpClient = new-object system.net.mail.smtpClient
            $smtpClient.Host = 'smtp.gmail.com'
            $smtpClient.Port = 587
            $smtpClient.EnableSsl = $true
            $SMTPClient.Credentials = New-Object System.Net.NetworkCredential("devops@mi9retail.com", "M19D3v0ps");

            $emailfrom = "devops@mi9retail.com"
            $emailto = "#{node['mosaic']['masterdb']['emailnotification']}"
            $subject = "Deployment notification"
            $body = "See the file attached."

            $emailMessage = New-Object System.Net.Mail.MailMessage
            $emailMessage.From = $EmailFrom
            $emailMessage.To.Add($EmailTo)
            $emailMessage.Subject = $Subject
            $emailMessage.Body = $Body
            $emailMessage.Attachments.Add("#{node['mosaic']['masterdb']['execution_result_filename']}")
            $SMTPClient.Send($emailMessage)
			 EOH

		guard_interpreter :powershell_script
		only_if { node['mosaic']['masterdb']['backup_standalone']}
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="GenStandalone deploy Successfully\n"
  end
end
