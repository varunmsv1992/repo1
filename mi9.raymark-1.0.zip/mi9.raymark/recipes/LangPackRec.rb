#
# Cookbook:: LangPack
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.
version ="#{node['mosaic']['langpack_version']}"
pkg_dir = "#{node['mosaic']['artifacts_dir']}"
#   #{node['mosaic']['version']}
lp_pack = "#{pkg_dir}\\#{node['mosaic']['version']}\\LP_Mosaic-affinity#{node['mosaic']['version']}"
#RAMS
Deploy_languagepack 'RAMS' do
  physical_path  node['mosaic']['affinity']['RAMS']['physical_path']
  installer_dir "#{lp_pack}\\Affinity\\Affinity-Merchandising #{version}"
  iis_publication_type node['mosaic']['affinity']['installation_type']
  iis_root node['mosaic']['affinity']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#REMS
Deploy_languagepack 'RESM' do
  physical_path  node['mosaic']['affinity']['RESM']['physical_path']
  installer_dir "#{lp_pack}\\Affinity\\Affinity-Enterprise Solution Manager #{version}"
  iis_publication_type node['mosaic']['affinity']['installation_type']
  iis_root node['mosaic']['affinity']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#REPAIRS
Deploy_languagepack 'REPAIRS' do
  physical_path  node['mosaic']['affinity']['REPAIRS']['physical_path']
  installer_dir "#{lp_pack}\\Affinity\\Affinity-repairs #{version}"
  iis_publication_type node['mosaic']['affinity']['installation_type']
  iis_root node['mosaic']['affinity']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#RCRM
Deploy_languagepack 'RCRM' do
  physical_path  node['mosaic']['affinity']['RCRM']['physical_path']
  installer_dir "#{lp_pack}\\Affinity\\Affinity-Customer Relationship Management #{version}"
  iis_publication_type node['mosaic']['affinity']['installation_type']
  iis_root node['mosaic']['affinity']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#MOSAIC desktop app
Deploy_languagepack 'Mosaic' do
  physical_path  node['mosaic']['pos']['MosaicApp']['physical_path']
  installer_dir "#{lp_pack}\\mosaic"
  iis_publication_type node['mosaic']['affinity']['installation_type']
  iis_root node['mosaic']['affinity']['iis_root']
  action :deploypack
#  only_if {::File.directory?(physical_path)}
end
#mosaic web app
Deploy_languagepack 'Mosaicweb' do
  physical_path  node['mosaic']['webservice']['MosaicApp']['physical_path']
  installer_dir "#{lp_pack}\\mosaic\\www"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#CRA
Deploy_languagepack 'CRA' do
  physical_path  node['mosaic']['webservice']['CRA']['physical_path']
  installer_dir "#{lp_pack}\\webservice\\CRAService.mosaic"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#POSservice
Deploy_languagepack 'POSservice' do
  physical_path  node['mosaic']['webservice']['POSservice']['physical_path']
  installer_dir "#{lp_pack}\\webservice\\POSservice.rest"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#POSWSPublicREST
Deploy_languagepack 'POSWSPublicREST' do
  physical_path  node['mosaic']['webservice']['POSWSPublicREST']['physical_path']
  installer_dir "#{lp_pack}\\webservice\\posservicepublic.rest"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
#CMService
Deploy_languagepack 'cmservice' do
  physical_path  node['mosaic']['webservice']['CMService']['physical_path']
  installer_dir "#{lp_pack}\\webservice\\cmservice"
  iis_publication_type node['mosaic']['webservice']['iis_publication_type']
  env node['mosaic']['env']
  iis_root node['mosaic']['webservice']['iis_root']
  action :deploypack
  #only_if {::File.directory?(physical_path)}
end
