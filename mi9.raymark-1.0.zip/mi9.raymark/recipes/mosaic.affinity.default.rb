#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.affinity.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="affinity_start"

ruby_block "verify affinity HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'affinity_verify'
      if node['filesystem']['C:']['kb_available'] < node['mosaic']['affinity']['min_kb_available']
          fail "The affinity HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

if node['mosaic']['affinity']['rollback']['apps']
  raymark_rollback 'Rollback_backup_apps_folder' do
    puts node['mosaic']['affinity']['backup']['appsdir']
    backup_folder node['mosaic']['affinity']['backup']['appsdir']
    action :nothing
  end

  #delete affinity folder
  directory 'Delete_folders_in_affinity'  do
    path node['mosaic']['affinity']['iis_root_env']
    recursive true
  	action :nothing
  end

  powershell_script "Restoring_affinity_folders" do
    code <<-EOH
      $Zipfile = "#{node['mosaic']['affinity']['backup']['appsdir']}\\#{node['mosaic']['affinity']['backup']['appszip']}"
      $Destination = "#{node['mosaic']['affinity']['iis_root_env']}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
    guard_interpreter :powershell_script
    action :nothing
  end
end

if node['mosaic']['affinity']['backup']['apps']
  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['mosaic']['backup']['maindir']
    backup_folder node['mosaic']['affinity']['backup']['appsdir']
    action :backup
  end

  powershell_script "Backup affinity" do
    code <<-EOH
  					[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
  					$src_folder = "#{node['mosaic']['affinity']['iis_root_env']}"
  					$destfile = "#{node['mosaic']['affinity']['backup']['appsdir']}\\#{node['mosaic']['affinity']['backup']['appszip']}"
  					$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
  					$includebasedir = $false
  					[System.IO.Compression.ZipFile]::CreateFromDirectory($src_folder,$destfile,$compressionLevel, $includebasedir )
      EOH
    guard_interpreter :powershell_script
    only_if {::File.directory?(node['mosaic']['affinity']['iis_root_env'])}
  end

  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="affinity_backup"
    end
  end
end

#make update
ruby_block "make affinity update" do
  block do
      node.default['deploy']['runstatus']="affinity_update"
      Chef.run_context.include_recipe 'mi9.raymark::mosaic.affinity.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="affinity deploy Successfully\n"
  end
end

#post update
#delete backup appsdir_last folder
directory 'delete backup appsdir_last folder'  do
  #puts "Deleting #{node['mosaic']['affinity']['backup']['appsdir']}_last"
	path "#{node['mosaic']['affinity']['backup']['appsdir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['mosaic']['affinity']['backup']['appsdir']}_last") }
end
