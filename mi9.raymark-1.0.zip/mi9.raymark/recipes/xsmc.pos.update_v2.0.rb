#
# Cookbook Name:: mi9.raymark
# Recipe:: xsmc.pos.update
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute

# actions
# - Download actifacts
# - Preparing update
# – Update xsmc 2.0 or higther


#**********************************************
# - Download actifacts
#**********************************************

pkg_dir = "#{node['xsmc']['artifacts_dir']}\\#{node['xsmc']['version']}"

version = node['xsmc']['version']
prev_version = node['xsmc']['prev_version']
art_url = node['xsmc']['depository_url']
art_dir="XSMC "

#Creating pkg_dir/xsmc folder
directory pkg_dir do
  action :create
  not_if { ::File.directory?(pkg_dir)}
end

remote_file "#{pkg_dir}\\#{node['xsmc']['pos']['artifact']}" do
 source "#{art_url}/#{version}/#{node['xsmc']['pos']['artifact']}"
 not_if { ::File.exists?("#{pkg_dir}\\#{node['xsmc']['pos']['artifact']}")}
end


#**********************************************
# - Preparing update.
# backup App.ini file
#**********************************************
=begin
ruby_block 'Backup App.ini' do
  block do
    FileUtils.cp "#{node['xsmc']['pos']['newpath']}\\App.ini","#{pkg_dir}/App.ini"
  end
  only_if { ::File.file?("#{node['xsmc']['pos']['newpath']}\\App.ini")}
end
=end
#**********************************************
# – Update xsmc
#**********************************************

powershell_script "Close XSMC app" do
  code <<-EOH
    try{
					$process = Get-Process "XSMC" -ErrorAction Stop
					if ($process -ne $Null -and $process -ne ''){
								 Get-Process "XSMC" | stop-process -Force
					}
    }catch [System.Exception] {
        Write-Output $_.Exception.Message
    }
    EOH
  guard_interpreter :powershell_script
end
puts node['xsmc']['prev_version']

powershell_script "Uninstall XSMC" do
  code <<-EOH
        $app = Get-WmiObject -Class Win32_Product | Where-Object {
          $_.Name -match "#{node['xsmc']['pos']['nametouninstall']}"
        }
        if($app -ne $null)
          {
            $app.Uninstall()
          }

    EOH
  guard_interpreter :powershell_script
  only_if { node['xsmc']['pos']['typeofuninstall']=='direct' && Gem::Version.new(node['xsmc']['prev_version']) < Gem::Version.new('2.0.0.0')}
end

powershell_script 'Uninstall XSMC' do
  code <<-EOH
    $succeeded = import-module WebAdministration
    if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
     #Could not import, trying to snapin
     add-pssnapin WebAdministration
    }

    $arch = gwmi win32_operatingsystem | select osarchitecture
    $regName = ""
    if ($arch.osarchitecture -eq "32-bit")
    {
     $regName = "SOFTWARE"
    }
    else
    {
     $regName = "SOFTWARE\\Wow6432Node"
    }
    $path = "HKLM:\\$regName\\Microsoft\\Windows\\CurrentVersion\\Uninstall"
    $uninstall = (gci $path | foreach { gp $_.PSPath } | ? { $_ -match "XSM Client" } | select UninstallString)

    if ($uninstall) {

     $upath = $uninstall.UninstallString | Where-Object {$_ -match "MsiExec.exe"}
     # $upath
     $posI = $upath.IndexOf("/X")
     # $posI
     $upath = $upath.Substring($posI+2,38)
     $upath = $upath.Trim()
     # Write-output $upath
     start-process "MsiExec.exe" -arg "/X$upath /q /norestart" -Wait

    }
  EOH
  guard_interpreter :powershell_script
  only_if { node['xsmc']['pos']['typeofuninstall']=='direct' && Gem::Version.new(node['xsmc']['version']) >= Gem::Version.new('2.0.0.0')}
#  notifies :run, 'execute[Install Raymark Mosaic for Windows]', :immediately
end

#delete XSCM folder if it exists
directory 'delete backup XSMC folder'  do
  path "#{node['xsmc']['pos']['path']}"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['xsmc']['pos']['path']}")}
end

#Creating phisical folders to store the websites
directory node['xsmc']['pos']['newpath'] do
  recursive true
  action :create
	not_if {::File.directory?(node['xsmc']['pos']['newpath'])}
end

report_app_installed_v2 'reporting XSMC installed' do
    appname 'XSMC'
    version node['xsmc']['version']
    path node['xsmc']['pos']['newpath']
    details "WebSite"
    action :nothing
end

#Installing XSMC for Windows.
execute "msiexec /i #{pkg_dir}\\#{node['xsmc']['pos']['artifact']} /qn INSTALLDIR=\"#{node['xsmc']['pos']['newpath']}\"" do
  action :run
  only_if { ::File.file?("#{pkg_dir}\\#{node['xsmc']['pos']['artifact']}")}
  notifies :send, 'report_app_installed_v2[reporting XSMC installed]', :immediately
end

ruby_block 'Deleting App.ini template file' do
  block do
    FileUtils.remove_file "#{node['xsmc']['pos']['newpath']}\\App.ini", true
  end
  only_if { ::File.file?("#{node['xsmc']['pos']['newpath']}\\App.ini")}
end

ruby_block 'Restauring App.ini' do
  block do
    FileUtils.cp "#{pkg_dir}/App.ini", "#{node['xsmc']['pos']['newpath']}\\App.ini"
  end
  only_if { ::File.file?("#{pkg_dir}/App.ini")}
end

#Apply template: App.ini
template "#{node['xsmc']['pos']['newpath']}/App.ini" do
  source "XSMC/App.ini_v2.0.erb"
  not_if { ::File.file?("#{pkg_dir}/App.ini")}
end


#Apply template: App.ini
template "#{node['xsmc']['pos']['newpath']}/XSMC.exe.config" do
  source "XSMC/XSMC.exe.config_v2.0.erb"
end
