#
# Cookbook Name:: mi9.raymark
# Recipe:: xpert.central.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

node.default['deploy']['runstatus']="xpert_start"

ruby_block "verify HDD space" do
  block do
      node.default['deploy']['runstatus'] = 'xpert_verify'
      if node['filesystem']['C:']['kb_available']< node['xpert']['pos']['min_kb_available']
          fail "The HDD space is not enough, current HDD space is #{node['filesystem']['C:']['kb_available']}"
      end
  end
end

if node['xpert']['pos']['rollback']['xpert']
  raymark_rollback 'Rollback_backup_xpert_pos_folder' do
    backup_folder node['xpert']['pos']['backup']['dir']
    action :nothing
  end

  directory 'Delete_folders_in_XPERT_Pos'  do
    path node['xpert']['pos']['path']
    recursive true
  	action :nothing
  end

  powershell_script "Restoring_XPERT_Pos_folders" do
    code <<-EOH
      $Zipfile = "#{node['xpert']['pos']['backup']['dir']}\\#{node['xpert']['pos']['backup']['zip']}"
      $Destination = "#{node['xpert']['pos']['path']}"
      Add-Type -assembly "system.io.compression.filesystem"
      [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
      EOH
    guard_interpreter :powershell_script
    action :nothing
    only_if { node['xpert']['pos']['backup']['dir'] and ::File.directory?(node['xpert']['pos']['path']) }
  end
end

if node['xpert']['pos']['backup']['xpert']

  ruby_block "change runstatus" do
    block do
        node.default['deploy']['runstatus']="xpert_backup"
    end
  end

  #make a backup
  raymark_backup 'Create backup folder' do
    backup_mainfolder node['xpert']['backup']['maindir']
    backup_folder node['xpert']['pos']['backup']['dir']
    action :backup
  end

  powershell_script "Backup Xpert" do
    code <<-EOH
  					[Reflection.Assembly]::LoadWithPartialName( "System.IO.Compression.FileSystem" )
  					$src_folder = "#{node['xpert']['pos']['path']}"
  					$destfile = "#{node['xpert']['pos']['backup']['dir']}\\#{node['xpert']['pos']['backup']['zip']}"
  					$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
  					$includebasedir = $false
  					[System.IO.Compression.ZipFile]::CreateFromDirectory($src_folder,$destfile,$compressionLevel, $includebasedir )
      EOH
    guard_interpreter :powershell_script
    only_if { node['xpert']['pos']['backup']['xpert'] and ::File.directory?(node['xpert']['pos']['path']) }
  end
end

#make update
ruby_block "make xpert update" do
  block do
      node.default['deploy']['runstatus']="xpert_update"
      Chef.run_context.include_recipe 'mi9.raymark::xpert.central.update'
  end
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="Xpert deploy Successfully\n"
  end
end

#post update
directory 'delete backup Xpert dir_last folder'  do
  puts "Deleting #{node['xpert']['pos']['backup']['dir']}_last"
	path "#{node['xpert']['pos']['backup']['dir']}_last"
  recursive true
	action :delete
  only_if { ::File.directory?("#{node['xpert']['pos']['backup']['dir']}_last")}
end
