#
# Cookbook Name:: mi9.raymark
# Recipe:: xpert.pos.update
#
# Copyright 2016, Mi9_Retail
#
# All rights reserved - Do Not Redistribute

# actions
# - Download actifacts
# - Preparing update
# – Update xpert


#**********************************************
# - Download actifacts
#**********************************************
#xpert .zip

pkg_dir = "#{node['xpert']['artifacts_dir']}\\#{node['xpert']['version']}"
version = node['xpert']['version']
art_url = node['xpert']['depository_url']

#Creating pkg_dir
directory pkg_dir do
  action :create
  not_if { ::File.directory?(pkg_dir)}
end

node['xpert']['pos']['artifacts'].each do |art|
  puts "Downloading #{art}"
  artEncoded = art.dup
  if art_url.include? "http"
    artEncoded = artEncoded.gsub! ' ', '%20'
    artEncoded = artEncoded.nil? ? art : artEncoded
  end
  remote_file "#{pkg_dir}\\#{art}#{version}.zip" do
   source "#{art_url}/#{version}/#{artEncoded}#{version}.zip"
	#not_if { ::File.exists?("#{pkg_dir}\\#{art}#{version}.zip")}
  end
end

#**********************************************
# - Preparing update
#**********************************************

node['xpert']['pos']['artifacts'].each do |art|
  puts "Unzipping #{art}"
  directory "#{pkg_dir}\\#{art}#{version}" do
    recursive true
    action :delete
  	only_if {::File.directory?("#{pkg_dir}\\#{art}#{version}")}
  end
	powershell_script "Unziping artifact #{art} " do
	  code <<-EOH
      $Zipfile = "#{pkg_dir}\\#{art}#{version}.zip"
			$Destination = "#{pkg_dir}\\#{art}#{version}"
	    Add-Type -assembly "system.io.compression.filesystem"
	    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
	    EOH
	    guard_interpreter :powershell_script
	  #not_if { ::File.directory?("#{pkg_dir}\\#{art}#{version}")}
	end

end


ruby_block 'Backup License.dat' do
  block do
    FileUtils.cp "#{node['xpert']['pos']['path']}\\License.dat","#{pkg_dir}/License.dat"
  end
  only_if { ::File.file?("#{node['xpert']['pos']['path']}\\License.dat")}
end


#Creating phisical folders to store the websites
directory node['xpert']['pos']['path'] do
  recursive true
  action :create
	not_if {::File.directory?(node['xpert']['pos']['path'])}
end


#**********************************************
# – Update Xpert
#**********************************************

#delete previous version
directory node['xpert']['pos']['path'] do
  recursive true
  action :delete
	only_if {node['xpert']['pos']['path']}
end

#Creating folder
directory node['xpert']['pos']['path'] do
  action :create
  not_if { ::File.directory?(node['xpert']['pos']['path'])}
end

#Update files
ruby_block 'Copy Xpert files' do
  block do
    FileUtils.cp_r "#{pkg_dir}/Xpert-central #{version}/.",node['xpert']['pos']['path']
  end
  only_if { ::Dir.entries(node['xpert']['pos']['path']) == ['.', '..']} #if the folder is empty
end


#Apply template: posinet.ini
template "#{node['xpert']['pos']['path']}\\posisent.ini" do
  source "xpert/posisent.ini.erb"

end

#Apply template: opos.ini
template "#{node['xpert']['pos']['path']}\\opos.ini" do
  source "xpert/opos.ini.erb"

end


ruby_block 'Restauring License.dat' do
  block do
    FileUtils.cp "#{pkg_dir}/License.dat", "#{node['xpert']['pos']['path']}\\License.dat"
  end
  only_if { ::File.file?("#{pkg_dir}/License.dat")}
end

#Restoring templates files
ruby_block 'Copy XMLTemplates' do
  block do
    FileUtils.cp_r "#{node['mosaic']['programfile_dir']}\\Raymark\\RunTime\\XMLTemplates/.","#{node['mosaic']['programfile_dir']}\\Raymark\\Xpert-Central\\Main\\XMLTemplates\\"
  end
  not_if { ::Dir.entries("#{node['mosaic']['programfile_dir']}\\Raymark\\RunTime\\XMLTemplates") == ['.', '..']} #if the folder is empty
end
