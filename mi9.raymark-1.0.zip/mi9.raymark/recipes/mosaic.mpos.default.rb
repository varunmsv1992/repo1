#
# Cookbook Name:: mi9.raymark
# Recipe:: mosaic.pos.default
#
# Copyright 2017, Mi9_Retail
#
# All rights reserved - Do Not Redistribute
#

# actions
# - Download actifacts
# – Update Mosaic POS


#**********************************************
# - Download actifacts
#**********************************************
node.default['deploy']['runstatus']="MPOS start"

pkg_dir = "#{node['mosaic']['artifacts_dir']}\\#{node['mosaic']['version']}"

version = node['mosaic']['version']

art_url = node['mosaic']['depository_url']



#############################
# Uninstalling  previous version
#############################
prev_version = node['mosaic']['prev_version']

#backing up the registry entries
# before uninstall of previous version, export mosaic registry
# x64
batch "export_mosaic_registry_64" do
  code <<-EOH
  REG EXPORT HKEY_LOCAL_MACHINE\\SOFTWARE\\WOW6432Node\\Raymark\\Mosaic #{node['download']['destination']}\\mosaic.reg /y
  EOH
  timeout 18000
  only_if { node['kernel']['os_info']['os_architecture'] == '64-bit' }
end
# x86
batch "export_mosaic_registry_32" do
  code <<-EOH
  REG EXPORT HKEY_LOCAL_MACHINE\\SOFTWARE\\Raymark\\Mosaic #{node['download']['destination']}\\mosaic.reg /y
  EOH
  timeout 18000
  only_if { node['kernel']['os_info']['os_architecture'] != '64-bit' }
end


#**********************************************
# – Installing the new version
#**********************************************
directory pkg_dir do
  action :create
  not_if { ::File.directory?(pkg_dir)}
end

#download MosaicSetupFull new version
remote_file "#{pkg_dir}\\MosaicSetupFull-#{version}.exe" do
 source "#{art_url}/#{version}/MosaicSetupFull-#{version}.exe"
 not_if { ::File.exists?("#{pkg_dir}\\MosaicSetupFull-#{version}.exe")}
end
#Uninstalling Raymark Mosaic previous version for Windows.
powershell_script 'uninstallMosaic' do
  code <<-EOH
    $succeeded = import-module WebAdministration
    if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
     #Could not import, trying to snapin
     add-pssnapin WebAdministration
    }

    $arch = gwmi win32_operatingsystem | select osarchitecture
    $regName = ""
    if ($arch.osarchitecture -eq "32-bit")
    {
     $regName = "SOFTWARE"
    }
    else
    {
     $regName = "SOFTWARE\\Wow6432Node"
    }
    $path = "HKLM:\\$regName\\Microsoft\\Windows\\CurrentVersion\\Uninstall"
    $uninstall = (gci $path | foreach { gp $_.PSPath } | ? { $_ -match "MI9 Mosaic for Windows v" } | select UninstallString)
    if ($uninstall) {
     $upath = $uninstall.UninstallString | Where-Object {$_ -match "ProgramData"}
    # $upath
     $upath = $upath -Replace "msiexec.exe","" -Replace "/I","" -Replace "/X","" -Replace "/uninstall",""
     $upath = $upath.Trim()
    # Write-output $upath
    start-process $upath -arg "/uninstall /q /norestart" -Wait

    }
  EOH
  notifies :run, 'execute[Install Raymark Mosaic for Windows]', :immediately
end

#Installing Raymark Mosaic for Windows.
execute "Install Raymark Mosaic for Windows" do
  command "#{pkg_dir}/MosaicSetupFull-#{version}.exe /q"
  action :nothing
  only_if { ::File.directory?("#{pkg_dir}")}
end

#Installing new version
ruby_block 'Copy Mosaic files' do
  block do
    FileUtils.cp_r "#{pkg_dir}/Mosaic-#{version}/.",node['mosaic']['pos']['MosaicApp']['physical_path']
  end
  only_if { ::Dir.entries(node['mosaic']['pos']['MosaicApp']['physical_path']) == ['.', '..']} #if the folder is empty
end

#download MasterServer map

puts "store map defined = #{node['mosaic']['pos']['storemap_defined']}"
if (node['mosaic']['pos']['storemap_defined'])

    remote_file "#{pkg_dir}\\storemap.json" do
     source "#{art_url}/#{version}/storemap.json"
    end

    ruby_block 'Loading StoreMap' do
      block do

        def downcase_hash_keys(h)
          if h.is_a?(Hash)
            h.keys.each do |key|
              new_key = key.to_s.downcase
              h[new_key] = h.delete(key)
              downcase_hash_keys(h[new_key])
            end
          elsif h.respond_to?(:each)
            h.each { |e| downcase_hash_keys(e) }
          end
          h
        end

        if File.file?("#{pkg_dir}\\storemap.json")
        	require 'json'
        	file = File.read("#{pkg_dir}\\storemap.json")
        	data_hash = JSON.parse(file)
        	downcase_hash_keys(data_hash)
          puts data_hash
          puts "#{node['hostname']}"

        	#puts data_hash["#{node['hostname']}"]
        	node.default['mosaic']['offlineServer'] = data_hash["#{node['hostname']}".to_s.downcase]['masterpos']

        	puts node['mosaic']['offlineServer']

        else
        	puts "the system can't find the storemap file. Current node #{node['hostname']}"
        end
      end
      only_if { ::File.file?("#{pkg_dir}\\storemap.json")} #if the folder is empty
    end


end

puts "offlineserver = #{node['mosaic']['offlineServer']}"

#Apply template: serverSettings.js
template "#{node['mosaic']['pos']['MosaicApp']['physical_path']}/App_js/serverSettings.js" do
  source "#{pkg_dir}\\configs #{version}\\pos\\App_js.serverSettings.js.erb"
  local true
end

#Apply templates serverSettings.js and sysSettings.js for the rest of mosaic internal apps
node['mosaic']['pos']['MosaicApp']['apps'].each do |app|
  puts "Applying template for #{app}"
    template "#{node['mosaic']['pos']['MosaicApp']['physical_path']}/#{app}/App_js/serverSettings.js" do
      source "#{pkg_dir}\\configs #{version}\\pos\\#{app}.serverSettings.js.erb"
      local true
    end
end

# apply previous versions registry settings
batch 'import_previous_registry' do
  code <<-EOH
  REG IMPORT #{node['download']['destination']}\\mosaic.reg
  EOH
  timeout 18000
  only_if { ::File.exists?("#{node['download']['destination']}\\mosaic.reg")}
end

tt = ''

ruby_block 'generate_unique_timestamp' do
  block do
    ttt = Time.now.to_i
    tt = ttt.to_s
  end
  only_if { ::File.exists?("#{node['download']['destination']}\\mosaic.reg")}
end

# rename old reg file for the next run, if the recipe got this far
ruby_block 'rename_mosaic_registry' do
  block do
    ::File.rename("#{node['download']['destination']}\\mosaic.reg", "#{node['download']['destination']}\\mosaic-#{tt}.reg")
  end
  only_if { ::File.exists?("#{node['download']['destination']}\\mosaic.reg")}
end

=begin
registry_key 'HKEY_LOCAL_MACHINE\SOFTWARE\Raymark\Mosaic' do
  architecture :i386
#  recursive true
  values [{:name => 'PeripheralAllowed', :type => :dword, :data => node['mosaic']['pos']['MosaicApp']['config']['PeripheralAllowed'] }
         ]
  action :create
  only_if {node['mosaic']['pos']['MosaicApp']['config']['setup']}
end
=end

=begin
values [{:name => 'PeripheralAllowed', :type => :dword, :data => node['mosaic']['pos']['MosaicApp']['config']['PeripheralAllowed'] },
        {:name => 'DefaultCashDrawerId', :type => :string, :data => "#{node['mosaic']['pos']['MosaicApp']['config']['DefaultCashDrawerId']}"},
        {:name => 'DefaultLineDisplayId', :type => :string, :data => "#{node['mosaic']['pos']['MosaicApp']['config']['DefaultLineDisplayId']}"},
        {:name => 'DefaultMSReaderId', :type => :string, :data => "node['mosaic']['pos']['MosaicApp']['config']['DefaultMSReaderId']}"},
        {:name => 'DefaultMICRId', :type => :string, :data => "#{node['mosaic']['pos']['MosaicApp']['config']['DefaultMICRId']}"},
        {:name => 'DefaultPrinterId', :type => :string, :data => "#{node['mosaic']['pos']['MosaicApp']['config']['DefaultPrinterId']}"},
        {:name => 'DefaultScannerId', :type => :string, :data => "#{node['mosaic']['pos']['MosaicApp']['config']['DefaultScannerId']}"},
        {:name => 'LocaleName', :type => :string, :data => "#{node['mosaic']['pos']['MosaicApp']['config']['LocaleName']}"},
       ]
=end

apply_patch 'artifacts' do
   artifacts node['mosaic']['pos']['MosaicApp']['patches']['patchfiles']
   action :apply
   only_if {node['mosaic']['pos']['MosaicApp']['patches']['apply']}# && node['mosaic']['pos']['MosaicApp']['patches'].attribute?('patchfiles') }
end

#Add key to POSPeripherals config to change logo for printer
powershell_script 'Add logo path to config' do
  code <<-EOH
    $webConfig = '#{node['mosaic']['pos']['MosaicApp']['config']['MosaicPeripheralsMgr']}\\MosaicPeripheralsSvc.exe.config'
    $doc = (Get-Content $webConfig) -as [Xml]
    $obj = $doc.configuration.appSettings.add | where {$_.Key -eq 'OPOSPrinterLogoFile'}
    $obj.value="#{node['mosaic']['pos']['MosaicApp']['config']['logo']}"
    $doc.Save($webConfig)
  EOH
end

report_app_installed_v2 'reporting' do
    appname "MPOS"
    version "#{version}"
    path "#{node['mosaic']['pos']['MosaicApp']['physical_path']}"
    details "Mosaic - POS was deployed"
    action :send
end

ruby_block "change runstatus" do
  block do
      node.default['deploy']['runstatus']="MPOS deploy Successfully\n"
  end
end
