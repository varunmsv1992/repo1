resource_name :deploy_webservice

property :webservice_name, String, name_property: true
property :physical_path, String
property :pub_name, String , required: true
property :app_pool_name, String , required: true, default: "DefaultAppPool"
property :appversion, String
property :installer_dir, String, required: true
property :config_template_file, String, default: ""
property :subapps, Array, default: []
property :templates, Array, default: []
property :iis_publication_type ,equal_to: ['simple','pubname-env','env-pubname'], default: 'pubname-env'
property :env, String, default: node['mosaic']['env'], required: true
property :iis_root, String, default: "C:\\WebSites"


load_current_value do

end

default_action :deployws

action :deployws do

  puts "Deploying #{webservice_name}"
  puts physical_path
  raise "The property physical_path must contains value" if !property_is_set?(:physical_path)
  #validations
  #if !property_is_set?(:physical_path) then
  tphysical_path = physical_path

  if !tphysical_path.include? iis_root
    if iis_publication_type.to_s =='simple'
      physical_path= "#{iis_root}\\#{tphysical_path}"
    else
      physical_path= "#{iis_root}\\#{env}\\#{tphysical_path}"
    end
  else
    physical_path = tphysical_path #I don't know why is we don't do this, phisical_path lose it current value
  end


  puts physical_path


  puts pub_name
  tpub_name = pub_name
  if iis_publication_type.to_s =='env-pubname'
    pub_name = "#{env}\\#{tpub_name}"
  elsif iis_publication_type.to_s =='pubname-env'
    pub_name = "#{tpub_name}-#{env}"
  else
    pub_name = tpub_name
  end

  puts pub_name

  #delete previous version
  directory physical_path do
    recursive true
    action :delete
  	only_if {::File.directory?(physical_path)}
  end

  #Creating folder
  directory physical_path do
    action :create
    not_if { ::File.directory?(physical_path)}
  end

  #Update files
  ruby_block 'Copying files' do
    block do
      FileUtils.cp_r "#{installer_dir}/.",physical_path
    end
    only_if { ::Dir.entries(physical_path) == ['.', '..']} #if the folder is empty
  end


  #Apply template: Web.config
  template "#{physical_path}/Web.config" do
    source config_template_file
    local true
    only_if {!(config_template_file.nil? or config_template_file.empty?)}
  end

  report_app_installed_v2 'reporting webservice installed' do
      appname pub_name
      version appversion
      path physical_path
      details "WebService"
      action :nothing
  end

  puts "final physical path: #{physical_path}"
  #Creating Web Application if not exists
  powershell_script 'Creating Web Application' do
  code <<-EOH
    $succeeded = import-module WebAdministration
    if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
      #Could not import, trying to snapin
      add-pssnapin WebAdministration
    }

    $appName = "#{pub_name}"
    $appPoolName = "#{app_pool_name}"
    $AppPoolPath = "IIS:\\AppPools\\$appPoolName"
    if (!(Test-Path $AppPoolPath -pathType container))
    {
      #create the app pool
      $pool = New-Item $AppPoolPath
      $pool = get-itemproperty $AppPoolPath
      $pool.managedRuntimeVersion= "v4.0"
      $pool.enable32BitAppOnWin64 = 1
      $pool.processModel.Identity
      $pool.processModel.identityType = 4;
      $pool | Set-Item
      $pool.Stop();
      $pool.Start();
    }
    $phisicalPath = "#{physical_path}"
    $IISPath = "IIS:\\Sites\\Default Web Site\\$appName"
    $exists = Test-Path $IISPath
    if ($exists){
      Remove-WebApplication -Name "$appName" -Site "Default Web Site"
    }


    New-Item "$IISPath" -physicalPath $phisicalPath -type Application -Force
    Set-ItemProperty  "$IISPath" -name applicationPool -value $appPoolName -Force

  EOH
  guard_interpreter :powershell_script
  not_if { 1!=1}
  notifies :send, 'report_app_installed_v2[reporting webservice installed]', :immediately
  end
end


action :deploywebapp do

  puts "Deploying #{webservice_name}"
  puts physical_path
  raise "The property physical_path must contains value" if !property_is_set?(:physical_path)
  #validations
  tphysical_path = physical_path

  if !tphysical_path.include? iis_root
    if iis_publication_type.to_s =='simple'
      physical_path= "#{iis_root}\\#{tphysical_path}"
    else
      physical_path= "#{iis_root}\\#{env}\\#{tphysical_path}"
    end
  else
    physical_path = tphysical_path #I don't know why is we don't do this, phisical_path lose it current value
  end


  puts physical_path


  puts pub_name
  tpub_name = pub_name
  if iis_publication_type.to_s =='env-pubname'
    pub_name = "#{env}\\#{tpub_name}"
  elsif iis_publication_type.to_s =='pubname-env'
    pub_name = "#{tpub_name}-#{env}"
  else
    pub_name = tpub_name
  end

  puts pub_name

  #delete previous version
  directory physical_path do
    recursive true
    action :delete
    only_if {::File.directory?(physical_path)}
  end

    #Creating folder
    directory physical_path do
      action :create
      not_if { ::File.directory?(physical_path)}
    end

    #Update files
    ruby_block 'Copying files' do
      block do
        FileUtils.cp_r "#{installer_dir}/.",physical_path
      end
      only_if { ::Dir.entries(physical_path) == ['.', '..']} #if the folder is empty
    end

    templates.each do |template|
      puts "Applying template for #{template['file']}"
      only_if { ::File.file?("#{config_template_file}\\App_js.serverSettings.js.erb")}
    #Apply template: backoffice serverSettings.js
    template "#{physical_path}/App_js/serverSettings.js" do
      source "#{config_template_file}\\backoffice_App_js.serverSettings.js.erb"
      local true
      only_if { ::File.file?("#{config_template_file}\\backoffice_App_js.serverSettings.js.erb")}
    end

    #Apply template: controlstation serverSettings.js
    template "#{physical_path}/App_js/serverSettings.js" do
      source "#{config_template_file}\\controlstation_App_js.serverSettings.js.erb"
      local true
      only_if { ::File.file?("#{config_template_file}\\controlstation_App_js.serverSettings.js.erb")}
    end


      template "#{physical_path}/#{template['file']}" do
        source "#{config_template_file}#{template['source']}"
        local template['local']
        only_if { ::File.file?("#{config_template_file}#{template['source']}")}
      end

    end

    #Apply template: serverSettings.js
    template "#{physical_path}/App/config.js" do
      source "#{config_template_file}\\App.config.js.erb"
      local true
      only_if { ::File.file?("#{config_template_file}\\App.config.js.erb")} #if the folder is empty
    end

    report_app_installed_v2 'reporting webapp installed' do
        appname pub_name
        version appversion
        path physical_path
        details "WebSite"
        action :nothing
    end

    #Creating Mosaic Web Application if not exists
    powershell_script 'Installing AppPools for Mosaic' do
    code <<-EOH
      $succeeded = import-module WebAdministration
      if (($succeeded -ne $null) -and ($succeeded.GetType() -eq [System.Exception])) {
        #Could not import, trying to snapin
        add-pssnapin WebAdministration
      }

      $appName = "#{pub_name}"
      $appPoolName = "#{app_pool_name}"
      $AppPoolPath = "IIS:\\AppPools\\$appPoolName"
      if (!(Test-Path $AppPoolPath -pathType container))
      {
        #create the app pool
        $pool = New-Item $AppPoolPath
        $pool = get-itemproperty $AppPoolPath
        $pool.managedRuntimeVersion= "v4.0"
        $pool.enable32BitAppOnWin64 = 1
        $pool.processModel.Identity
        $pool.processModel.identityType = 4;
        $pool | Set-Item
        $pool.Stop();
        $pool.Start();
      }
      $phisicalPath = "#{physical_path}"
      $IISPath = "IIS:\\Sites\\Default Web Site\\$appName"
      $exists = Test-Path $IISPath
      if ($exists){
        Remove-WebApplication -Name "$appName" -Site "Default Web Site"
      }

      New-Item "$IISPath" -physicalPath $phisicalPath -type Application -Force
      Set-ItemProperty  "$IISPath" -name applicationPool -value $appPoolName -Force

    EOH
    guard_interpreter :powershell_script
    not_if { 1!=1}
    notifies :send, 'report_app_installed_v2[reporting webapp installed]', :immediately
    end


end
