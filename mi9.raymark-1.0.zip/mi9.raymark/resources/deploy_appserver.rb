resource_name :deploy_application

property :app_name, String, name_property: true
property :physical_path, String, required: true
property :exe_file_name, String , required: true
property :appversion, String , default: ""
property :installer_dir, String, required: true
property :config_template_file, String, required: true
property :installation_type ,equal_to: ['simple','pubname-env'], default: 'pubname-env'
property :env, String, default: node['mosaic']['env'], required: true
property :program_file_root, String
load_current_value do
end

default_action :deployapp

action :deployapp do

  puts "Deploying #{app_name}"
  puts physical_path
  raise "The property physical_path must contains value" if !property_is_set?(:physical_path)

	powershell_script 'Process Terminate' do
	 code <<-EOH
	   $process = "#{exe_file_name}"
	   $processname = $process -replace ".exe", ""
	   $Processes = (get-process "$processname")
		if($Processes) {
			foreach ($process in $processes) {
			  $process.kill()
			  write-host "The $ProcessName  has Terminated"
			 }
	   }
	   else {
		write-host "No Process found with name $ProcessName"
		}
	 EOH
	 guard_interpreter :powershell_script
	end

  #validations
  #if !property_is_set?(:physical_path) then
  tphysical_path = physical_path

  if !tphysical_path.include? program_file_root
    if installation_type.to_s =='simple'
      physical_path= "#{program_file_root}\\#{tphysical_path}"
    else
      physical_path= "#{program_file_root}\\#{env}\\#{tphysical_path}"
    end
  else
    physical_path = tphysical_path #I don't know why is we don't do this, phisical_path lose it current value
  end

  puts physical_path

  #delete previous version
  directory physical_path do
    recursive true
    action :delete
    only_if {::File.directory?(physical_path)}
  end

  #Creating folder
  directory physical_path do
    action :create
    not_if { ::File.directory?(physical_path)}
  end

  directory "#{physical_path}" do
  	rights :full_control, "Everyone"
  	inherits true
  	action :create
    recursive true
  end
  #Update files
  ruby_block "Copy #{app_name} files" do
    block do
      FileUtils.cp_r "#{installer_dir}/.",physical_path
    end
    only_if { ::Dir.entries(physical_path) == ['.', '..']} #if the folder is empty
  end

  report_app_installed_v2 'reporting Affinity installed' do
      appname app_name
      version appversion
      path physical_path
      details "Affinity"
      action :nothing
  end

  #Apply template: Web.config
  template "#{physical_path}/#{exe_file_name}.config" do
    source config_template_file
    local true
    notifies :send, 'report_app_installed_v2[reporting Affinity installed]', :immediately
  end


end
