resource_name :send_email

=begin
http://localhost:8080/api/notification/send-email
{
"from":"jcfiorenzano23@gmail.com",
"to":["jcfiorenzano23@gmail.com"],
"subject":"Subject-test",
"message":"Last Test"
}
=end

property :artifacts, Array, default: [], required: true
property :from, String , required: true
property :to,Array, default: [] , required: true
property :subject, String , required: true
property :message, String , required: true
#property :override, [TrueClass, FalseClass] , default: true

load_current_value do
end

default_action :send

action :send do
  puts node['waitress']['url']
  puts to
  http_request 'Sending notification email' do
    message ({
    :from =>from,
    :to =>to,
    :subject =>subject,
    :message =>message
    }.to_json)
    url "#{node['waitress']['url']}/api/notification/send-email"
    headers({'Content-Type' => 'application/json'})
    action :post
    ignore_failure true
  end

end
