resource_name :download_installers

property :artifacts, Array, default: [], required: true
property :dest_dir, String , required: true
property :version, String , required: true
property :art_url, String , required: true
#property :override, [TrueClass, FalseClass] , default: true

load_current_value do
  #Creating artifacts_dir folder
=begin
  directory dest_dir do
    action :create
    not_if { ::File.directory?(dest_dir)}
  end
=end
end

default_action :download

action :download do
  directory dest_dir do
    action :create
    not_if { ::File.directory?(dest_dir)}
  end

  artifacts.each do |art|
    puts "Downloading #{art}"
    artEncoded = art.dup
    if art_url.include? "http"
      artEncoded = artEncoded.gsub! ' ', '%20'
      artEncoded = artEncoded.nil? ? art : artEncoded
    end
    remote_file "#{dest_dir}\\#{art}#{version}.zip" do
     source "#{art_url}/#{version}/#{artEncoded}#{version}.zip"
  	 #not_if { ::File.exists?("#{dest_dir}\\#{art}#{version}.zip")}
    end
  end

end

action :unzip do

  artifacts.each do |art|
    puts "Unzipping #{art}"
  	powershell_script "Unziping artifact #{art} " do
  	  code <<-EOH
        $Zipfile = "#{dest_dir}\\#{art}#{version}.zip"
  			$Destination = "#{dest_dir}\\#{art}#{version}"
        if(test-path $Destination){
          Remove-Item $Destination -Recurse -Force
        }
        Add-Type -assembly "system.io.compression.filesystem"
  	    [io.compression.zipfile]::ExtractToDirectory($Zipfile, $Destination)
  	    EOH
  	    guard_interpreter :powershell_script
  	#not_if { ::File.directory?("#{dest_dir}\\#{art}#{version}")}
    only_if {1==1}
  	end

  end
end
