resource_name :Deploy_languagepack

property :pub_name, String, name_property: true
property :physical_path, String, required: true
property :installer_dir, String, required: true
property :application_name, String, name_property: true
property :component_name, String, name_property: true
property :iis_publication_type ,equal_to: ['simple','pubname-env','env-pubname'], default: 'pubname-env'
property :env, String, default: node['mosaic']['env'], required: true
property :iis_root, String, default: "C:\\WebSites"
#property :installation_type ,equal_to: ['simple','pubname-env'], default: 'pubname-env'
property :program_file_root, String
default_action :deploypack

action :deploypack do

  puts installer_dir
  puts "Deploying Language Package"
  puts physical_path

  raise "The property physical_path must contains value" if !property_is_set?(:physical_path)
  #validations
  #if !property_is_set?(:physical_path) then
  tphysical_path = physical_path

  if !tphysical_path.include? iis_root
    if iis_publication_type.to_s =='simple'
      physical_path= "#{iis_root}\\#{tphysical_path}"
    else
      physical_path= "#{iis_root}\\#{env}\\#{tphysical_path}"
    end
  else
    physical_path = tphysical_path #I don't know why is we don't do this, phisical_path lose it current value
  end
  #Update files
  ruby_block "Copy #{application_name} files" do
    block do
      FileUtils.cp_r "#{installer_dir}\\.",physical_path
      puts physical_path
      puts installer_dir
    end
    only_if{::File.directory?(physical_path)} #if the folder exist
  end
end
