resource_name :raymark_rollback

property :backup_folder, String, required: true

default_action :rollback_default

action :rollback_default do

  directory 'rollback create backup folder'  do
    path backup_folder
    recursive true
  	action :delete
  	only_if { ::File.directory?(backup_folder) and ::File.directory?("#{backup_folder}_last")}
  end

  #rollback from rename_last_backup_dbdir
  ruby_block 'rollback rename last backup folder' do
  	block do
  		if ::File.directory?("#{backup_folder}_last") and !(::File.directory?(backup_folder))
          ::File.rename("#{backup_folder}_last",backup_folder)
      end
  	end
  	action :run
  end
end
