resource_name :raymark_backup

property :backup_mainfolder, String, required: true
property :backup_folder, String, required: true

default_action :backup

action :backup do
  directory 'Create Backup main folder' do
    path backup_mainfolder
    action :create
    not_if {::File.directory?(backup_mainfolder)}
  end

  directory 'Delete backup last folder'  do
    path "#{backup_folder}_last"
    recursive true
  	action :delete
    only_if { ::File.directory?("#{backup_folder}_last")}
  end

  ruby_block "Rename last backup folder if it exists" do
  	block do
  		::File.rename(backup_folder,"#{backup_folder}_last")
  	end
  	only_if { ::File.directory?(backup_folder) and !(::File.directory?("#{backup_folder}_last"))}
  end

  directory 'Create Backup folder' do
    path backup_folder
    action :create
    not_if { ::File.directory?(backup_folder) }
  end
end
