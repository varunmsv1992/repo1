resource_name :deploy_xpertapplication

property :app_name, String, name_property: true
property :acronym_name, String
#property :physical_path, String, required: true
#property :exe_file_name, String , required: true
property :version, String , default: ""
property :installer_dir, String, required: true
#property :installation_type ,equal_to: ['simple','pubname-env'], default: 'pubname-env'
#property :env, String, default: node['mosaic']['env'], required: true
#property :program_file_root, String, default: "C:\\Program Files (x86)\\Raymark"

load_current_value do
end

action :deployapp do

  puts "Deploying #{app_name}"

  powershell_script "Closing #{app_name} app" do
    code <<-EOH
      try{
  					$process = Get-Process "#{app_name}" -ErrorAction Stop
  					if ($process -ne $Null -and $process -ne ''){
  								 Get-Process "#{app_name}" | stop-process
  					}
      }catch [System.Exception] {
          Write-Output $_.Exception.Message
      }
      EOH
    guard_interpreter :powershell_script
  end


  powershell_script "Uninstalling #{app_name}" do
    code <<-EOH
          $app = Get-WmiObject -Class Win32_Product | Where-Object {
            $_.Name -match "#{app_name}"
          }
          if ($app){
            $app.Uninstall()
          }else{
            $app = Get-WmiObject -Class Win32_Product | Where-Object {
              $_.Name -match "#{acronym_name}"
            }
            if ($app){ $app.Uninstall()
            }

          }
      EOH
    guard_interpreter :powershell_script
  end

  #Apply template: Setup.ini
  template "#{installer_dir}\\setup.iss" do
    source "/xpert/#{acronym_name}/setup.iss_#{version}.erb"
  end

  #Installing #{app_name} for Windows.
  execute "Installing #{app_name} for Windows" do
    command "\"#{installer_dir}\\setup.exe\" /s /f1\"#{installer_dir}\\setup.iss\""
    #action :nothing
    only_if { ::File.directory?("#{installer_dir}")}
  end
end
