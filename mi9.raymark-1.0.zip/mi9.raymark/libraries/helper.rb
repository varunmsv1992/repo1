require 'net/smtp'
require 'json'

module HandlerSendEmail
  class Helper

    def send_email(email, messagePart)
      message = "From: #{email['from']}\n"
      message << "To: "
      email['to'].each do |to|
        message << "<#{to}>,"
      end
      message << "\n"
      message << "Date: #{Time.now.rfc2822}\n"
      message << messagePart

      smtp = Net::SMTP.new(email['server'], email['port'])
      smtp.enable_starttls
      smtp.start(email['domain'], email['user'], email['password'], :login) do |smtp|
              smtp.send_message message, email['user'], email['to']
      end
    end

    def send_email_on_run_completed(node_name, deploy)
        email=deploy['email']
        runlog=deploy['runlog']
        message = "Subject: Chef run completed on #{node_name}\n"
        message << "Chef run completed on #{node_name}\n"
        message << "#{runlog}\n"
        send_email(email, message)
    end

    def send_email_on_run_failure(node_name, deploy)
        email=deploy['email']
        runlog=deploy['runlog']
        message = "Subject: Chef run failed on #{node_name}\n"
        message << "Chef run failed on #{node_name}\n"
        message << "#{runlog}\n"
        send_email(email, message)
    end

    def send_email_on_run_failure1(node_name, deploy)
      email=deploy['email']
      runstatus=deploy['runstatus']
      filename = "failed-run-data.json"
      file = "C:\\chef\\cache\\#{filename}"
      # Read a file and encode it into base64 format
      filecontent = File.read(file)
      encodedcontent = [filecontent].pack("m")   # base64
      # Read Json Data to Array
      data_hash = JSON.parse(filecontent)
      marker = "AUNIQUEMARKER"

      body = "#{data_hash['exception']}\n"
      body << "Run status: #{runstatus}\n"

      body= "Chef run failed on #{node_name}\n"
      body << "#{data_hash['exception']}\n"
      # Define the main headers.
      message = "Subject: Chef run failed on #{node_name}\n"
      message << "MIME-Version: 1.0\n"
      message << "Content-Type: multipart/mixed; boundary=#{marker}\n"
      message << "--#{marker}\n"
      # Define the message action
      message << "Content-Type: text/plain\n"
      message << "Content-Transfer-Encoding:8bit\n"
      message << "#{body}\n"
      message << "--#{marker}\n"
      # Define the attachment section
      message << "Content-Type: multipart/mixed; name=#{filename}\n"
      message << "Content-Transfer-Encoding:base64\n"
      message << "Content-Disposition: attachment; filename=#{filename}\n"
      message << "#{encodedcontent}\n"
      message << "--#{marker}--\n"
      send_email(email, message)
    end

=begin
        send_email(email, message)
    end

    def send_email_on_run_failure(node_name, email, runstatus)

      filename = "failed-run-data.json"
      file="#{Chef::Config[:file_cache_path]}\\#{filename}"
      #file = "C:\\chef\\cache\\#{filename}"
      # Read a file and encode it into base64 format
      filecontent = File.read(file)
      encodedcontent = [filecontent].pack("m")   # base64
      # Read Json Data to Array
      data_hash = JSON.parse(filecontent)
      marker = "AUNIQUEMARKER"

      body = "#{data_hash['exception']}\n"
      body << "Run status: #{runstatus}\n"
      # Define the main headers.
      message = "Subject: Deployment failed on #{node_name} node\n"
      message << "MIME-Version: 1.0\n"
      message << "Content-Type: multipart/mixed; boundary=#{marker}\n"
      message << "--#{marker}\n"
      # Define the message action
      message << "Content-Type: text/plain\n"
      message << "Content-Transfer-Encoding:8bit\n"
      message << "#{body}\n"
      message << "--#{marker}\n"
      # Define the attachment section
      message << "Content-Type: multipart/mixed; name=#{filename}\n"
      message << "Content-Transfer-Encoding:base64\n"
      message << "Content-Disposition: attachment; filename=#{filename}\n"
      message << "#{encodedcontent}\n"
      message << "--#{marker}--\n"
      send_email(email, message)
    end
=end
    def send_email_on_database_update_completed(node_name, email, runlog, filename)
      file="#{Chef.run_context.node.mosaic.backup.maindir}\\#{filename}"
      filecontent = File.read(file)
      encodedcontent = [filecontent].pack("m")   # base64
      # Read Json Data to Array
      #data_hash = JSON.parse(filecontent)
      marker = "AUNIQUEMARKER"
      body= "The follow roles were deployed:\n"
      body << "#{runlog}\n"
      # Define the main headers.
      message = "Subject: Deployment completed on #{node_name} node\n"

      message << "MIME-Version: 1.0\n"
      message << "Content-Type: multipart/mixed; boundary=#{marker}\n"
      message << "--#{marker}\n"
      # Define the message action
      message << "Content-Type: text/plain\n"
      message << "Content-Transfer-Encoding:8bit\n"
      message << "#{body}\n"
      message << "--#{marker}\n"
      # Define the attachment section
      message << "Content-Type: multipart/mixed; name=#{filename}\n"
      message << "Content-Transfer-Encoding:base64\n"
      message << "Content-Disposition: attachment; filename=#{filename}\n"
      message << "#{encodedcontent}\n"
      message << "--#{marker}--\n"
      send_email(email, message)
    end

    def run_resource(nickname, type, action)
        filesystem_resource = Chef.run_context.resource_collection.lookup("#{type}[#{nickname}]")
        filesystem_resource.run_action(action) if filesystem_resource
    end

    def mosaic_rollback_backup()
      run_resource("rollback create backup wsdir folder", "directory", :delete)
      run_resource("rollback rename_last_backup_wsdir", "ruby_block", :run)
    end

    def mosaic_rollback_update()
      run_resource("Delete folders in WebSites", "directory", :delete)
      run_resource("Restoring WebSites folders", "powershell_script", :run)
      mosaic_rollback_backup()
    end

    def mosaic_rollback_apps_backup()
      run_resource("rollback create backup appsdir folder", "directory", :delete)
      run_resource("rollback rename_last_backup_appsdir", "ruby_block", :run)
    end

    def mosaic_rollback_apps_update()
      run_resource("Delete folders in AppServer", "directory", :delete)
      run_resource("Restoring AppServer folders", "powershell_script", :run)
      mosaic_rollback_apps_backup()
    end

    def mosaic_rollback_standalone_backup()
      run_resource("rollback create backup dbdir folder", "directory", :delete)
      run_resource("rollback rename_last_backup_dbdir", "ruby_block", :run)
    end

    def mosaic_rollback_standalone_update()
      run_resource("Restoring standalone database", "powershell_script", :run)
    end

    def mosaic_rollback_db_backup()
      run_resource("rollback create db backup dbdir folder", "directory", :delete)
      run_resource("rollback db rename_last_backup_dbdir", "ruby_block", :run)
    end

    def mosaic_rollback_db_update()
      run_resource("Restoring db database", "powershell_script", :run)
    end

    def do_on_run_failure(node_name, deploy)
        runstatus=deploy['runstatus']
        status=["webservice_backup","webservice_update","appserver_backup","appserver_update","standalone_backup","standalone_update","db_backup","db_update","xpert_backup","xpert_update","xsmc_backup","xsmc_update"]
        if status.include?(runstatus)
           mosaic_rollback(runstatus)
        end
    end

    def mosaic_rollback(runstatus)
      #run_resource("Sending status Error", "http_request", :post)
        case runstatus
          when "webservice_backup"
            mosaic_rollback_backup()
          when "webservice_update"
            mosaic_rollback_update()
          when "appserver_backup"
            mosaic_rollback_apps_backup()
          when "appserver_update"
            mosaic_rollback_apps_update()
          when "standalone_backup"
            mosaic_rollback_standalone_backup()
          when "standalone_update"
            mosaic_rollback_standalone_update()
          when "db_backup"
            mosaic_rollback_db_backup()
          when "db_update"
            mosaic_rollback_db_update()
        end
    end

  end
end
