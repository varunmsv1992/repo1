require 'net/smtp'
require 'json'

module HandlerChefRun
  class Helper

    def send_email(email, messagePart)
      message = "From: #{email['from']}\n"
      message << "To: "
      email['to'].each do |to|
        message << "<#{to}>,"
      end
      message << "\n"
      message << "Date: #{Time.now.rfc2822}\n"
      message << messagePart

      smtp = Net::SMTP.new(email['server'], email['port'])
      smtp.enable_starttls
      smtp.start(email['domain'], email['user'], email['password'], :login) do |smtp|
              smtp.send_message message, email['user'], email['to']
      end
    end

    def send_email_on_run_completed(node_name, deploy)
        email=deploy['email']
        runlog=deploy['runlog']
        message = "Subject: Chef run completed on #{node_name}\n"
        message << "Chef run completed on #{node_name}\n"
        message << "#{runlog}\n"
        send_email(email, message)
    end

    def send_email_on_run_failure_2(node_name, deploy)
        email=deploy['email']
        runlog=deploy['runstatus']
        message = "Subject: Chef run failed on #{node_name}\n"
        message << "Chef run failed on #{node_name}\n"
        message << "#{runlog}\n"
        send_email(email, message)
    end

    def send_email_on_run_failure(node_name, deploy)
      email=deploy['email']
      runstatus=deploy['runstatus']
      filename = "failed-run-data.json"
      file = "C:\\chef\\cache\\#{filename}"
      # Read a file and encode it into base64 format
      filecontent = File.read(file)
      encodedcontent = [filecontent].pack("m")   # base64
      # Read Json Data to Array
      data_hash = JSON.parse(filecontent)
      marker = "AUNIQUEMARKER"

      body = "#{data_hash['exception']}\n"
      body << "Run status: #{runstatus}\n"

      body= "Chef run failed on #{node_name}\n"
      body << "#{data_hash['exception']}\n"
      # Define the main headers.
      message = "Subject: Chef run failed on #{node_name}\n"
      message << "MIME-Version: 1.0\n"
      message << "Content-Type: multipart/mixed; boundary=#{marker}\n"
      message << "--#{marker}\n"
      # Define the message action
      message << "Content-Type: text/plain\n"
      message << "Content-Transfer-Encoding:8bit\n"
      message << "#{body}\n"
      message << "--#{marker}\n"
      # Define the attachment section
      message << "Content-Type: multipart/mixed; name=#{filename}\n"
      message << "Content-Transfer-Encoding:base64\n"
      message << "Content-Disposition: attachment; filename=#{filename}\n"
      message << "#{encodedcontent}\n"
      message << "--#{marker}--\n"
      send_email(email, message)
    end

  end
end
